# MU — Why Has It Skyrocketed and Is It Cheap or Expensive?

**Memo prepared from: trading_comps_template.xlsx (real data, May 2026)**
Spot: $668.06  |  Mkt Cap: $570B  |  EV: $563B  |  Net Cash $6.6B (no net debt)

---

## TL;DR — The two truths that explain everything

**MU is BOTH the most expensive memory stock in history AND the cheapest AI infrastructure stock — depending on which earnings number you use.**

| Multiple | MU | Peer Median | Premium / (Discount) | Verdict |
|---|---|---|---|---|
| **LTM EV/EBITDA** | **30.1x** | 22.4x | **+34%** | EXPENSIVE on backward earnings |
| **FY1E EV/EBITDA** | **21.2x** | 14.9x | **+42%** | EXPENSIVE even on forwards |
| **LTM P/E** | **25.2x** | 26.7x | -6% | In line on backward |
| **FY1E P/E** | **8.9x** | 24.2x | **−63%** | **DEEPLY CHEAP on forwards** |
| **FY2E P/E** | **5.6x** | n/a | n/a | **Trading at semicap-trough multiple** |
| **MU's own historical** | **30.1x EV/EBITDA** | **6.7x (10-yr median)** | **+349%** | **5x its own normal** |

The market is paying a 34% LTM premium AND a 63% forward discount **simultaneously**. That happens when consensus believes a structural earnings step-change is real — i.e. EPS goes from $20 (LTM) to $56 (FY1E) to $89 (FY2E). At those levels, today's $668 is cheap; at trailing levels, it's egregious.

---

## Why MU has skyrocketed (the bull case)

1. **HBM (High-Bandwidth Memory) is structural, not cyclical.** Every NVIDIA AI accelerator, AMD MI300, and hyperscaler TPU uses HBM3e/HBM4. Per company guidance, MU has **already locked in price + volume agreements for ALL of calendar 2026 HBM supply.**

2. **Q3 FY26 guide is unprecedented.** Revenue $33.5B (vs Q2 $23.86B = **+40% QoQ**), gross margin **81%**, EPS **$19.15** for a single quarter. Annualized → $76 EPS run-rate.

3. **Earnings trajectory: $4.60 → $12.07 → $19.15 in three quarters** (Q1→Q2→Q3 FY26 GAAP EPS). This is the steepest earnings ramp MU has ever delivered.

4. **Net cash balance sheet ($6.6B).** Most-ever net cash position (vs peer median 0.7x ND/EBITDA leverage). MU is no longer a balance-sheet risk story.

5. **ROIC 18%** — well above peer median 12% and 200bps above MU's own through-cycle 16-18%.

6. **Analyst PTs**: Mean ~$525, range $350–$700. Consensus says modest upside from here, and even the bears ($350) are only -30%.

---

## Why MU is fundamentally expensive (the through-cycle view)

This is what an IB analyst would flag in pitch:

| Through-Cycle Metric | Value | Read |
|---|---|---|
| Mid-Cycle EBITDA Margin (10-yr mean) | **28%** | LTM is 32% — only 430bps above mid-cycle |
| Mid-Cycle EBITDA ($mm) | **$16,240** | Implied via mid-cycle margin × LTM revenue |
| LTM EBITDA | $18,740 | 15% above mid-cycle |
| **Through-Cycle EV/EBITDA** | **34.7x** | vs MU's 10-yr median of **6.7x** = **5x premium to own history** |
| Through-Cycle ROIC | 18% | In line with current — earnings power genuine |

**Key tension:** the "Mid-Cycle EBITDA Margin" of 28% is computed from MU's own 10-year average, which spans 2018 peak through 2023 trough. Memory has *historically* mean-reverted hard. The market is implicitly betting **HBM lifts the through-cycle margin to 40-50% permanently** — i.e. the 10-year history is no longer the right reference.

---

## Football Field — Implied Share Price Ranges

What MU should be worth under each methodology:

| Methodology | Implied Low | Implied Median | Implied High | Current vs Median |
|---|---|---|---|---|
| 52-Week Trading Range | $160 | $342 | $524 | **+46%** above mid |
| Analyst Price Targets | $350 | $525 | $700 | **−5%** below mid |
| EV/Revenue LTM (peers) | $215 | $405 | $595 | +23% |
| EV/EBITDA LTM (peers) | $255 | $354 | $453 | **+41%** |
| EV/EBITDA FY1E (peers) | $304 | $468 | $632 | +7% |
| **P/E LTM (peers)** | **$431** | **$644** | **$856** | **−22%** |
| **P/E FY1E (peers)** | **$1,021** | **$1,276** | **$1,531** | **−61%** |
| Mid-Cycle EV/EBITDA | $204 | $316 | $429 | **+58%** |
| Mini DCF (WACC 12.4%, g 2.5%) | $32 | $55 | $78 | **+811%** |

**Two clusters:**
- **Through-cycle / mean-reversion methods** ($55–$405): MU is severely overvalued
- **Forward earnings methods** ($644–$1,531): MU is severely undervalued

This is the cleanest illustration of the market's pricing problem — it's a single asset that legitimately trades 50% above OR 60% below "fair value" depending on whether you trust the FY27 EPS print of $89.

---

## The Verdict — What an IB MD Would Say in the Pitch

> "MU is a **call option on HBM secularity**. At $668, you're paying ~9x next-year earnings — cheap if AI capex sustains and HBM stays sold-out through 2027. But you're also paying 35x through-cycle EBITDA — three derating risks if memory normalizes:
>
> 1. **Capacity adds:** SK Hynix and Samsung are racing to add HBM. By 2H 2027, supply could outpace demand. Memory prices have NEVER gone up four years in a row.
> 2. **AI capex normalization:** Hyperscaler capex is at a record share of revenue. Pace must slow eventually.
> 3. **Multiple compression on EPS:** Even if MU prints $89 EPS in FY27, applying a memory-cyclical 15x multiple gives $1,335 — but applying a 6x trough multiple gives $534. Same earnings, dramatically different stock."

**The honest answer to "is MU cheap or expensive":**

- **Cheap on FY27E earnings.** 5.6x P/E means you only need to believe MU prints $90 EPS to make today's price work.
- **Expensive on through-cycle math.** Its own 10-year median EV/EBITDA is 6.7x; it's currently 30x. To return to even 12x mid-cycle, EBITDA would have to **double** while price stays flat (effectively requiring HBM to lift through-cycle EBITDA from ~$16B to ~$47B run-rate).
- **Risk/reward**: lopsided in absolute terms. Peak-cycle multiples on peak-cycle earnings = 2x downside risk if you're wrong on HBM secularity, 30-40% upside if consensus is right.

---

## What changed vs prior cycles

| Cycle Top | Year | MU Peak EBITDA Mgn | Peak EV/EBITDA | Subsequent Trough EBITDA Mgn | Trough Drawdown |
|---|---|---|---|---|---|
| Cycle 1 | 2014 | ~30% | ~5x | 16% (2016) | -50% |
| Cycle 2 | 2018 | ~50% | ~3.5x | 22% (2019-20) | -60% |
| Cycle 3 (current) | 2026E | ~50%+ (Q3 guide 81% GM) | **30x** | TBD | TBD |

In every prior peak, **MU's EV/EBITDA multiple compressed to single digits BEFORE the EBITDA cycle peaked**, because the market sees through. **This time the multiple has expanded into the peak.** That's the historic anomaly — and either marks a structural regime change (HBM = secular AI demand = different industry now) OR sets up a violent mean reversion when sentiment shifts.

---

## How to refresh this analysis

The memo above was generated from `trading_comps_template.xlsx` using the data in this folder. To refresh with current quotes / estimates:

1. Run **`2 - REFRESH DATA.bat`** — pulls live MU + peer data from Yahoo Finance
2. Open **`trading_comps_template.xlsx`**
3. Go to **Football Field** tab — see updated implied share prices
4. Go to **Cyclical Adjustments** tab — see current LTM vs mid-cycle margin gap
5. Go to **Mini DCF** tab — see implied price under your own WACC and terminal growth assumptions (the yellow cells in B11/B12 are user-editable)
6. Go to **Sensitivity** tab — change peer multiple assumptions to stress-test

The workbook will tell you instantly whether MU is cheap or expensive **on whichever methodology you trust** — that's the point of the football field. There is no single answer.

---

*Built with `trading_comps_template.xlsx` — 19 tabs, 3,049 formulas, 0 errors, all data refreshable via `python refresh.py` from yfinance.*
