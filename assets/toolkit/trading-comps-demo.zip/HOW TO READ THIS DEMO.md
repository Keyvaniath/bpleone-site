# Trading Comps Model — DEMO Edition

This is a **frozen sample** of the full IB-grade trading comps model, populated with a real Micron Technology (MU) analysis as of April 2026.

## What's in this folder

1. **`Sample_Trading_Comps_MU_DEMO.xlsx`** — open this in Excel
   - 19 IB-grade analysis tabs + 1 upgrade page · 4 charts · 3,000+ interconnected formulas
   - Football Field, Implied Valuation, WACC, Mini DCF, Cyclical Adjustments, Performance, Sensitivity, etc.

2. **`SAMPLE - Why MU is at $499 (full thesis).md`** — the analytical narrative the workbook supports

3. **`What this model can analyze (sample sectors).md`** — pre-built peer sets for Oil, AI, Banks, Auto, Semis

4. **`About the Author.md`** — Brandon Leon, independent research

## What's locked in this demo
- Data is FROZEN — no live refresh
- Cannot change ticker / peers / sector
- No Python source code or notebook

## To unlock — see the workbook's first tab "👉 GET FULL VERSION"

Standard edition: workbook + live refresh tool · **$79**
Pro edition: + Jupyter + refresh.exe + white-label license · **$249**

