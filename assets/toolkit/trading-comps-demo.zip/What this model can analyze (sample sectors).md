# Sample Peer Sets — What This Model Can Do

The same workbook handles any sector with a one-line ticker change. Here are pre-built peer sets across the industries I cover.

---

## Semiconductors — Memory (cyclical heavyweight)
**Target candidates:** MU, 005930.KS (Samsung), 000660.KS (SK Hynix)
**Peers:** WDC, STX, SNDK, NVDA, AVGO
**Sector flag:** `Semiconductors`
**Why this combo:** Memory is the most violently cyclical sub-industry in tech. Through-cycle EV/EBITDA matters more than LTM. The model surfaces this on the Cyclical Adjustments tab.

## Semiconductors — Logic / AI accelerators
**Target candidates:** NVDA, AMD, AVGO
**Peers:** INTC, MRVL, QCOM, ARM, TSM
**Sector flag:** `Semiconductors`
**Why:** Different cycle dynamics from memory — AI demand has lifted multiples; question is sustainability.

## Semiconductors — Capital equipment ("picks and shovels")
**Target candidates:** AMAT, LRCX, KLAC, ASML
**Peers:** TER, ENTG, UCTT, ICHR
**Sector flag:** `Semiconductors`
**Why:** Sells INTO memory + foundry capex. Cycle leads memory by 2-3 quarters.

---

## Oil & Gas — Integrated supermajors
**Target candidates:** XOM, CVX, SHEL, BP, TTE
**Peers:** COP, EOG, OXY, FANG, MRO
**Sector flag:** `Oil & Gas`
**Why:** Most cyclical sector outside memory. Through-cycle margin = your headline metric. LTM multiples are useless at peaks.

## Oil & Gas — E&P pure-plays
**Target candidates:** EOG, FANG, OXY, COP
**Peers:** PXD, MTDR, CHRD, OVV
**Sector flag:** `Oil & Gas`
**Why:** Higher beta than supermajors. Capex intensity is the swing factor.

## Oil & Gas — Refining / midstream
**Target candidates:** MPC, PSX, VLO, HF
**Peers:** ENB, KMI, EPD, ET
**Sector flag:** `Oil & Gas`
**Why:** Different multiple framework — EV/distributable cash flow matters for midstream.

---

## AI / Hyperscaler — Mega-cap cloud
**Target candidates:** MSFT, GOOGL, AMZN, META
**Peers:** ORCL, IBM, CRM, ADBE, NOW, SAP
**Sector flag:** `AI / Hyperscaler`
**Why:** Capex intensity is the new battleground. Compare hyperscaler capex/rev ratios to spot who's overspending.

## AI Infrastructure — Picks-and-shovels
**Target candidates:** NVDA, ANET, AVGO
**Peers:** AMD, MRVL, MU, COHR, VRT, SMCI
**Sector flag:** `AI / Hyperscaler`
**Why:** Datacenter buildout beneficiaries. Watch through-cycle ROIC for who's earning real returns vs riding hype.

---

## Financials — Money center banks
**Target candidates:** JPM, BAC, WFC, C
**Peers:** GS, MS, USB, PNC, TFC
**Sector flag:** `Standard`
**Why:** Different framework — P/B and ROTCE matter more than EV/EBITDA. Workbook still works (P/B included on Implied Valuation tab).

## Financials — Asset managers
**Target candidates:** BLK, BX, KKR, APO, BAM
**Peers:** TROW, BEN, IVZ, AB, AMG
**Sector flag:** `Standard`

---

## Auto / Mobility
**Target candidates:** TSLA, F, GM, STLA
**Peers:** RIVN, LCID, NIO, LI, XPEV, TM, HMC
**Sector flag:** `Standard`
**Why:** Splits cleanly into legacy ICE (low multiple) vs EV pure-plays (high multiple). The peer comparison surfaces the gap.

## Auto Parts / Suppliers
**Target candidates:** APTV, BWA, MGA, LEA
**Peers:** GT, ALSN, DAN
**Sector flag:** `Standard`

---

## Materials / Mining (cyclical)
**Target candidates:** FCX, NEM, AEM, GOLD, RIO
**Peers:** BHP, VALE, SCCO, AA
**Sector flag:** Use `Oil & Gas` (similar cyclical treatment)
**Why:** Through-cycle margins, not LTM, drive valuation. Mid-cycle EBITDA framework critical.

## Steel / Industrial Metals
**Target candidates:** NUE, STLD, X, CLF
**Peers:** RS, CMC, HCC, SCHN

---

## Healthcare — Big Pharma
**Target candidates:** PFE, MRK, JNJ, ABBV, BMY
**Peers:** LLY, GSK, NVO, AZN, SNY, NVS
**Sector flag:** `Standard`

## Healthcare — Biotech
**Target candidates:** REGN, VRTX, GILD, BIIB
**Peers:** AMGN, BMY, INCY, ALNY
**Sector flag:** `Standard`

---

## Consumer / Retail
**Target candidates:** WMT, COST, TGT, AMZN
**Peers:** HD, LOW, BJ, DG, DLTR
**Sector flag:** `Standard`

## Restaurants
**Target candidates:** MCD, CMG, SBUX, YUM
**Peers:** QSR, DPZ, WING, CAKE
**Sector flag:** `Standard`

---

## Aerospace & Defense
**Target candidates:** LMT, RTX, NOC, GD, BA
**Peers:** LDOS, HII, CW, AVAV
**Sector flag:** `Standard`

## Industrials — Multi-industry
**Target candidates:** GE, HON, MMM, ITW, EMR
**Peers:** ROK, ETN, PH, AME, DOV
**Sector flag:** `Standard`

---

**How to use (Standard / Pro tiers):** Open the workbook's `Inputs` tab, set the target ticker + peers + sector flag from the lists above. Double-click `2 - REFRESH DATA.bat` (or `refresh.exe` for Pro). Workbook rebuilds in ~30 seconds with full IB-grade anal