# About the Author

**Brandon Leon** — independent equity research focused on cyclical industries.

## Coverage focus

- **Semiconductors** (memory, logic, semicap equipment)
- **Energy** (oil & gas, midstream, refining)
- **Materials** (metals, mining, chemicals)
- **AI infrastructure** (hyperscaler beneficiaries, datacenter buildout)

## What I do differently

I treat cyclicals as cyclicals. Most sell-side comps quote LTM EV/EBITDA at the top of the cycle and call the stock cheap. My framework computes mid-cycle EBITDA from each company's own 7–10 year history and quotes the through-cycle multiple — which usually tells a different story.

This workbook automates that approach. It's the same framework I use for my own research notes.

## Sample analysis

See `MU_THESIS_MEMO.md` in the Demo bundle — full through-cycle valuation framework applied to Micron Technology, capturing both the structural HBM bull case and the mean-reversion bear case.

## Background

- 2023 CFA Institute Research Challenge — Americas Region winner with Cal State Fullerton; advanced to global final, Washington, D.C.
- CFA Level 2 candidate
- Lower-middle-market private equity (2022–