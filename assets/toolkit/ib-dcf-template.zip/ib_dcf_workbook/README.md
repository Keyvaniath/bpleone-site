# IB DCF Template — Standalone Workbook

This folder contains just the Excel workbook — no notebook, no pipeline, no Python.

## What's here

- **`IB_DCF_Template.xlsm`** — the full 20-tab DCF workbook. Currently populated with **MU (Micron Technology)** as a worked example so you can see what a finished IC analysis looks like end-to-end.

## How to use it

You have two choices:

### Option A — Use it as a manual fill-in template

Open `IB_DCF_Template.xlsm` in Excel and overwrite the input cells with your own company's data. Live formulas will recalculate automatically.

The yellow-highlighted cells are manual inputs:
- **Required Return tab** — ticker (C3), shares outstanding, beta, debt amounts
- **Cash Flow Forecast tab** — revenue, EBIT, CapEx, NWC, depreciation
- **Cover tab** — rating, price target, thesis bullets
- **Scenario Analysis tab** — Pess/Base/Opt revenue and EBIT paths

This works but requires you to source the data manually (yfinance, SEC filings, FactSet, Bloomberg).

### Option B — Use the full automated pipeline (recommended)

The full automated version pulls data live from yfinance, builds peer comparisons, runs the 9-step pipeline, and produces a clean workbook in ~60 seconds. To use that version, get the full distribution package — it includes this workbook plus the Jupyter notebook that drives the pipeline.

## What's in the workbook

20 tabs organized into four groups:

**Front-of-book** (the IC reads these): Cover, Instructions, Peer Comparison, Relative Valuation
**The model** (analyst lives here): Required Return, Cash Flow Forecast, Scenario Analysis, Valuation Estimates, Valuation Summary, Debt Maturity Schedule, Reverse DCF
**Source data** (yfinance pulls): IS, BS, CF, Key Items, Estimates, Segment Revenue, Industry
**Analysis tools**: Driver Sensitivity, Revenue Bridge

For a comprehensive walkthrough of what each tab does and how to read it, see the `ANALYST_GUIDE.md` that ships with the full distribution package.

## Audited

The workbook has been audited end-to-end across sixteen dimensions. It opens cleanly in Excel without repair dialogs. Every formula is auditable, every fallback is transparent.

---

**Version:** Universal Edition — Apr 2026
