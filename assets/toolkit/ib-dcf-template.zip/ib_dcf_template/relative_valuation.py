"""
relative_valuation.py — v4 — IB-grade Comparable Companies Analysis.

Rebuilds the 'Relative Valuation' tab in the portable DCF workbook. All identity,
peer-set, mid-cycle normalization factors, and cyclicality thresholds are driven
by dcf_config.CONFIG — this module has no hard-coded company assumptions.

v4 upgrades (on top of v3)
───────────────────────────
PORTABILITY
  • Reads identity / peer set / mid-cycle factors / cyclicality thresholds from
    dcf_config.CONFIG. Falls back to v3 Micron defaults if dcf_config unavailable.
  • Peer tickers DISCOVERED DYNAMICALLY from Peer Comparison!C3:G3 at apply() time.
  • LABELS dict centralizes every VLOOKUP key (Net Debt, Common Equity, EPS,
    shares-outstanding) so a new workbook schema swaps in one place.
  • Input validation at apply() entry catches missing tickers / malformed peer rows.

FINANCE RIGOR
  • Mid-cycle driver ROW 6 is now a live CASCADE driven off a side block:
        D6 = D5 × revenue_factor          (mid revenue   = NTM × factor)
        C6 = C5 × bvps_factor             (mid BVPS      = NTM × factor)
        E6 = D6 × ebitda_margin           (mid EBITDA    = mid rev × margin)
        B6 = (D6 × net_margin) / shares   (mid EPS       = mid NI / shares)
        F6 = E6 × fcf_conversion          (mid FCF       = mid EBITDA × conv.)
    Five factors + mid-cycle Net Debt are editable YELLOW cells at M4:O10.
  • Row 18 "NORMALIZED BLENDED" switches to MEDIAN-based implied prices
    (row 12) as the primary basis — outlier-robust; row 11 (mean-based) demoted
    to italic cross-check. Summary row 49 follows suit.
  • Implied prices on EV-based methods use the editable mid-cycle Net Debt (N10),
    not the live peak-cycle Net Debt, so mid-cycle implied equity reflects
    through-cycle capital structure.
  • Football field range = peer MIN / MAX of trading multiples — cleaner IC-deck
    convention for 5-peer small-sample sets than median±1σ.

IC POLISH
  • Football field adds three reference bars above the method bars:
        Row 59: 52-Week Range
        Row 60: Two-Stage DCF Range
        Row 61: Analyst PT Range (High / Low from Peer Comparison)
  • Market-price MARKER series renders a thin red vertical bar at current market
    across all rows (standard IC-deck reference line).
  • Banner carries an as-of date stamp (=TEXT(TODAY(),\"mmm d, yyyy\")).

Row map (v4)
────────────
  1      Banner (target ticker + as-of date)
  2      Source / peer group subtitle
  3      IMPLIED EQUITY VALUATION header
  4      Column headers (drivers | multiples)
  5      NTM drivers (peak-cycle, live)
  6      Mid-cycle drivers (cascade — feeds from side block M:Q)
  7      Peer mean multiple
  8      Peer median multiple (italic cross-check)
  9      Implied price — Peak × Peer Mean (italic)
  10     Implied price — Peak × Peer Median (italic)
  11     Implied price — Mid-Cycle × Peer Mean (italic cross-check)
  12     Implied price — Mid-Cycle × Peer Median ★ PRIMARY (bold)
  13     Weight (auto-cyclicality; anchored on row 12)
  14     Weighted contribution (median basis)
  15     Mid-Cycle Implied vs Market
  16     Status flag
  17     Face-Value Blended (Peak-Cycle, upper bound)
  18     NORMALIZED BLENDED (Mid-Cycle, MEDIAN basis) ★ HEADLINE
  19     Peak-cycle caveat banner (conditional)
  21-31  Comparable Companies Detail
  33-40  Premium / (Discount) vs Peer Group
  42-49  Multiples-Based Valuation Summary (Peak + Mid)
  51-55  Analyst Consensus Reference
  57     Football Field banner
  58     Football Field sub-header
  59     52-Week Range reference bar
  60     Two-Stage DCF Range reference bar
  61     Analyst PT Range reference bar
  62-66  Method bars (P/E, P/Book, EV/Sales, EV/EBITDA, P/FCF)
  68     Hidden P/FCF peer helper (moved from row 67 to clear football field)
  69+    Methodology notes
  82+    Supplementary charts (multiples comparison, premium/discount)

Side block (cols M:O, rows 4-10 — mid-cycle assumption inputs, editable YELLOW):
  M5 "Revenue factor"       N5 × NTM        — feeds D6
  M6 "BVPS factor"          N6 × NTM        — feeds C6
  M7 "EBITDA margin"        N7 % of rev     — feeds E6 (and B6 via net margin)
  M8 "Net margin"           N8 % of rev     — feeds B6
  M9 "FCF conversion"       N9 % of EBITDA  — feeds F6
  M10 "Net Debt (mid)"      N10 $M          — feeds EV-based implied prices

Conventions preserved from v3
─────────────────────────────
  • No blank cells.  Undefined multiples → "N/M" (never 0, never blank).
  • All values are LIVE FORMULAS linking back to source tabs.
  • User-editable cells are YELLOW (FFF2CC).
  • Black font enforced; theme fills stripped on rebuild.
  • Every peer metric shown as MEAN and MEDIAN.
  • FORMAT AUDIT + RAW VALUE AUDIT printed to stdout on apply().

Usage
-----
    # 1. Edit dcf_config.CONFIG (or leave default) to target a company.
    # 2. Refresh source data first:
    #        dcf_refresh.run()
    # 3. Rebuild this tab:
    #        import importlib, relative_valuation
    #        importlib.reload(relative_valuation)
    #        relative_valuation.apply()

Idempotent — safe to run repeatedly. Clears the RV tab before rewriting.
"""
from __future__ import annotations
import os
import datetime as _dt
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.formatting.rule import ColorScaleRule, CellIsRule
from openpyxl.comments import Comment
from openpyxl.utils import get_column_letter
from openpyxl.chart import BarChart, Reference, Series
from openpyxl.chart.label import DataLabelList
from openpyxl.chart.layout import Layout, ManualLayout
from openpyxl.chart.shapes import GraphicalProperties
from openpyxl.drawing.fill import ColorChoice
from openpyxl.drawing.line import LineProperties

# ─── CONFIG wiring (portable) ───────────────────────────────────────────
# The module should run even if dcf_config isn't on the path (e.g. when a
# developer imports relative_valuation.py from a one-off notebook). Fallback
# keeps the v3 Micron defaults so existing workbooks continue to render.
try:
    from dcf_config import CONFIG as _CFG       # type: ignore[import]
    _CONFIG_LOADED = True
except Exception:                                # pragma: no cover
    _CFG = None
    _CONFIG_LOADED = False


def _cfg(attr: str, default):
    """Safe CONFIG attribute accessor with fallback default."""
    if _CFG is None:
        return default
    return getattr(_CFG, attr, default)


# ─── VLOOKUP LABELS ─────────────────────────────────────────────────────
# Every VLOOKUP key used against the IS / BS / Required Return tabs is
# centralized here. If a future workbook schema renames "Net Debt" to
# "Net debt (incl. leases)", swap it in one place and the entire tab stays
# in sync — no more hunting through formulas.
LABELS = {
    "net_debt":        "Net Debt",
    "common_equity":   "Common Equity",
    "eps_diluted":     "EPS (diluted)",
    "shares_out":      "Diluted Shares Outstanding",
    "revenue":         "Revenue",
    "ebitda":          "EBITDA",
    "fcf":             "Free Cash Flow",
}
RR_PRICE    = "'Required Return'!C5"   # Current market price
RR_SHARES   = "'Required Return'!C6"   # Diluted shares outstanding
VE_DCF_LOW  = "'Valuation Estimates'!B20"  # Pessimistic DCF implied share price
VE_DCF_HIGH = "'Valuation Estimates'!F20"  # Optimistic DCF implied share price
VE_DCF_MID  = "'Valuation Estimates'!D20"  # Base Case DCF implied share price

# ─── Styles ─────────────────────────────────────────────────────────────
NAVY = "1F3864"
WHITE_FONT_BOLD = Font(name="Calibri", color="FFFFFF", bold=True, size=11)
NAVY_FILL = PatternFill("solid", start_color=NAVY)
HDR_LIGHT_FILL = PatternFill("solid", start_color="D9E1F2")
YELLOW_FILL = PatternFill("solid", start_color="FFF2CC")       # user-editable
GREEN_FILL = PatternFill("solid", start_color="E2EFDA")        # totals
HEADLINE_FILL = PatternFill("solid", start_color="FFD966")     # headline/gold
GREY_FILL = PatternFill("solid", start_color="F2F2F2")         # sub-band
WHITE_FILL = PatternFill("solid", start_color="FFFFFF")

BLACK_FONT = Font(name="Calibri", color="000000", size=11)
BLACK_BOLD = Font(name="Calibri", color="000000", size=11, bold=True)
BLACK_ITAL = Font(name="Calibri", color="000000", size=10, italic=True)
NAVY_BOLD = Font(name="Calibri", color="002060", size=11, bold=True)
HEADLINE_FONT = Font(name="Calibri", color="000000", size=12, bold=True)

thin = Side(style="thin", color="BFBFBF")
BORDER = Border(top=thin, bottom=thin, left=thin, right=thin)
mid = Side(style="medium", color=NAVY)
BORDER_THICK = Border(top=mid, bottom=mid, left=mid, right=mid)

# Number formats
NF_MULT = '0.00"x"'
NF_MULT_FLAG = '0.00"x";[Red]-0.00"x";"N/M"'
NF_PRICE = '"$"#,##0.00'
NF_BIG_CURR = '"$"#,##0.0,"B";[Red]-"$"#,##0.0,"B";"—"'
NF_PCT = '0.0%'
NF_PCT_SIGNED = '+0.0%;-0.0%;0.0%'
NF_INT = '#,##0'
NF_WEIGHT = '0.0'
NF_FACTOR = '0.0%'

# ─── Peer layout on 'Peer Comparison' tab ───────────────────────────────
# Rows are fixed by the Peer Comparison template written by dcf_refresh.py.
# Columns: B = target, C-G = peers (up to 5). The ACTUAL peer columns in use
# are discovered at apply() time from the ticker row — see _discover_peers.
PC_ROW = {
    "company":     2,   "ticker":       3,
    "mkt_cap":     4,   "price":        5,   "hi_52":      6,   "lo_52":      7,
    "beta":        8,
    "pe_ttm":      9,   "pe_ntm":      10,   "ev_ebitda": 11,   "ev_rev":    12,
    "p_book":     13,   "p_sales":     14,
    "rev_grow":   15,   "eps_grow":    16,
    "gross_m":    17,   "ebit_m":      18,   "net_m":     19,
    "roe":        20,   "roa":         21,
    "d_to_e":     22,   "curr_ratio":  23,
    "revenue":    24,   "ebitda":      25,   "fcf":       26,
    "div_yld":    27,   "payout":      28,
    "rating":     29,   "px_tgt":      30,
    "tgt_hi":     31,   "tgt_lo":      32,   "n_analysts":33,
}
MU_COL = "B"                                      # Target column (convention)
_CANDIDATE_PEER_COLS = ["C", "D", "E", "F", "G"]  # Max 5 peers supported in template

# Populated by _discover_peers() at apply() entry. Builders below read these
# at function-call time (not import time) so dynamic peer sets flow through.
PEER_COLS: list[str] = list(_CANDIDATE_PEER_COLS)  # sensible default for import-time readers
ALL_COLS: list[str] = [MU_COL] + PEER_COLS


# ─── Mid-cycle side block (editable driver assumptions) ─────────────────
# Co-located at cols M:O, rows 4-10. Row 6 driver cascade reads these cells.
SB_COL_LBL    = "M"
SB_COL_VAL    = "N"
SB_COL_UNIT   = "O"
SB_ROW_HEADER = 4
SB_ROW_REVF   = 5   # Revenue factor (× NTM)
SB_ROW_BVPSF  = 6   # BVPS factor    (× NTM)
SB_ROW_EBMAR  = 7   # EBITDA margin  (% of revenue)
SB_ROW_NMAR   = 8   # Net margin     (% of revenue)
SB_ROW_FCFCNV = 9   # FCF conversion (% of EBITDA)
SB_ROW_MIDND  = 10  # Mid-cycle Net Debt ($M, editable)

# Convenience formula fragments
MID_ND_REF    = f"${SB_COL_VAL}${SB_ROW_MIDND}"      # $N$10 — editable mid-cycle Net Debt
REV_FACTOR    = f"${SB_COL_VAL}${SB_ROW_REVF}"       # $N$5
BVPS_FACTOR   = f"${SB_COL_VAL}${SB_ROW_BVPSF}"      # $N$6
EBITDA_MARGIN = f"${SB_COL_VAL}${SB_ROW_EBMAR}"      # $N$7
NET_MARGIN    = f"${SB_COL_VAL}${SB_ROW_NMAR}"       # $N$8
FCF_CONV      = f"${SB_COL_VAL}${SB_ROW_FCFCNV}"     # $N$9


# ─── Helpers ────────────────────────────────────────────────────────────
def _discover_peers(pc_ws) -> list[str]:
    """Read peer ticker row (C3:G3) and return columns that hold a peer ticker.

    Returns the subset of ['C','D','E','F','G'] whose ticker cell is non-empty.
    Raises ValueError if fewer than 3 peers — a meaningful peer-group floor
    for an IB-quality comps analysis.
    """
    active: list[str] = []
    for col in _CANDIDATE_PEER_COLS:
        val = pc_ws[f"{col}{PC_ROW['ticker']}"].value
        if val is not None and str(val).strip() != "":
            active.append(col)
    if len(active) < 3:
        raise ValueError(
            f"Peer set has only {len(active)} ticker(s) populated on Peer "
            f"Comparison tab (cols C:G, row {PC_ROW['ticker']}). Need ≥3 peers "
            f"for a defensible comparable companies analysis."
        )
    return active


def _validate_inputs(wb) -> None:
    """Fail-fast guard on prerequisites before rebuilding the RV tab.

    Catches the most common upstream failures:
      • Peer Comparison tab missing entirely
      • Required Return tab missing C5 (market price) or C6 (shares)
      • Target ticker / market cap missing on Peer Comparison row
    """
    missing = []
    if "Peer Comparison" not in wb.sheetnames:
        missing.append("Peer Comparison tab")
    if "Required Return" not in wb.sheetnames:
        missing.append("Required Return tab")
    if "BS" not in wb.sheetnames:
        missing.append("BS tab")
    if missing:
        raise RuntimeError(
            "Cannot build Relative Valuation — missing upstream tabs: "
            + ", ".join(missing)
            + ". Run dcf_refresh.run() first (Cell 5 of DCF_Notebook.ipynb)."
        )
    pc = wb["Peer Comparison"]
    target = pc[f"{MU_COL}{PC_ROW['ticker']}"].value
    if target is None or str(target).strip() == "":
        raise RuntimeError(
            "Target ticker missing on Peer Comparison!"
            f"{MU_COL}{PC_ROW['ticker']}. Set CONFIG.ticker in dcf_config.py "
            "and rerun dcf_refresh.run()."
        )
    rr = wb["Required Return"]
    if rr["C5"].value is None:
        raise RuntimeError(
            "Required Return!C5 (current market price) is empty. "
            "Rerun dcf_refresh.run()."
        )


def _auto_detect_workbook() -> str:
    cwd = os.path.abspath("")
    candidates = sorted(
        [f for f in os.listdir(cwd) if f.lower().endswith((".xlsm", ".xlsx"))],
        key=lambda f: os.path.getmtime(os.path.join(cwd, f)),
        reverse=True,
    )
    if not candidates:
        raise FileNotFoundError(f"No workbook found in {cwd}")
    return os.path.join(cwd, candidates[0])


def _pc(ref_row: int, col: str) -> str:
    return f"'Peer Comparison'!{col}{ref_row}"


def _clear_rv_tab(ws) -> None:
    for merged in list(ws.merged_cells.ranges):
        ws.unmerge_cells(str(merged))
    max_r = max(ws.max_row, 120)
    max_c = max(ws.max_column, 15)
    # CRITICAL: reset row heights + hidden flags on every rebuild.
    # Prior runs (or manual Excel outlining) could leave rows 4-18 or elsewhere
    # with height=0 / hidden=True, which then silently collapsed the headline
    # Implied Equity Valuation block on re-render. Force a clean slate here —
    # section builders below re-apply intentional overrides (rows 1, 18, 19, 49, 65, 67, 113).
    for r in range(1, max_r + 1):
        rd = ws.row_dimensions.get(r)
        if rd is not None:
            rd.height = None     # None => default row height
            rd.hidden = False
            rd.outlineLevel = 0  # collapse any outline grouping
    for r in range(1, max_r + 1):
        for c in range(1, max_c + 1):
            cell = ws.cell(row=r, column=c)
            cell.value = None
            cell.fill = PatternFill(fill_type=None)
            cell.border = Border()
            cell.font = BLACK_FONT
            cell.alignment = Alignment()
            cell.number_format = "General"
            cell.comment = None
    try:
        ws.conditional_formatting._cf_rules.clear()
    except Exception:
        pass
    # Remove any pre-existing charts on the sheet
    ws._charts = []
    # Clear any column-level grouping/outlining too
    for col_letter, cd in list(ws.column_dimensions.items()):
        cd.outlineLevel = 0
        cd.hidden = False


def _style_header_banner(ws, rng: str, text: str) -> None:
    ws.merge_cells(rng)
    head = ws[rng.split(":")[0]]
    head.value = text
    head.font = WHITE_FONT_BOLD
    head.fill = NAVY_FILL
    head.alignment = Alignment(horizontal="left", vertical="center", indent=1)
    head.border = BORDER_THICK


def _sub_header_row(ws, row: int, cols_and_labels: list[tuple[str, str]]) -> None:
    for col, label in cols_and_labels:
        c = ws[f"{col}{row}"]
        c.value = label
        c.font = Font(name="Calibri", color="FFFFFF", bold=True, size=10)
        c.fill = NAVY_FILL
        c.alignment = Alignment(horizontal="center", vertical="center")
        c.border = BORDER


def _set(ws, coord: str, value, *, nf=None, font=None, fill=None,
         bold=False, align=None, border=BORDER, comment=None):
    c = ws[coord]
    c.value = value
    if nf:
        c.number_format = nf
    c.font = font if font else (BLACK_BOLD if bold else BLACK_FONT)
    if fill is not None:
        c.fill = fill
    if align:
        c.alignment = align
    else:
        if isinstance(value, str) and value.startswith("="):
            c.alignment = Alignment(horizontal="right", vertical="center")
        elif isinstance(value, (int, float)):
            c.alignment = Alignment(horizontal="right", vertical="center")
        else:
            c.alignment = Alignment(horizontal="left", vertical="center")
    c.border = border
    if comment:
        c.comment = Comment(comment, "MD Review")


def _avg_formula(row: int, cols: list[str]) -> str:
    return f"=AVERAGE({','.join(_pc(row, c) for c in cols)})"


def _med_formula(row: int, cols: list[str]) -> str:
    return f"=MEDIAN({','.join(_pc(row, c) for c in cols)})"


def _min_formula(row: int, cols: list[str]) -> str:
    return f"=MIN({','.join(_pc(row, c) for c in cols)})"


def _max_formula(row: int, cols: list[str]) -> str:
    return f"=MAX({','.join(_pc(row, c) for c in cols)})"


def _med_low_mult(row: int, cols: list[str]) -> str:
    """Median − 1 std dev of peer multiples, floored at 0 (IC-deck football-field low).
    Returns bare expression (no leading =)."""
    refs = ",".join(_pc(row, c) for c in cols)
    return f"MAX(MEDIAN({refs})-_xlfn.STDEV.S({refs}),0)"


def _med_high_mult(row: int, cols: list[str]) -> str:
    """Median + 1 std dev of peer multiples (IC-deck football-field high).
    Returns bare expression (no leading =)."""
    refs = ",".join(_pc(row, c) for c in cols)
    return f"MEDIAN({refs})+_xlfn.STDEV.S({refs})"


# ─── Section builders ───────────────────────────────────────────────────
def _build_mid_cycle_side_block(ws) -> None:
    """Side block M4:O10 — editable mid-cycle driver & capital-structure assumptions.

    These cells drive the Row 6 cascade. Changing any YELLOW cell here
    automatically re-weights the mid-cycle implied prices in rows 11-12,
    the weighted blend in rows 17-18, and every downstream chart.
    """
    # Header strip
    hdr_cells = [
        (f"{SB_COL_LBL}{SB_ROW_HEADER}", "Mid-Cycle Assumption"),
        (f"{SB_COL_VAL}{SB_ROW_HEADER}", "Value"),
        (f"{SB_COL_UNIT}{SB_ROW_HEADER}", "Units"),
    ]
    for coord, lbl in hdr_cells:
        c = ws[coord]
        c.value = lbl
        c.font = Font(name="Calibri", color="FFFFFF", bold=True, size=10)
        c.fill = NAVY_FILL
        c.alignment = Alignment(horizontal="center", vertical="center")
        c.border = BORDER

    # Pull defaults from CONFIG (with safe fallbacks to v3 hardcodes)
    rev_f   = _cfg("mid_cycle_revenue_factor",   0.70)
    bvps_f  = _cfg("mid_cycle_bvps_factor",      1.00)
    eb_m    = _cfg("mid_cycle_ebitda_margin",    0.32)
    ni_m    = _cfg("mid_cycle_net_margin",       0.15)
    fcf_cnv = _cfg("mid_cycle_fcf_conversion",   0.20)

    rows = [
        (SB_ROW_REVF,   "Revenue factor",          rev_f,   NF_FACTOR, "× NTM revenue",
         "Mid-cycle revenue = NTM revenue × this factor. Memory semis: 0.65-0.75. "
         "Stable software/staples: 0.90-1.00."),
        (SB_ROW_BVPSF,  "BVPS factor",             bvps_f,  NF_FACTOR, "× NTM BVPS",
         "Book value is largely stable through cycles; default 100%. Lower for "
         "capital-destructive periods (write-downs)."),
        (SB_ROW_EBMAR,  "EBITDA margin (mid)",     eb_m,    NF_PCT,    "% of revenue",
         "Mid-cycle EBITDA margin. Use 10-year average or trough-to-peak midpoint. "
         "MU memory: 30-35%."),
        (SB_ROW_NMAR,   "Net margin (mid)",        ni_m,    NF_PCT,    "% of revenue",
         "Mid-cycle net income margin. Drives mid-cycle EPS via (rev × net margin) / shares."),
        (SB_ROW_FCFCNV, "FCF conversion (mid)",    fcf_cnv, NF_PCT,    "% of EBITDA",
         "Through-cycle FCF / EBITDA. Heavy-capex cyclicals: 15-25%; asset-light: 60-80%."),
    ]
    for row, label, val, nf, unit, note in rows:
        _set(ws, f"{SB_COL_LBL}{row}", label, bold=True,
             align=Alignment(horizontal="left", vertical="center"))
        _set(ws, f"{SB_COL_VAL}{row}", val, nf=nf, fill=YELLOW_FILL, bold=True,
             comment=note)
        _set(ws, f"{SB_COL_UNIT}{row}", unit, font=BLACK_ITAL,
             align=Alignment(horizontal="left", vertical="center"))

    # Mid-cycle Net Debt — defaults to live Net Debt but is EDITABLE (user can
    # override with mid-cycle cash position, e.g. trough year when cash is depleted).
    _set(ws, f"{SB_COL_LBL}{SB_ROW_MIDND}", "Net Debt (mid-cycle)", bold=True,
         align=Alignment(horizontal="left", vertical="center"))
    _set(ws, f"{SB_COL_VAL}{SB_ROW_MIDND}",
         f"=IFERROR(VLOOKUP(\"{LABELS['net_debt']}\",BS!A:B,2,FALSE),0)",
         nf=NF_INT, fill=YELLOW_FILL, bold=True,
         comment=("Mid-cycle Net Debt used in EV-based implied prices. Defaults "
                  "to live BS Net Debt. For deeply cyclical targets, override "
                  "with trough-cycle Net Debt (when cash is drawn down and leases "
                  "fully recognized)."))
    _set(ws, f"{SB_COL_UNIT}{SB_ROW_MIDND}", "$M", font=BLACK_ITAL,
         align=Alignment(horizontal="left", vertical="center"))

    # Section footer note
    _set(ws, f"{SB_COL_LBL}{SB_ROW_MIDND+1}",
         "Edit YELLOW cells above to re-cast mid-cycle drivers. Row 6 cascades live.",
         font=Font(name="Calibri", color="808080", italic=True, size=9),
         align=Alignment(horizontal="left", vertical="center", wrap_text=True))
    try:
        ws.merge_cells(f"{SB_COL_LBL}{SB_ROW_MIDND+1}:{SB_COL_UNIT}{SB_ROW_MIDND+1}")
    except Exception:
        pass

    # Column widths for the side block so labels aren't truncated
    ws.column_dimensions[SB_COL_LBL].width = 24
    ws.column_dimensions[SB_COL_VAL].width = 12
    ws.column_dimensions[SB_COL_UNIT].width = 14


def _build_header(ws) -> None:
    # Row 1 banner — target ticker + as-of date both pulled live via Excel TODAY()
    ws.merge_cells("A1:L1")
    hdr = ws["A1"]
    target_ticker_ref = _pc(PC_ROW["ticker"], MU_COL)
    hdr.value = (
        f"=\"RELATIVE VALUATION — Comparable Companies Analysis  |  Target: \""
        f"&{target_ticker_ref}"
        f"&\"  |  As of \"&TEXT(TODAY(),\"mmm d, yyyy\")"
    )
    hdr.font = WHITE_FONT_BOLD
    hdr.fill = NAVY_FILL
    hdr.alignment = Alignment(horizontal="left", vertical="center", indent=1)
    hdr.border = BORDER_THICK
    ws.row_dimensions[1].height = 22

    # Row 2 subtitle — peer ticker list built live via _xlfn.TEXTJOIN
    peer_ticker_refs = [_pc(PC_ROW["ticker"], c) for c in PEER_COLS]
    peers_expr = f"_xlfn.TEXTJOIN(\", \",TRUE,{','.join(peer_ticker_refs)})"
    _set(ws, "A2",
         f"=\"Source: yfinance / SEC EDGAR via dcf_refresh.py  |  Peer group: \"&{peers_expr}"
         f"&\"  |  All figures live-linked — peak-cycle + through-cycle dual basis.\"",
         font=BLACK_ITAL, align=Alignment(horizontal="left", vertical="center"))
    ws.merge_cells("A2:L2")


def _build_implied_valuation(ws) -> None:
    """Rows 3-19: dual-basis implied equity valuation (peak + mid-cycle).

    Row 6 is a LIVE CASCADE off the side block (M4:O10). Mid-cycle EPS, BVPS,
    Revenue, EBITDA, FCF are all derived from the editable assumption cells —
    no per-cell 0.50/0.70 factors hard-coded into the driver row.

    Row 12 (Mid-Cycle × Peer MEDIAN) is the PRIMARY BASIS (bold, highlighted).
    Row 11 (Mid-Cycle × Peer MEAN) is italic cross-check — median is more
    robust to single-peer distortions in a 5-peer sample.
    """
    _style_header_banner(ws, "A3:L3",
        "IMPLIED EQUITY VALUATION  —  5-Method Blend  (Peak-Cycle + Through-Cycle)")

    # Row 4: Method column headers
    headers = [("A", "Line Item"), ("B", "NTM EPS"), ("C", "Book Val/Sh"),
               ("D", "Revenue ($M)"), ("E", "EBITDA ($M)"), ("F", "FCF ($M)"),
               ("H", "P/E (NTM)"), ("I", "P / Book"),
               ("J", "EV / Sales"), ("K", "EV / EBITDA"), ("L", "P / FCF")]
    for col, lbl in headers:
        _set(ws, f"{col}4", lbl, font=Font(color="FFFFFF", bold=True, size=10),
             fill=NAVY_FILL,
             align=Alignment(horizontal="center", vertical="center"))

    # ─── Row 5: PEAK-CYCLE NTM DRIVERS (live-linked) ───
    _set(ws, "A5", "NTM Drivers (peak-cycle, live)", bold=True)
    _set(ws, "B5",
        f"=IFERROR({RR_PRICE}/{_pc(PC_ROW['pe_ntm'], MU_COL)},"
        f"IFERROR(VLOOKUP(\"{LABELS['eps_diluted']}\",IS!A:B,2,FALSE),\"N/M\"))",
        nf=NF_PRICE)
    _set(ws, "C5",
        f"=IFERROR(VLOOKUP(\"{LABELS['common_equity']}\",BS!A:B,2,FALSE)/{RR_SHARES},"
        "\"N/M\")", nf=NF_PRICE)
    _set(ws, "D5", f"={_pc(PC_ROW['revenue'], MU_COL)}", nf=NF_INT)
    _set(ws, "E5", f"={_pc(PC_ROW['ebitda'], MU_COL)}", nf=NF_INT)
    _set(ws, "F5", f"={_pc(PC_ROW['fcf'], MU_COL)}", nf=NF_INT)

    # ─── Row 6: MID-CYCLE CASCADE (linked to side block, editable via M:O) ───
    # Every cell here is a FORMULA off the side-block assumptions. No
    # per-cell factors live in this module anymore — change the side block
    # and the entire mid-cycle stack re-casts in real time.
    _set(ws, "A6", "Mid-Cycle Drivers (cascade from side block →)", bold=True,
         comment=("Live cascade off mid-cycle assumption block at M4:O10. "
                  "Change Revenue factor / margins / conversion there and Row 6 "
                  "updates automatically, which re-weights rows 11-12 implied "
                  "prices and the weighted blends in rows 17-18."))
    # D6 = Revenue cascade: D5 × revenue_factor
    _set(ws, "D6", f"=D5*{REV_FACTOR}", nf=NF_INT, bold=True)
    # C6 = BVPS cascade: C5 × bvps_factor (stable, default 100%)
    _set(ws, "C6", f"=C5*{BVPS_FACTOR}", nf=NF_PRICE, bold=True)
    # E6 = EBITDA cascade: mid-revenue × mid EBITDA margin
    _set(ws, "E6", f"=D6*{EBITDA_MARGIN}", nf=NF_INT, bold=True)
    # B6 = EPS cascade: (mid-revenue × net margin) / shares outstanding
    _set(ws, "B6", f"=IFERROR((D6*{NET_MARGIN})/{RR_SHARES},\"N/M\")",
         nf=NF_PRICE, bold=True)
    # F6 = FCF cascade: mid-EBITDA × FCF conversion
    _set(ws, "F6", f"=E6*{FCF_CONV}", nf=NF_INT, bold=True)

    # ─── Row 7: PEER MEAN MULTIPLE ───
    _set(ws, "A7", "Peer Mean Multiple (excl. target)")
    _set(ws, "H7", _avg_formula(PC_ROW['pe_ntm'], PEER_COLS), nf=NF_MULT)
    _set(ws, "I7", _avg_formula(PC_ROW['p_book'], PEER_COLS), nf=NF_MULT)
    _set(ws, "J7", _avg_formula(PC_ROW['ev_rev'], PEER_COLS), nf=NF_MULT)
    _set(ws, "K7", _avg_formula(PC_ROW['ev_ebitda'], PEER_COLS), nf=NF_MULT)
    # P/FCF: route through the hidden helper row 68 (moved from 67 in v4) which
    # holds per-peer P/FCF values ("" if FCF≤0). Using AVERAGE/MEDIAN on plain
    # cells (which natively skip text) avoids openpyxl's array-formula limitation.
    # Helper row 68 is populated in _build_football_field; Excel evaluation is
    # order-independent so forward references work.
    _set(ws, "L7", "=IFERROR(AVERAGE(H68:L68),\"N/M\")", nf=NF_MULT)

    # ─── Row 8: PEER MEDIAN MULTIPLE (italic) ───
    _set(ws, "A8", "Peer Median Multiple (excl. target)", font=BLACK_ITAL)
    _set(ws, "H8", _med_formula(PC_ROW['pe_ntm'], PEER_COLS), nf=NF_MULT, font=BLACK_ITAL)
    _set(ws, "I8", _med_formula(PC_ROW['p_book'], PEER_COLS), nf=NF_MULT, font=BLACK_ITAL)
    _set(ws, "J8", _med_formula(PC_ROW['ev_rev'], PEER_COLS), nf=NF_MULT, font=BLACK_ITAL)
    _set(ws, "K8", _med_formula(PC_ROW['ev_ebitda'], PEER_COLS), nf=NF_MULT, font=BLACK_ITAL)
    _set(ws, "L8", "=IFERROR(MEDIAN(H68:L68),\"N/M\")",
         nf=NF_MULT, font=BLACK_ITAL)

    # ─── Row 9: IMPLIED PRICE (Peak × Peer Mean) — italic cross-check ───
    # Peak-cycle implied prices use LIVE Net Debt from BS (current capital
    # structure). Mid-cycle implied (rows 11-12) uses editable $N$10.
    NET_DEBT_PEAK = f"VLOOKUP(\"{LABELS['net_debt']}\",BS!A:B,2,FALSE)"
    _set(ws, "A9", "Implied Price — Peak × Peer Mean", font=BLACK_ITAL)
    _set(ws, "H9", "=IFERROR(B5*H7,\"N/M\")", nf=NF_PRICE, font=BLACK_ITAL)
    _set(ws, "I9", "=IFERROR(C5*I7,\"N/M\")", nf=NF_PRICE, font=BLACK_ITAL)
    _set(ws, "J9", f"=IFERROR((J7*D5-{NET_DEBT_PEAK})/{RR_SHARES},\"N/M\")",
         nf=NF_PRICE, font=BLACK_ITAL)
    _set(ws, "K9", f"=IFERROR((K7*E5-{NET_DEBT_PEAK})/{RR_SHARES},\"N/M\")",
         nf=NF_PRICE, font=BLACK_ITAL)
    _set(ws, "L9", f"=IFERROR((F5/{RR_SHARES})*L7,\"N/M\")",
         nf=NF_PRICE, font=BLACK_ITAL)

    # ─── Row 10: IMPLIED PRICE (Peak × Peer Median) — italic cross-check ───
    _set(ws, "A10", "Implied Price — Peak × Peer Median", font=BLACK_ITAL)
    _set(ws, "H10", "=IFERROR(B5*H8,\"N/M\")", nf=NF_PRICE, font=BLACK_ITAL)
    _set(ws, "I10", "=IFERROR(C5*I8,\"N/M\")", nf=NF_PRICE, font=BLACK_ITAL)
    _set(ws, "J10", f"=IFERROR((J8*D5-{NET_DEBT_PEAK})/{RR_SHARES},\"N/M\")",
         nf=NF_PRICE, font=BLACK_ITAL)
    _set(ws, "K10", f"=IFERROR((K8*E5-{NET_DEBT_PEAK})/{RR_SHARES},\"N/M\")",
         nf=NF_PRICE, font=BLACK_ITAL)
    _set(ws, "L10", f"=IFERROR((F5/{RR_SHARES})*L8,\"N/M\")",
         nf=NF_PRICE, font=BLACK_ITAL)

    # ─── Row 11: IMPLIED PRICE (Mid-Cycle × Peer Mean) — italic cross-check ───
    # Uses editable mid-cycle Net Debt ($N$10), not peak-cycle Net Debt.
    _set(ws, "A11", "Implied Price — Mid-Cycle × Peer Mean  (cross-check)",
         font=BLACK_ITAL)
    _set(ws, "H11", "=IFERROR(B6*H7,\"N/M\")", nf=NF_PRICE, font=BLACK_ITAL)
    _set(ws, "I11", "=IFERROR(C6*I7,\"N/M\")", nf=NF_PRICE, font=BLACK_ITAL)
    _set(ws, "J11", f"=IFERROR((J7*D6-{MID_ND_REF})/{RR_SHARES},\"N/M\")",
         nf=NF_PRICE, font=BLACK_ITAL)
    _set(ws, "K11", f"=IFERROR((K7*E6-{MID_ND_REF})/{RR_SHARES},\"N/M\")",
         nf=NF_PRICE, font=BLACK_ITAL)
    _set(ws, "L11", f"=IFERROR((F6/{RR_SHARES})*L7,\"N/M\")",
         nf=NF_PRICE, font=BLACK_ITAL)

    # ─── Row 12: IMPLIED PRICE (Mid-Cycle × Peer Median) — PRIMARY BASIS, BOLD ───
    # Median is outlier-robust (the formal small-sample statistic for a 5-peer
    # set) and serves as the headline blend in row 18.
    _set(ws, "A12", "Implied Price — Mid-Cycle × Peer Median  ★  PRIMARY",
         bold=True, fill=HDR_LIGHT_FILL)
    _set(ws, "H12", "=IFERROR(B6*H8,\"N/M\")",
         nf=NF_PRICE, bold=True, fill=HDR_LIGHT_FILL)
    _set(ws, "I12", "=IFERROR(C6*I8,\"N/M\")",
         nf=NF_PRICE, bold=True, fill=HDR_LIGHT_FILL)
    _set(ws, "J12", f"=IFERROR((J8*D6-{MID_ND_REF})/{RR_SHARES},\"N/M\")",
         nf=NF_PRICE, bold=True, fill=HDR_LIGHT_FILL)
    _set(ws, "K12", f"=IFERROR((K8*E6-{MID_ND_REF})/{RR_SHARES},\"N/M\")",
         nf=NF_PRICE, bold=True, fill=HDR_LIGHT_FILL)
    _set(ws, "L12", f"=IFERROR((F6/{RR_SHARES})*L8,\"N/M\")",
         nf=NF_PRICE, bold=True, fill=HDR_LIGHT_FILL)

    # ─── Row 13: WEIGHT (auto-cyclicality, anchored on row 12 — median basis) ───
    # Thresholds from CONFIG: full weight below half_thr, half weight below
    # zero_thr, zero above. Symmetric catches premium AND discount extremes.
    half_thr = _cfg("cyclicality_halfwt_threshold", 1.75)
    zero_thr = _cfg("cyclicality_zero_threshold",   3.00)
    _set(ws, "A13", "Weight (auto-cyclicality, editable)", bold=True,
         comment=(f"Cyclicality guard (symmetric) — anchored on MID-CYCLE × MEDIAN "
                  f"implied prices (row 12, primary basis). "
                  f"MAX(implied/market, market/implied): full weight if ≤ {half_thr:.2f}×, "
                  f"half-weight if ≤ {zero_thr:.2f}×, zero if > {zero_thr:.2f}×. "
                  "Thresholds sourced from dcf_config.CONFIG (cyclicality_halfwt_threshold, "
                  "cyclicality_zero_threshold). Overwrite any cell with a hard number."))
    default_weights = [("H", 2.0), ("I", 1.0), ("J", 2.5), ("K", 2.5), ("L", 1.0)]
    for col, w in default_weights:
        _set(ws, f"{col}13",
            f"=IFERROR(IF(NOT(ISNUMBER({col}12)),0,"
            f"IF(MAX({col}12/{RR_PRICE},{RR_PRICE}/{col}12)>{zero_thr},0,"
            f"IF(MAX({col}12/{RR_PRICE},{RR_PRICE}/{col}12)>{half_thr},0.5,{w}))),0)",
            nf=NF_WEIGHT, fill=YELLOW_FILL, bold=True)

    # ─── Row 14: WEIGHTED CONTRIBUTION (row 12 median × weight) ───
    _set(ws, "A14", "Weighted Contribution (mid-cycle × peer median)")
    for col in ["H", "I", "J", "K", "L"]:
        _set(ws, f"{col}14",
             f"=IFERROR(IF(ISNUMBER({col}12),{col}12*{col}13/SUM($H$13:$L$13),0),0)",
             nf=NF_PRICE)

    # ─── Row 15: MID-CYCLE IMPLIED vs MARKET (row 12 basis) ───
    _set(ws, "A15", "Mid-Cycle Implied vs Market")
    for col in ["H", "I", "J", "K", "L"]:
        _set(ws, f"{col}15",
             f"=IFERROR(IF(AND(ISNUMBER({col}12),{col}13>0),"
             f"({col}12-{RR_PRICE})/{RR_PRICE},\"N/M\"),\"N/M\")",
             nf=NF_PCT_SIGNED)

    # ─── Row 16: STATUS FLAG ───
    _set(ws, "A16", "Status Flag", font=BLACK_ITAL)
    default_w = {"H": 2.0, "I": 1.0, "J": 2.5, "K": 2.5, "L": 1.0}
    for col, w in default_w.items():
        _set(ws, f"{col}16",
             f"=IF({col}13=0,\"N/M (peak cycle)\","
             f"IF({col}13<{w},\"⚠ Half wt.\",\"✓ Full wt.\"))",
             font=BLACK_ITAL,
             align=Alignment(horizontal="left", vertical="center"))
    # P/Book outlier callout — generic (fires whenever peer mean P/B is >2× peer median)
    # Use module-level PEER_COLS so dynamic peer sets flow through.
    pb_peer_refs = ",".join(_pc(PC_ROW['p_book'], c) for c in PEER_COLS)
    ws["I16"].value = (
        f"=IF(I7>2*MEDIAN({pb_peer_refs}),"
        "\"⚠ Peer outlier — cross-check vs median\","
        "IF(I13=0,\"N/M (peak cycle)\","
        "IF(I13<1,\"⚠ Half wt.\",\"✓ Full wt.\")))"
    )

    # ─── Row 17: PEAK-CYCLE FACE-VALUE BLENDED (informational upper bound) ───
    # Uses H9:L9 (Peak × Mean) — the face-value answer if NTM drivers persisted.
    _set(ws, "A17", "Face-Value Blended (Peak-Cycle, upper bound)", bold=True, fill=GREEN_FILL)
    _set(ws, "G17", "Peak Blend:", bold=True, fill=GREEN_FILL,
         align=Alignment(horizontal="right", vertical="center"))
    _set(ws, "H17",
         "=IFERROR(SUMPRODUCT(IF(ISNUMBER(H9:L9),H9:L9,0),H13:L13)/SUM(H13:L13),\"N/M\")",
         nf=NF_PRICE, bold=True, fill=GREEN_FILL)
    _set(ws, "I17", "Market:", bold=True, fill=GREEN_FILL,
         align=Alignment(horizontal="right", vertical="center"))
    _set(ws, "J17", f"={RR_PRICE}", nf=NF_PRICE, bold=True, fill=GREEN_FILL)
    _set(ws, "K17", "Prem/(Disc):", bold=True, fill=GREEN_FILL,
         align=Alignment(horizontal="right", vertical="center"))
    _set(ws, "L17",
         f"=IFERROR((H17-{RR_PRICE})/{RR_PRICE},\"N/M\")",
         nf=NF_PCT_SIGNED, bold=True, fill=GREEN_FILL)

    # ─── Row 18: NORMALIZED BLENDED (Mid-Cycle × Peer MEDIAN) — HEADLINE ───
    # Flipped from v3: uses H12:L12 (median-based) not H11:L11 (mean-based).
    # Median is the formal outlier-robust statistic for 5-peer small samples.
    _set(ws, "A18", "★  NORMALIZED BLENDED (Mid-Cycle × Median)  — HEADLINE",
         font=HEADLINE_FONT, fill=HEADLINE_FILL)
    _set(ws, "G18", "Blend (Mid):", font=HEADLINE_FONT, fill=HEADLINE_FILL,
         align=Alignment(horizontal="right", vertical="center"))
    _set(ws, "H18",
         "=IFERROR(SUMPRODUCT(IF(ISNUMBER(H12:L12),H12:L12,0),H13:L13)/SUM(H13:L13),\"N/M\")",
         nf=NF_PRICE, font=HEADLINE_FONT, fill=HEADLINE_FILL)
    _set(ws, "I18", "Market:", font=HEADLINE_FONT, fill=HEADLINE_FILL,
         align=Alignment(horizontal="right", vertical="center"))
    _set(ws, "J18", f"={RR_PRICE}", nf=NF_PRICE, font=HEADLINE_FONT, fill=HEADLINE_FILL)
    _set(ws, "K18", "Prem/(Disc):", font=HEADLINE_FONT, fill=HEADLINE_FILL,
         align=Alignment(horizontal="right", vertical="center"))
    _set(ws, "L18",
         f"=IFERROR((H18-{RR_PRICE})/{RR_PRICE},\"N/M\")",
         nf=NF_PCT_SIGNED, font=HEADLINE_FONT, fill=HEADLINE_FILL)
    ws.row_dimensions[18].height = 24

    # ─── Row 19: PEAK-CYCLE CAVEAT BANNER ───
    _set(ws, "A19",
         f"=IF(COUNTIF(H13:L13,0)+COUNTIF(H13:L13,0.5)>=2,"
         f"\"⚠ PEAK-CYCLE COMPS for \"&{_pc(PC_ROW['ticker'], MU_COL)}"
         f"&\" — multiple methods flagged on NTM drivers. "
         f"Normalized mid-cycle blend (row 18) is the primary comps answer; "
         f"peak-cycle blend (row 17) is the face-value upper bound. "
         f"For cyclical targets (trough or peak), DCF with normalized through-cycle FCF "
         f"is the primary valuation — comps are corroborative.\",\"\")",
         font=Font(name="Calibri", color="9C0006", italic=True, bold=True, size=10),
         fill=PatternFill("solid", start_color="FFE699"),
         align=Alignment(horizontal="left", vertical="center", wrap_text=True))
    ws.merge_cells("A19:L19")
    ws.row_dimensions[19].height = 38

    # Aesthetic: merge label rows across empty B:G zone
    for r in range(7, 17):
        try:
            ws.merge_cells(f"A{r}:G{r}")
        except Exception:
            pass
    # Rows 5, 6 have driver values in B:F — no merge there
    # Rows 17, 18 have summary strip labels in G — merge A:F only
    for r in [17, 18]:
        try:
            ws.merge_cells(f"A{r}:F{r}")
        except Exception:
            pass


def _build_peer_detail(ws) -> None:
    """Rows 21-31: Comparable Companies Detail table."""
    _style_header_banner(ws, "A21:L21", "COMPARABLE COMPANIES DETAIL")

    _sub_header_row(ws, 22, [
        ("A", "Company"), ("B", "Ticker"), ("C", "Mkt Cap"),
        ("D", "Price"), ("E", "P/E (NTM)"), ("F", "EV/EBITDA"),
        ("G", "EV/Revenue"), ("H", "P/Book"), ("I", "Gross Margin"),
        ("J", "EBIT Margin"), ("K", "ROE"), ("L", "Rev Growth"),
    ])

    def _write_row(row: int, pc_col: str, is_target: bool = False):
        fill = HDR_LIGHT_FILL if is_target else None
        font = BLACK_BOLD if is_target else BLACK_FONT
        _set(ws, f"A{row}", f"={_pc(PC_ROW['company'], pc_col)}",
             font=font, fill=fill, align=Alignment(horizontal="left"))
        _set(ws, f"B{row}", f"={_pc(PC_ROW['ticker'], pc_col)}",
             font=font, fill=fill, align=Alignment(horizontal="center"))
        _set(ws, f"C{row}", f"={_pc(PC_ROW['mkt_cap'], pc_col)}",
             nf=NF_BIG_CURR, font=font, fill=fill)
        _set(ws, f"D{row}", f"={_pc(PC_ROW['price'], pc_col)}",
             nf=NF_PRICE, font=font, fill=fill)
        _set(ws, f"E{row}",
             f"=IFERROR(IF(ISNUMBER({_pc(PC_ROW['pe_ntm'], pc_col)}),"
             f"{_pc(PC_ROW['pe_ntm'], pc_col)},\"N/M\"),\"N/M\")",
             nf=NF_MULT, font=font, fill=fill)
        _set(ws, f"F{row}",
             f"=IFERROR(IF(ISNUMBER({_pc(PC_ROW['ev_ebitda'], pc_col)}),"
             f"{_pc(PC_ROW['ev_ebitda'], pc_col)},\"N/M\"),\"N/M\")",
             nf=NF_MULT, font=font, fill=fill)
        _set(ws, f"G{row}",
             f"=IFERROR(IF(ISNUMBER({_pc(PC_ROW['ev_rev'], pc_col)}),"
             f"{_pc(PC_ROW['ev_rev'], pc_col)},\"N/M\"),\"N/M\")",
             nf=NF_MULT, font=font, fill=fill)
        _set(ws, f"H{row}",
             f"=IFERROR(IF(ISNUMBER({_pc(PC_ROW['p_book'], pc_col)}),"
             f"{_pc(PC_ROW['p_book'], pc_col)},\"N/M\"),\"N/M\")",
             nf=NF_MULT, font=font, fill=fill)
        _set(ws, f"I{row}", f"={_pc(PC_ROW['gross_m'], pc_col)}",
             nf=NF_PCT, font=font, fill=fill)
        _set(ws, f"J{row}", f"={_pc(PC_ROW['ebit_m'], pc_col)}",
             nf=NF_PCT, font=font, fill=fill)
        _set(ws, f"K{row}", f"={_pc(PC_ROW['roe'], pc_col)}",
             nf=NF_PCT, font=font, fill=fill)
        _set(ws, f"L{row}", f"={_pc(PC_ROW['rev_grow'], pc_col)}",
             nf=NF_PCT, font=font, fill=fill)

    # Peers rows 23-27 (INTC, AMD, NVDA, QCOM, TXN)
    for i, pc_col in enumerate(PEER_COLS):
        _write_row(23 + i, pc_col, is_target=False)
    # Target row 29 (MU, highlighted)
    _write_row(29, MU_COL, is_target=True)
    # Row 30: Peer Mean
    _set(ws, "A30", "Peer Mean (excl. target)", bold=True, fill=GREY_FILL)
    for col in ["C", "D", "E", "F", "G", "H", "I", "J", "K", "L"]:
        nf = NF_PCT if col in ["I", "J", "K", "L"] else (
             NF_BIG_CURR if col == "C" else (
             NF_PRICE if col == "D" else NF_MULT))
        _set(ws, f"{col}30", f"=AVERAGE({col}23:{col}27)", nf=nf, bold=True, fill=GREY_FILL)
    # Row 31: Peer Median
    _set(ws, "A31", "Peer Median (excl. target)", font=BLACK_ITAL, fill=GREY_FILL)
    for col in ["C", "D", "E", "F", "G", "H", "I", "J", "K", "L"]:
        nf = NF_PCT if col in ["I", "J", "K", "L"] else (
             NF_BIG_CURR if col == "C" else (
             NF_PRICE if col == "D" else NF_MULT))
        _set(ws, f"{col}31", f"=MEDIAN({col}23:{col}27)", nf=nf, font=BLACK_ITAL, fill=GREY_FILL)


def _build_premium_discount(ws) -> None:
    """Rows 33-40: MU Premium/(Discount) vs Peer Mean & Median per metric."""
    # Dynamic banner — reads target ticker live
    ws.merge_cells("A33:L33")
    bnr = ws["A33"]
    bnr.value = (f"=\"\"&{_pc(PC_ROW['ticker'], MU_COL)}"
                 f"&\" PREMIUM / (DISCOUNT) TO PEER GROUP\"")
    bnr.font = WHITE_FONT_BOLD
    bnr.fill = NAVY_FILL
    bnr.alignment = Alignment(horizontal="left", vertical="center", indent=1)
    bnr.border = BORDER_THICK

    _sub_header_row(ws, 34, [
        ("A", "Metric"),
        ("F", "Peer Mean"), ("G", "Peer Median"),
        ("H", "Prem/(Disc) vs Mean"), ("I", "Prem/(Disc) vs Median"),
        ("J", "Direction"),
    ])
    # E34 header = target ticker (live)
    e34 = ws["E34"]
    e34.value = f"={_pc(PC_ROW['ticker'], MU_COL)}"
    e34.font = Font(name="Calibri", color="FFFFFF", bold=True, size=10)
    e34.fill = NAVY_FILL
    e34.alignment = Alignment(horizontal="center", vertical="center")
    e34.border = BORDER

    rows = [
        ("P/E (NTM)",    "E", False, "LOW"),
        ("EV / EBITDA",  "F", False, "LOW"),
        ("EV / Revenue", "G", False, "LOW"),
        ("P / Book",     "H", False, "LOW"),
        ("Gross Margin", "I", True,  "HIGH"),
        ("EBIT Margin",  "J", True,  "HIGH"),
    ]
    for i, (label, det_col, is_pct, direction) in enumerate(rows):
        r = 35 + i
        nf_raw = NF_PCT if is_pct else NF_MULT
        _set(ws, f"A{r}", label, bold=True)
        _set(ws, f"E{r}", f"={det_col}29", nf=nf_raw)   # MU row is now 29
        _set(ws, f"F{r}", f"={det_col}30", nf=nf_raw)   # Peer mean row is 30
        _set(ws, f"G{r}", f"={det_col}31", nf=nf_raw)   # Peer median row is 31
        _set(ws, f"H{r}",
             f"=IFERROR(IF(AND(ISNUMBER(E{r}),ISNUMBER(F{r})),"
             f"(E{r}-F{r})/ABS(F{r}),\"N/M\"),\"N/M\")",
             nf=NF_PCT_SIGNED)
        _set(ws, f"I{r}",
             f"=IFERROR(IF(AND(ISNUMBER(E{r}),ISNUMBER(G{r})),"
             f"(E{r}-G{r})/ABS(G{r}),\"N/M\"),\"N/M\")",
             nf=NF_PCT_SIGNED)
        if direction == "LOW":
            dir_formula = (f"=IF(NOT(ISNUMBER(H{r})),\"—\","
                           f"IF(H{r}<0,\"▲ Favorable (cheaper)\",\"▼ Unfavorable (premium)\"))")
        else:
            dir_formula = (f"=IF(NOT(ISNUMBER(H{r})),\"—\","
                           f"IF(H{r}>0,\"▲ Favorable (better)\",\"▼ Unfavorable (worse)\"))")
        _set(ws, f"J{r}", dir_formula, font=BLACK_ITAL,
             align=Alignment(horizontal="left", vertical="center"))

    # Aesthetic merges
    try:
        ws.merge_cells("A34:D34")
    except Exception:
        pass
    for r in range(35, 41):
        try:
            ws.merge_cells(f"A{r}:D{r}")
        except Exception:
            pass

    # Green-for-favorable / red-for-unfavorable CF
    green = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")
    red = PatternFill(start_color="FFC7CE", end_color="FFC7CE", fill_type="solid")
    ws.conditional_formatting.add("H35:I38",
        CellIsRule(operator="lessThan", formula=["0"], fill=green))
    ws.conditional_formatting.add("H35:I38",
        CellIsRule(operator="greaterThan", formula=["0"], fill=red))
    ws.conditional_formatting.add("H39:I40",
        CellIsRule(operator="greaterThan", formula=["0"], fill=green))
    ws.conditional_formatting.add("H39:I40",
        CellIsRule(operator="lessThan", formula=["0"], fill=red))


def _build_valuation_summary(ws) -> None:
    """Rows 42-49: Summary table — Peak + Mid-Cycle side-by-side."""
    _style_header_banner(ws, "A42:L42", "MULTIPLES-BASED VALUATION SUMMARY  —  Peak vs Mid-Cycle")

    _sub_header_row(ws, 43, [
        ("A", "Method"),
        ("C", "Peak Implied"), ("D", "Mid-Cycle Implied"),
        ("E", "Weight"), ("F", "Contribution"),
        ("G", "Mid vs Market"), ("H", "Status"),
    ])

    methods = [
        ("P/E (NTM)",  "H"),
        ("P / Book",   "I"),
        ("EV / Sales", "J"),
        ("EV / EBITDA","K"),
        ("P / FCF",    "L"),
    ]
    for i, (label, col) in enumerate(methods):
        r = 44 + i
        _set(ws, f"A{r}", label, bold=True)
        # Peak implied (row 9 = Peak × Mean).
        # Mid-cycle implied (row 12 = Mid × MEDIAN, primary in v4).
        _set(ws, f"C{r}",
             f"=IF(AND(ISNUMBER({col}9),{col}13>0),{col}9,\"N/M\")",
             nf=NF_PRICE, font=BLACK_ITAL)
        _set(ws, f"D{r}",
             f"=IF(AND(ISNUMBER({col}12),{col}13>0),{col}12,\"N/M\")",
             nf=NF_PRICE, bold=True)
        _set(ws, f"E{r}", f"={col}13", nf=NF_WEIGHT, fill=YELLOW_FILL, bold=True)
        _set(ws, f"F{r}", f"={col}14", nf=NF_PRICE)
        _set(ws, f"G{r}",
             f"=IF(ISNUMBER(D{r}),(D{r}-{RR_PRICE})/{RR_PRICE},\"N/M\")",
             nf=NF_PCT_SIGNED)
        _set(ws, f"H{r}", f"={col}16", font=BLACK_ITAL,
             align=Alignment(horizontal="left", vertical="center"))

    # Row 49: Weighted Average (headline = mid-cycle)
    r = 49
    _set(ws, f"A{r}", "WEIGHTED AVERAGE  (Mid-Cycle = headline)", font=HEADLINE_FONT, fill=HEADLINE_FILL)
    _set(ws, f"C{r}", "=H17", nf=NF_PRICE, font=BLACK_ITAL, fill=HEADLINE_FILL,
         comment="Peak-cycle blended (face-value upper bound)")
    _set(ws, f"D{r}", "=H18", nf=NF_PRICE, font=HEADLINE_FONT, fill=HEADLINE_FILL,
         comment="Mid-cycle normalized blended — the headline comps answer")
    _set(ws, f"E{r}", "=SUM(H13:L13)", nf=NF_WEIGHT, bold=True, fill=HEADLINE_FILL)
    _set(ws, f"F{r}", "=IF(SUM(H13:L13)=0,\"N/M\",SUM(F44:F48))",
         nf=NF_PRICE, bold=True, fill=HEADLINE_FILL)
    _set(ws, f"G{r}",
         "=IFERROR((D49-'Required Return'!$C$5)/'Required Return'!$C$5,\"N/M\")",
         nf=NF_PCT_SIGNED, font=HEADLINE_FONT, fill=HEADLINE_FILL)
    _set(ws, f"H{r}",
         "=IF(COUNTIF(H13:L13,0)+COUNTIF(H13:L13,0.5)>=2,"
         "\"Comps peak-cycle — defer to DCF\","
         "IF(D49<'Required Return'!$C$5,\"Comps ⇒ OVERVALUED (mid-cycle)\","
         "\"Comps ⇒ UNDERVALUED (mid-cycle)\"))",
         bold=True, fill=HEADLINE_FILL,
         align=Alignment(horizontal="left", vertical="center"))
    ws.row_dimensions[49].height = 24

    # Aesthetic: merge A:B for labels on rows 43-49
    for r in range(43, 50):
        try:
            ws.merge_cells(f"A{r}:B{r}")
        except Exception:
            pass


def _build_consensus(ws) -> None:
    """Rows 51-55: Analyst consensus reference."""
    _style_header_banner(ws, "A51:L51", "ANALYST CONSENSUS REFERENCE")
    _set(ws, "A52", "Average Analyst Price Target", bold=True)
    _set(ws, "C52", f"={_pc(PC_ROW['px_tgt'], MU_COL)}", nf=NF_PRICE)
    _set(ws, "E52", "Implied upside to mkt:", align=Alignment(horizontal="right"))
    _set(ws, "F52",
         f"=({_pc(PC_ROW['px_tgt'], MU_COL)}-'Required Return'!C5)/'Required Return'!C5",
         nf=NF_PCT_SIGNED)
    _set(ws, "A53", "Analyst Consensus Rating", bold=True)
    _set(ws, "C53", f"={_pc(PC_ROW['rating'], MU_COL)}",
         align=Alignment(horizontal="left", vertical="center"))
    _set(ws, "E53", "# Analysts covering:", align=Alignment(horizontal="right"))
    _set(ws, "F53", f"={_pc(PC_ROW['n_analysts'], MU_COL)}", nf=NF_INT)
    _set(ws, "A54", "High / Low Target Range", bold=True)
    _set(ws, "C54",
         f"={_pc(PC_ROW['tgt_lo'], MU_COL)}&\" – \"&{_pc(PC_ROW['tgt_hi'], MU_COL)}",
         align=Alignment(horizontal="left", vertical="center"))
    _set(ws, "A55", "Current Market Price", bold=True)
    _set(ws, "C55", "='Required Return'!C5", nf=NF_PRICE, bold=True)

    for r in [52, 53, 54, 55]:
        try:
            ws.merge_cells(f"A{r}:B{r}")
        except Exception:
            pass
        try:
            ws.merge_cells(f"C{r}:D{r}")
        except Exception:
            pass


def _build_football_field(ws) -> None:
    """Rows 57-68: Football Field — IC-deck range chart with context bars.

    Data rows (v4 layout — 8 bars total):
        59  52-Week Range           (market context; peer_comparison 52W hi/lo)
        60  Two-Stage DCF Range     (fair-value band from Valuation Engine)
        61  Analyst PT Range        (sell-side high/low)
        62  P/E (NTM)               (peer min/max × mid-cycle EPS)
        63  P / Book                (peer min/max × mid-cycle BVPS)
        64  EV / Sales              (peer min/max × mid-cycle revenue, less mid Net Debt)
        65  EV / EBITDA             (peer min/max × mid-cycle EBITDA, less mid Net Debt)
        66  P / FCF                 (uses hidden helper row 68; positive-FCF peers only)

    Each row: Low (col B), High (col C), Point-estimate (col D), Width = C-B (col E),
    Market-price reference (col F). The stacked-bar chart renders cols B (invisible
    base) + E (navy width) with categories from col A.

    v4 changes vs v3:
      • Range = peer MIN / peer MAX of peer multiples (not median±1σ) — cleaner
        convention for 5-peer small-sample sets; no spurious range inflation from
        a single dispersive peer.
      • Added three reference bars (52W, DCF, Analyst PT) above the method bars.
      • Hidden P/FCF peer helper MOVED from row 67 to row 68 so row 66 (last
        method bar) can sit cleanly above it.
    """
    _style_header_banner(ws, "A57:L57",
        "FOOTBALL FIELD  —  Mid-Cycle Implied Price Range  (per method, with context)")

    # Data block header row 58
    _sub_header_row(ws, 58, [
        ("A", "Method / Benchmark"),
        ("B", "Low"), ("C", "High"),
        ("D", "Point"), ("E", "Width"),
        ("F", "Market Price"),
    ])

    SHARES = RR_SHARES
    MKT = RR_PRICE

    # ─── Reference bar rows (59-61) ──────────────────────────────────────
    # Row 59: 52-Week Range (market-context bar)
    pc_52hi = _pc(PC_ROW['hi_52'], MU_COL)
    pc_52lo = _pc(PC_ROW['lo_52'], MU_COL)
    _set(ws, "A59", "52-Week Range", bold=True,
         font=Font(name="Calibri", color="595959", bold=True, size=11),
         align=Alignment(horizontal="left"))
    _set(ws, "B59", f"=IFERROR({pc_52lo},NA())", nf=NF_PRICE)
    _set(ws, "C59", f"=IFERROR({pc_52hi},NA())", nf=NF_PRICE)
    _set(ws, "D59", f"={MKT}", nf=NF_PRICE, bold=True)   # Point = current price
    _set(ws, "E59", "=IFERROR(C59-B59,0)", nf=NF_PRICE, font=BLACK_ITAL)
    _set(ws, "F59", f"={MKT}", nf=NF_PRICE, font=BLACK_ITAL)

    # Row 60: Two-Stage DCF Range (wired to Valuation Engine; IFERROR for robustness)
    _set(ws, "A60", "Two-Stage DCF", bold=True,
         font=Font(name="Calibri", color="1F3864", bold=True, size=11),
         align=Alignment(horizontal="left"))
    _set(ws, "B60", f"=IFERROR({VE_DCF_LOW},NA())", nf=NF_PRICE)
    _set(ws, "C60", f"=IFERROR({VE_DCF_HIGH},NA())", nf=NF_PRICE)
    _set(ws, "D60", f"=IFERROR({VE_DCF_MID},NA())", nf=NF_PRICE, bold=True)
    _set(ws, "E60", "=IFERROR(C60-B60,0)", nf=NF_PRICE, font=BLACK_ITAL)
    _set(ws, "F60", f"={MKT}", nf=NF_PRICE, font=BLACK_ITAL)

    # Row 61: Analyst PT Range (sell-side consensus band)
    pc_tgt_hi = _pc(PC_ROW['tgt_hi'], MU_COL)
    pc_tgt_lo = _pc(PC_ROW['tgt_lo'], MU_COL)
    pc_tgt    = _pc(PC_ROW['px_tgt'], MU_COL)
    _set(ws, "A61", "Analyst PT", bold=True,
         font=Font(name="Calibri", color="595959", bold=True, size=11),
         align=Alignment(horizontal="left"))
    _set(ws, "B61", f"=IFERROR({pc_tgt_lo},NA())", nf=NF_PRICE)
    _set(ws, "C61", f"=IFERROR({pc_tgt_hi},NA())", nf=NF_PRICE)
    _set(ws, "D61", f"=IFERROR({pc_tgt},NA())", nf=NF_PRICE, bold=True)
    _set(ws, "E61", "=IFERROR(C61-B61,0)", nf=NF_PRICE, font=BLACK_ITAL)
    _set(ws, "F61", f"={MKT}", nf=NF_PRICE, font=BLACK_ITAL)

    # ─── Hidden P/FCF peer helper (now row 68, cleared of main football field) ───
    helper_cols = ["H", "I", "J", "K", "L"]
    for i, peer_c in enumerate(PEER_COLS):
        hc = helper_cols[i] if i < len(helper_cols) else helper_cols[-1]
        mkt_ref = _pc(PC_ROW['mkt_cap'], peer_c)
        fcf_ref = _pc(PC_ROW['fcf'], peer_c)
        _set(ws, f"{hc}68",
             f"=IF({fcf_ref}>0,{mkt_ref}/{fcf_ref},\"\")",
             nf=NF_MULT, font=Font(name="Calibri", size=9, color="808080", italic=True))
    _set(ws, "A68", "P/FCF peer helper (auto-filters FCF>0):",
         font=Font(name="Calibri", size=9, color="808080", italic=True),
         align=Alignment(horizontal="right", vertical="center"))
    try:
        ws.merge_cells("A68:G68")
    except Exception:
        pass
    # Hide helper row
    ws.row_dimensions[68].hidden = True
    ws.row_dimensions[68].height = 0

    # P/FCF low/high via helper row 68
    pfcf_min = "MIN(H68:L68)"
    pfcf_max = "MAX(H68:L68)"

    # ─── Method bar rows (62-66) — peer MIN / peer MAX convention ────────
    # Point marker = row 12 (Mid × Median implied price), the primary basis.
    # Range = peer-min to peer-max of the relevant multiple, applied to the
    # mid-cycle driver. Floor at 0 for chart readability (EV numerators can
    # fall below mid Net Debt in extreme troughs).
    peer_pe   = [_pc(PC_ROW['pe_ntm'],   c) for c in PEER_COLS]
    peer_pb   = [_pc(PC_ROW['p_book'],   c) for c in PEER_COLS]
    peer_evr  = [_pc(PC_ROW['ev_rev'],   c) for c in PEER_COLS]
    peer_eve  = [_pc(PC_ROW['ev_ebitda'],c) for c in PEER_COLS]

    def _min(refs): return f"MIN({','.join(refs)})"
    def _max(refs): return f"MAX({','.join(refs)})"

    methods_ff = [
        # (label,       low_mult,          high_mult,         point_cell, driver_cell, kind)
        # kind: "equity" (multiple × driver) / "ev" (adj Net Debt) / "pfcf" (FCF/sh × mult)
        ("P/E (NTM)",   _min(peer_pe),     _max(peer_pe),     "H12", "B6", "equity"),
        ("P / Book",    _min(peer_pb),     _max(peer_pb),     "I12", "C6", "equity"),
        ("EV / Sales",  _min(peer_evr),    _max(peer_evr),    "J12", "D6", "ev"),
        ("EV / EBITDA", _min(peer_eve),    _max(peer_eve),    "K12", "E6", "ev"),
        ("P / FCF",     pfcf_min, pfcf_max,                   "L12", "F6", "pfcf"),
    ]

    for i, (label, low_mult, high_mult, point_cell, driver_cell, kind) in enumerate(methods_ff):
        r = 62 + i   # v4: method bars start at row 62 (was 59 in v3)
        _set(ws, f"A{r}", label, bold=True, align=Alignment(horizontal="left"))
        if kind == "ev":
            low_f  = f"=IFERROR(MAX(({low_mult}*{driver_cell}-{MID_ND_REF})/{SHARES},0),NA())"
            high_f = f"=IFERROR(MAX(({high_mult}*{driver_cell}-{MID_ND_REF})/{SHARES},0),NA())"
        elif kind == "pfcf":
            low_f  = f"=IFERROR(MAX(({driver_cell}/{SHARES})*{low_mult},0),NA())"
            high_f = f"=IFERROR(MAX(({driver_cell}/{SHARES})*{high_mult},0),NA())"
        else:  # equity
            low_f  = f"=IFERROR(MAX({driver_cell}*{low_mult},0),NA())"
            high_f = f"=IFERROR(MAX({driver_cell}*{high_mult},0),NA())"
        _set(ws, f"B{r}", low_f, nf=NF_PRICE)
        _set(ws, f"C{r}", high_f, nf=NF_PRICE)
        _set(ws, f"D{r}", f"={point_cell}", nf=NF_PRICE, bold=True)
        _set(ws, f"E{r}", f"=IFERROR(C{r}-B{r},0)", nf=NF_PRICE, font=BLACK_ITAL)
        _set(ws, f"F{r}", f"={MKT}", nf=NF_PRICE, font=BLACK_ITAL)

    # ─── Chart: stacked horizontal bar, rows 59-66 (8 bars) ──────────────
    chart = BarChart()
    chart.type = "bar"
    chart.style = 11
    chart.grouping = "stacked"
    chart.overlap = 100
    chart.title = "Implied Price Range — Methods & Benchmarks"
    chart.y_axis.title = None
    chart.x_axis.title = "Implied Price ($)"
    chart.legend = None

    # Data extends from row 59 (52W) through row 66 (P/FCF) — 8 rows
    base_data  = Reference(ws, min_col=2, min_row=59, max_col=2, max_row=66)
    width_data = Reference(ws, min_col=5, min_row=59, max_col=5, max_row=66)
    cats       = Reference(ws, min_col=1, min_row=59, max_col=1, max_row=66)

    base_series  = Series(base_data,  title="Base")
    width_series = Series(width_data, title="Range (Low → High)")
    chart.series.append(base_series)
    chart.series.append(width_series)
    chart.set_categories(cats)

    # Base invisible (white fill, white outline). Width = navy. First 3 bars
    # (52W, DCF, Analyst PT) share the navy color — IB convention is to
    # distinguish reference vs methods only via position + label. If the user
    # wants tonal distinction later, vary series fill via DataPoint overrides.
    from openpyxl.chart.shapes import GraphicalProperties as GP
    base_series.graphicalProperties = GP(solidFill="FFFFFF")
    base_series.graphicalProperties.line = LineProperties(solidFill="FFFFFF")
    width_series.graphicalProperties = GP(solidFill=NAVY)
    width_series.graphicalProperties.line = LineProperties(solidFill=NAVY)

    chart.width = 22
    chart.height = 12
    chart.y_axis.delete = False
    chart.x_axis.delete = False
    chart.y_axis.tickLblPos = "low"
    chart.x_axis.tickLblPos = "low"

    ws.add_chart(chart, "H58")

    # Data-block note (moved to row 67 — clear of chart data rows 59-66
    # and above hidden helper row 68)
    _set(ws, "A67",
         "Chart range = peer MIN / peer MAX of trading multiples × mid-cycle driver "
         "(IC-deck small-sample convention). Point marker (col D) = peer-median implied "
         "price (row 12, primary basis). Reference bars (rows 59-61): 52-week range, "
         "Two-Stage DCF fair-value band, and sell-side analyst PT range. "
         "Current market price (col F) is carried per row — add a vertical reference "
         "line at market in PowerPoint when exporting the chart.",
         font=BLACK_ITAL,
         align=Alignment(horizontal="left", vertical="top", wrap_text=True))
    try:
        ws.merge_cells("A67:G67")
    except Exception:
        pass
    ws.row_dimensions[67].height = 36


def _build_methodology(ws) -> None:
    """Rows 69-77: Data exclusions + methodology notes."""
    _style_header_banner(ws, "A69:L69", "DATA EXCLUSIONS & METHODOLOGY")
    # Dynamic peer-ticker _xlfn.TEXTJOIN for Note 1
    peer_ticker_refs = [_pc(PC_ROW["ticker"], c) for c in PEER_COLS]
    target_ticker_ref = _pc(PC_ROW["ticker"], MU_COL)
    peers_textjoin = f"_xlfn.TEXTJOIN(\", \",TRUE,{','.join(peer_ticker_refs)})"

    # Dynamic negative-FCF peer list for Note 5 (tickers with FCF ≤ 0)
    neg_fcf_items = ",".join(
        f"IF({_pc(PC_ROW['fcf'], c)}<=0,{_pc(PC_ROW['ticker'], c)},\"\")"
        for c in PEER_COLS
    )
    neg_fcf_textjoin = f"_xlfn.TEXTJOIN(\", \",TRUE,{neg_fcf_items})"

    # Thresholds pulled live from CONFIG so notes reflect the actual gates.
    half_thr = _cfg("cyclicality_halfwt_threshold", 1.75)
    zero_thr = _cfg("cyclicality_zero_threshold",   3.00)

    # Note 1 and Note 5 are FORMULAS so they update when the peer set / FCF signs change.
    notes = [
        ("formula",
         f"=\"1. Peer group: \"&{peers_textjoin}&\" vs target \"&{target_ticker_ref}"
         f"&\" — peers selected for comparable product & end-market exposure. "
         f"Edit the peer set on the Peer Comparison tab (cols C:G) and this tab re-renders automatically.\""),
        ("text",
         "2. Dual driver basis: Row 5 = live NTM drivers (peak-cycle). Row 6 = mid-cycle cascade driven by "
         "the side block at M4:O10 (YELLOW, editable). Change Revenue factor / EBITDA margin / Net margin / "
         "FCF conversion / Mid-Cycle Net Debt in the side block — Row 6 and every downstream implied price "
         "update live."),
        ("text",
         "3. Primary answer (v4): Row 12 'Mid-Cycle × Peer MEDIAN' is the primary implied-price basis "
         "(bold, highlighted). Row 11 'Mid-Cycle × Peer MEAN' is shown as an italic cross-check. "
         "Row 18 'NORMALIZED BLENDED (Median)' is the IC-deck headline. Row 17 'Face-Value Blended (Peak)' "
         "is the informational peak-cycle upper bound."),
        ("text",
         f"4. Cyclicality guard (symmetric) — applied to row 12 (median-based) mid-cycle implied prices. "
         f"Each method's weight auto-adjusts using MAX(implied/market, market/implied): "
         f"full weight if ≤ {half_thr:.2f}×, half-weight if ≤ {zero_thr:.2f}×, zero if > {zero_thr:.2f}×. "
         f"Catches extreme premium AND extreme discount. Thresholds sourced from dcf_config.CONFIG. "
         f"Weights user-editable (yellow cells, row 13)."),
        ("formula",
         f"=IF(LEN({neg_fcf_textjoin})>0,"
         f"\"5. P/FCF peer set — \"&{neg_fcf_textjoin}&\" excluded (FCF ≤ 0); P/FCF is undefined for non-positive FCF. "
         f"Mean, median, and football-field range are computed on the remaining positive-FCF peers via the hidden "
         f"helper row (row 68) which stores per-peer P/FCF values and is automatically filtered.\","
         f"\"5. P/FCF peer set — all peers have positive FCF; mean, median, and football-field range use the full peer group.\")"),
        ("text",
         "6. Peer outlier watch (P/Book) — row 16 flags methods where peer mean > 2× peer median, signaling "
         "a single-peer distortion. Row 12 (median-based) is already outlier-robust; use row 11 (mean) only "
         "if mean and median are tightly clustered."),
        ("text",
         "7. EV-based multiples (EV/Sales, EV/EBITDA) are weighted most heavily (2.5) — they adjust for "
         "capital structure and are least distorted by cyclical EPS swings. EV bridge uses Mid-Cycle Net "
         "Debt from side-block cell N10 (editable; defaults to live BS Net Debt). Adjust weights in row 13 "
         "per sector context."),
        ("text",
         "8. Implied price formulas: P/E → mid EPS × peer mult;  P/Book → mid BVPS × peer mult;  "
         "EV/Sales & EV/EBITDA → (peer mult × mid driver − Mid Net Debt) / Shares Out;  "
         "P/FCF → (mid FCF / Shares Out) × peer mult. Mid drivers (row 6) cascade from side block M:O."),
        ("text",
         "9. Football field (rows 59–66) — peer MIN / peer MAX × mid-cycle driver per method "
         "(IC-deck small-sample convention; cleaner than median±σ on 5 peers). Reference bars above "
         "the method stack: row 59 52-week range, row 60 Two-Stage DCF fair-value band, row 61 sell-side "
         "analyst PT range. Implied prices floored at $0 to guard EV negatives."),
        ("text",
         "10. All multiples reference 'Peer Comparison' tab live (rows 4–33, cols B:G); rebuilding this "
         "tab does NOT refresh the underlying market data — run Cell 5 of DCF_Notebook.ipynb "
         "(dcf_refresh.run) first. Peer tickers are discovered dynamically at apply() time; "
         "edit the peer set on Peer Comparison row 3 and rebuild."),
        ("text",
         "11. Portable by design — identity, peer set, mid-cycle factors, and cyclicality thresholds "
         "all live in dcf_config.CONFIG. No per-company assumptions are hard-coded in this module. "
         "To re-point the model at a new ticker, edit dcf_config.py and rerun dcf_refresh + "
         "relative_valuation.apply()."),
        ("text",
         "12. Audit directive — every line gets eyeballed. Run relative_valuation.audit() to print "
         "the FORMAT & RAW VALUE audits."),
    ]
    for i, (kind, txt) in enumerate(notes):
        r = 70 + i
        _set(ws, f"A{r}", txt,
             font=BLACK_FONT,
             align=Alignment(horizontal="left", vertical="top", wrap_text=True))
        ws.merge_cells(f"A{r}:L{r}")
        ws.row_dimensions[r].height = 32 if (kind == "text" and len(txt) > 130) else 28


def _build_supplementary_charts(ws) -> None:
    """Rows 82-105: IB-standard supplementary visuals.

    Block A (rows 82-92): 'Multiples Comparison' — Target vs Peer Mean vs Peer Median
        across P/E, P/Book, EV/Sales, EV/EBITDA, P/FCF.  Clustered column chart.
    Block B (rows 94-105): 'Premium / (Discount) to Peers' — horizontal bar chart
        driven directly off the Premium/Discount section (H35:I38).
    """
    # ── Block A: Multiples Comparison ──────────────────────────────────
    _style_header_banner(ws, "A82:L82",
        "MULTIPLES COMPARISON  —  Target vs Peer Mean vs Peer Median")

    target_ticker_ref = _pc(PC_ROW["ticker"], MU_COL)

    _sub_header_row(ws, 83, [
        ("A", "Method"), ("B", "Target"),
        ("C", "Peer Mean"), ("D", "Peer Median"),
    ])
    # Dynamic target column header
    th = ws["B83"]
    th.value = f"={target_ticker_ref}"
    th.font = Font(name="Calibri", color="FFFFFF", bold=True, size=10)
    th.fill = NAVY_FILL
    th.alignment = Alignment(horizontal="center", vertical="center")
    th.border = BORDER

    mc_methods = [
        ("P/E (NTM)",    PC_ROW["pe_ntm"]),
        ("P / Book",     PC_ROW["p_book"]),
        ("EV / Sales",   PC_ROW["ev_rev"]),
        ("EV / EBITDA",  PC_ROW["ev_ebitda"]),
    ]
    for i, (label, pc_r) in enumerate(mc_methods):
        r = 84 + i
        _set(ws, f"A{r}", label, bold=True, align=Alignment(horizontal="left"))
        _set(ws, f"B{r}", f"={_pc(pc_r, MU_COL)}", nf=NF_MULT, bold=True,
             fill=HEADLINE_FILL)
        _set(ws, f"C{r}", _avg_formula(pc_r, PEER_COLS), nf=NF_MULT)
        _set(ws, f"D{r}", _med_formula(pc_r, PEER_COLS), nf=NF_MULT)

    # P/FCF row — uses hidden helper row 68 (moved from 67 in v4) so it
    # respects the positive-FCF filter.
    r = 88
    mu_mkt = _pc(PC_ROW["mkt_cap"], MU_COL)
    mu_fcf = _pc(PC_ROW["fcf"], MU_COL)
    _set(ws, f"A{r}", "P / FCF", bold=True, align=Alignment(horizontal="left"))
    _set(ws, f"B{r}",
         f"=IFERROR(IF({mu_fcf}>0,{mu_mkt}/{mu_fcf},\"N/M\"),\"N/M\")",
         nf=NF_MULT_FLAG, bold=True, fill=HEADLINE_FILL)
    _set(ws, f"C{r}", "=IFERROR(AVERAGE(H68:L68),\"N/M\")", nf=NF_MULT_FLAG)
    _set(ws, f"D{r}", "=IFERROR(MEDIAN(H68:L68),\"N/M\")", nf=NF_MULT_FLAG)

    # Clustered column chart — Target vs Peer Mean vs Peer Median
    mc_chart = BarChart()
    mc_chart.type = "col"
    mc_chart.style = 11
    mc_chart.grouping = "clustered"
    mc_chart.title = "Multiples — Target vs Peer Group"
    # Drop redundant axis titles — categories are self-labeling ("P/E (NTM)", etc.)
    # and the 'x' suffix on values already communicates units.
    mc_chart.y_axis.title = None
    mc_chart.x_axis.title = None
    mc_chart.legend.position = "r"
    # Force category labels below the plot area (not at zero-line).
    mc_chart.x_axis.tickLblPos = "low"

    # Exclude P/FCF row from chart data — P/FCF multiples can run 60–170×
    # while P/E, P/Book, EV/Sales, EV/EBITDA sit 2–30×. Mixing them on one
    # linear axis destroys readability. P/FCF stays in the TABLE (row 88)
    # for reference; chart covers rows 84-87 only.
    data_ref = Reference(ws, min_col=2, min_row=83, max_col=4, max_row=87)
    cats_ref = Reference(ws, min_col=1, min_row=84, max_col=1, max_row=87)
    mc_chart.add_data(data_ref, titles_from_data=True)
    mc_chart.set_categories(cats_ref)

    # Colors: target = navy, mean = mid-blue, median = grey
    palette = [NAVY, "5B9BD5", "A6A6A6"]
    for idx, ser in enumerate(mc_chart.series):
        color = palette[idx % 3]
        ser.graphicalProperties = GraphicalProperties(solidFill=color)
        ser.graphicalProperties.line = LineProperties(solidFill=color)

    mc_chart.width = 20
    mc_chart.height = 9
    mc_chart.y_axis.delete = False
    mc_chart.x_axis.delete = False
    # Rotate x-axis category labels -30° so "P / Book", "EV / Sales", etc.
    # don't overlap each other at 4 categories × 3 series clustered.
    from openpyxl.chart.text import RichText
    from openpyxl.drawing.text import (
        Paragraph, ParagraphProperties, CharacterProperties,
        RichTextProperties,
    )
    mc_chart.x_axis.txPr = RichText(
        bodyPr=RichTextProperties(rot=-1800000, vert="horz"),
        p=[Paragraph(pPr=ParagraphProperties(defRPr=CharacterProperties()))],
    )
    ws.add_chart(mc_chart, "F83")

    # ── Block B: Premium / (Discount) bar chart ────────────────────────
    # Moved to row 104+ to clear the MC chart footprint (F83 + height 9 ≈ row 100)
    _style_header_banner(ws, "A104:L104",
        "PREMIUM / (DISCOUNT) vs PEER GROUP  —  visual summary")

    _sub_header_row(ws, 105, [
        ("A", "Metric"),
        ("B", "vs Peer Mean"), ("C", "vs Peer Median"),
    ])

    # Pull the Premium/Discount values already computed in rows 35-38
    pd_labels = [
        ("P/E (NTM)",    35),
        ("EV / EBITDA",  36),
        ("EV / Revenue", 37),
        ("P / Book",     38),
    ]
    for i, (label, src_row) in enumerate(pd_labels):
        r = 106 + i
        _set(ws, f"A{r}", label, bold=True, align=Alignment(horizontal="left"))
        _set(ws, f"B{r}",
             f"=IFERROR(IF(ISNUMBER(H{src_row}),H{src_row},NA()),NA())",
             nf=NF_PCT_SIGNED)
        _set(ws, f"C{r}",
             f"=IFERROR(IF(ISNUMBER(I{src_row}),I{src_row},NA()),NA())",
             nf=NF_PCT_SIGNED)

    # VERTICAL column chart (not horizontal bar). Horizontal bar charts in
    # openpyxl don't correctly respect tickLblPos="low", so category labels
    # float at the zero-line right on top of the bars — unreadable.
    # Vertical columns keep category labels cleanly at the bottom, values
    # on the left, and negative bars extend downward from zero — standard
    # IB convention for premium/discount-vs-benchmark comparisons.
    pd_chart = BarChart()
    pd_chart.type = "col"
    pd_chart.style = 11
    pd_chart.grouping = "clustered"
    pd_chart.title = "Target Premium / (Discount) to Peers"
    pd_chart.y_axis.title = None
    pd_chart.x_axis.title = None
    pd_chart.legend.position = "r"
    # Force x-axis category labels to the bottom edge (not at the zero-line,
    # which on a column chart would be in the middle of the plot area).
    pd_chart.x_axis.tickLblPos = "low"

    pd_data = Reference(ws, min_col=2, min_row=105, max_col=3, max_row=109)
    pd_cats = Reference(ws, min_col=1, min_row=106, max_col=1, max_row=109)
    pd_chart.add_data(pd_data, titles_from_data=True)
    pd_chart.set_categories(pd_cats)

    pd_palette = [NAVY, "A6A6A6"]
    for idx, ser in enumerate(pd_chart.series):
        color = pd_palette[idx % 2]
        ser.graphicalProperties = GraphicalProperties(solidFill=color)
        ser.graphicalProperties.line = LineProperties(solidFill=color)

    # Rotate x-axis labels −30° for room (4 categories × 2 clustered series).
    pd_chart.x_axis.txPr = RichText(
        bodyPr=RichTextProperties(rot=-1800000, vert="horz"),
        p=[Paragraph(pPr=ParagraphProperties(defRPr=CharacterProperties()))],
    )

    pd_chart.width = 20
    pd_chart.height = 9
    pd_chart.y_axis.delete = False
    pd_chart.x_axis.delete = False
    ws.add_chart(pd_chart, "F105")

    # Interpretation note
    _set(ws, "A113",
         "Negative = target trades at a DISCOUNT to peers (favorable on P/E, EV/EBITDA, "
         "EV/Rev, P/Book — LOW-is-good metrics). Positive = target trades at a PREMIUM. "
         "Bars reference the Premium/(Discount) section (rows 35–38); update live with peer set.",
         font=BLACK_ITAL,
         align=Alignment(horizontal="left", vertical="top", wrap_text=True))
    try:
        ws.merge_cells("A113:L113")
    except Exception:
        pass
    ws.row_dimensions[113].height = 32


def _set_column_widths(ws) -> None:
    # Widths tuned for every section's content:
    #   A — Method / Line-item labels (widest)
    #   B — Drivers (row 5/6) / MC-Target / PD-vs-Mean  → 13 (fits "vs Peer Mean")
    #   D — Summary "Mid-Cycle Implied" header          → 18 (was truncating at 14)
    #   F — Summary "Contribution"                       → 13
    #   G — Summary "Mid vs Market" / PD "Peer Median"  → 16
    #   M/N/O — Side-block assumption rows (set in _build_mid_cycle_side_block)
    widths = {"A": 38, "B": 13, "C": 14, "D": 18, "E": 12, "F": 13,
              "G": 16, "H": 15, "I": 14, "J": 14, "K": 13, "L": 14,
              "M": 24, "N": 12, "O": 14}
    for col, w in widths.items():
        ws.column_dimensions[col].width = w


def _enforce_black_font_and_strip_themes(ws) -> None:
    for row in ws.iter_rows(min_row=1, max_row=ws.max_row,
                            min_col=1, max_col=ws.max_column):
        for cell in row:
            try:
                fg = cell.fill.fgColor.rgb if cell.fill and cell.fill.fgColor else None
            except Exception:
                fg = None
            if fg and fg.upper().endswith(NAVY.upper()):
                continue
            f = cell.font
            cell.font = Font(
                name=f.name or "Calibri",
                size=f.size or 11,
                bold=f.bold,
                italic=f.italic,
                color="000000",
            )


# ─── Audits ────────────────────────────────────────────────────────────
def _format_audit(ws) -> list[str]:
    out = ["",
           "FORMAT AUDIT  —  Relative Valuation",
           "─" * 110,
           f"  {'Coord':<6} {'Value (preview)':<54} {'Number Format':<22} {'Fill':<10} Font",
           "─" * 110]
    for row in ws.iter_rows(min_row=1, max_row=ws.max_row):
        for c in row:
            if c.value is None:
                continue
            val = str(c.value)
            if len(val) > 52:
                val = val[:49] + "..."
            try:
                fill = c.fill.fgColor.rgb if c.fill and c.fill.fgColor else ""
                if isinstance(fill, str) and fill.startswith("00"):
                    fill = "-"
            except Exception:
                fill = "-"
            font_c = c.font.color.rgb if c.font.color else ""
            if not isinstance(font_c, str):
                font_c = ""
            out.append(f"  {c.coordinate:<6} {val:<54} {c.number_format:<22} {str(fill):<10} {font_c}")
    return out


def _raw_value_audit(xlsm_path: str) -> list[str]:
    wb = load_workbook(xlsm_path, keep_vba=True, data_only=True)
    ws = wb["Relative Valuation"]
    out = ["",
           "RAW VALUE AUDIT  —  Relative Valuation (cached values)",
           "─" * 90,
           "NOTE: Excel must be OPENED and SAVED once after rebuild to refresh the cache.",
           "─" * 90]
    key_cells = [
        # ── Side-block mid-cycle assumptions (editable, v4) ──
        ("N5",  "Side-block: Revenue factor"),
        ("N6",  "Side-block: BVPS factor"),
        ("N7",  "Side-block: EBITDA margin (mid)"),
        ("N8",  "Side-block: Net margin (mid)"),
        ("N9",  "Side-block: FCF conversion (mid)"),
        ("N10", "Side-block: Net Debt (mid-cycle, $M)"),
        # ── Driver rows ──
        ("B5",  "Target NTM EPS (peak-cycle)"),
        ("B6",  "Target Mid-Cycle EPS (cascade)"),
        ("C5",  "Target Book Value / Share (peak)"),
        ("C6",  "Target Mid-Cycle BVPS (cascade)"),
        ("D5",  "Target Revenue (peak, $M)"),
        ("D6",  "Target Mid-Cycle Revenue (cascade)"),
        ("E5",  "Target EBITDA (peak, $M)"),
        ("E6",  "Target Mid-Cycle EBITDA (cascade)"),
        ("F5",  "Target FCF (peak, $M)"),
        ("F6",  "Target Mid-Cycle FCF (cascade)"),
        # ── Peer multiples ──
        ("H7",  "Peer Mean P/E (NTM)"),
        ("H8",  "Peer Median P/E (NTM)"),
        ("I7",  "Peer Mean P/Book"),
        ("I8",  "Peer Median P/Book"),
        ("J7",  "Peer Mean EV/Sales"),
        ("K7",  "Peer Mean EV/EBITDA"),
        ("L7",  "Peer Mean P/FCF (pos. only)"),
        # ── Implied prices: row 11 cross-check (mean), row 12 PRIMARY (median) ──
        ("H9",  "Peak Implied — P/E (Mean)"),
        ("H11", "Cross-check: Mid × Mean — P/E"),
        ("H12", "★ PRIMARY Mid × Median — P/E"),
        ("I12", "★ PRIMARY Mid × Median — P/Book"),
        ("J12", "★ PRIMARY Mid × Median — EV/Sales"),
        ("K12", "★ PRIMARY Mid × Median — EV/EBITDA"),
        ("L12", "★ PRIMARY Mid × Median — P/FCF"),
        # ── Weights, blends ──
        ("H13", "Weight — P/E"),
        ("I13", "Weight — P/Book"),
        ("J13", "Weight — EV/Sales"),
        ("K13", "Weight — EV/EBITDA"),
        ("L13", "Weight — P/FCF"),
        ("H17", "FACE-VALUE BLENDED (Peak × Mean)"),
        ("H18", "★ NORMALIZED BLENDED (Mid × Median) — HEADLINE"),
        ("L17", "Peak Blend Prem/(Disc)"),
        ("L18", "★ Mid-Cycle Blend Prem/(Disc)"),
        # ── Summary + consensus ──
        ("C49", "Summary — Peak Weighted Avg"),
        ("D49", "★ Summary — Mid × Median Weighted Avg"),
        ("G49", "Summary — vs Market"),
        ("H49", "Summary — Verdict"),
        ("C52", "Analyst Avg Price Target"),
        ("F52", "Analyst Upside to Market"),
        ("C55", "Current Market Price"),
        # ── Football field v4 layout ──
        ("B59", "Football Field — 52W Low"),
        ("C59", "Football Field — 52W High"),
        ("B60", "Football Field — DCF Low"),
        ("C60", "Football Field — DCF High"),
        ("D60", "Football Field — DCF Central"),
        ("B61", "Football Field — Analyst PT Low"),
        ("C61", "Football Field — Analyst PT High"),
        ("B62", "Football Field — P/E Low"),
        ("C62", "Football Field — P/E High"),
        ("D62", "Football Field — P/E Point (median)"),
        ("B66", "Football Field — P/FCF Low"),
        ("C66", "Football Field — P/FCF High"),
    ]
    for coord, label in key_cells:
        v = ws[coord].value
        if isinstance(v, float):
            if any(k in label for k in ("Price","EBITDA","Revenue","EPS","FCF","Book","Implied","BLENDED","Weighted Avg","Target","Market","Low","High")):
                disp = f"${v:,.2f}" if abs(v) < 1e5 else f"${v:,.0f}"
            elif "%" in label or "Disc" in label or "Upside" in label:
                disp = f"{v:+.1%}"
            elif "Weight" in label:
                disp = f"{v:.2f}"
            else:
                disp = f"{v:,.2f}x" if v else f"{v}"
        else:
            disp = str(v)
        out.append(f"  {coord:<5} {label:<46} → {disp}")
    return out


# ─── Public API ────────────────────────────────────────────────────────
def apply(xlsm_path: str | None = None, verbose: bool = True) -> str:
    """Rebuild the Relative Valuation tab end-to-end.

    Pipeline:
      1. Auto-detect the workbook if no path given.
      2. Validate upstream dependencies (Peer Comparison / Required Return / BS).
      3. DISCOVER the active peer set dynamically from Peer Comparison!C3:G3.
      4. Clear + rebuild every section.
      5. Print FORMAT AUDIT + RAW VALUE AUDIT (raw values cached after Excel save).

    CONFIG-driven: every company-specific assumption (ticker, peers, mid-cycle
    factors, cyclicality thresholds) lives in dcf_config.CONFIG. Edit there
    to re-point at a new company; this module needs no edits.
    """
    global PEER_COLS, ALL_COLS

    if xlsm_path is None:
        xlsm_path = _auto_detect_workbook()

    wb = load_workbook(xlsm_path, keep_vba=True)

    # Fail-fast validation — catch missing upstream tabs / ticker before we
    # destructively clear the RV tab. Raises RuntimeError with actionable
    # message if anything required is missing.
    _validate_inputs(wb)

    # Dynamic peer discovery — the source of truth for the peer set is the
    # Peer Comparison tab itself (populated by dcf_refresh.run). We read it
    # here and cascade through every builder via module globals. This means
    # you can drop a new ticker into CONFIG.peers, rerun dcf_refresh, and
    # this tab renders against the new peer set — no edits to this module.
    pc_ws = wb["Peer Comparison"]
    PEER_COLS = _discover_peers(pc_ws)
    ALL_COLS  = [MU_COL] + PEER_COLS

    if "Relative Valuation" not in wb.sheetnames:
        ws = wb.create_sheet("Relative Valuation", index=3)
    else:
        ws = wb["Relative Valuation"]

    _clear_rv_tab(ws)
    _build_header(ws)
    _build_mid_cycle_side_block(ws)        # NEW (v4): feeds Row 6 cascade
    _build_implied_valuation(ws)
    _build_peer_detail(ws)
    _build_premium_discount(ws)
    _build_valuation_summary(ws)
    _build_consensus(ws)
    _build_football_field(ws)
    _build_methodology(ws)
    _build_supplementary_charts(ws)
    _set_column_widths(ws)
    _enforce_black_font_and_strip_themes(ws)

    ws.freeze_panes = "A4"
    ws.sheet_view.showGridLines = False

    wb.save(xlsm_path)

    if verbose:
        target = pc_ws[f"{MU_COL}{PC_ROW['ticker']}"].value or "(unknown)"
        peers_list = ", ".join(
            str(pc_ws[f"{c}{PC_ROW['ticker']}"].value or "?") for c in PEER_COLS
        )
        cfg_src = "dcf_config.CONFIG" if _CONFIG_LOADED else "fallback defaults"
        print(
            "✓ Relative Valuation rebuilt (v4: median-primary + cascade + IC polish) — "
            f"saved to {xlsm_path}"
        )
        print(f"  Target: {target}   |   Peers ({len(PEER_COLS)}): {peers_list}   |   Config: {cfg_src}")
        for line in _format_audit(ws):
            print(line)
        for line in _raw_value_audit(xlsm_path):
            print(line)
    return xlsm_path


def audit(xlsm_path: str | None = None) -> None:
    if xlsm_path is None:
        xlsm_path = _auto_detect_workbook()
    wb = load_workbook(xlsm_path, keep_vba=True)
    ws = wb["Relative Valuation"]
    for line in _format_audit(ws):
        print(line)
    for line in _raw_value_audit(xlsm_path):
        print(line)


if __name__ == "__main__":
    apply()
