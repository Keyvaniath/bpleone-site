"""
cff_forecast.py — Rebuild Cash Flow Forecast forecast-year driver ratios
from historical averages × CONFIG mid-cycle factors.

WHY THIS EXISTS (B1 in the audit punch-list)
────────────────────────────────────────────
The original template shipped with HARDCODED forecast-year ratios in:
    • Cash Flow Forecast!B60:F60   (CapEx % Sales, FY+1..FY+5)
    • Cash Flow Forecast!B62:F62   (NWC  % Sales, FY+1..FY+5)

Those five-year decay paths were tuned by hand for Micron's FY+1..FY+5
window. When the template is repointed to another ticker, they do NOT
auto-refresh — they stay frozen at MU's reinvestment profile, which
silently poisons every downstream FCF, EBITDA, and terminal calc.

This module fixes that by wiring B60:F60 and B62:F62 to Excel formulas
that reference the historical averages at H31 (CapEx/Sales) and H33
(NWC/Sales), then linearly interp toward a "mid-cycle" target defined
by CONFIG.capex_mid_cycle_factor and CONFIG.nwc_mid_cycle_factor.

    ratio_k = H31 * (1 + (k/5) * (factor - 1))     k = 1..5

So for a capital-light software name where forecast capex should decay
to 40% of recent history, set capex_mid_cycle_factor = 0.40 in CONFIG
and the five forecast years will ramp 100% → 88% → 76% → 64% → 52% → 40%
of the historical average. For a cyclical semis name holding steady,
keep factor=1.0 (ratios equal historical avg for all 5 years).

USAGE
─────
Called once at the end of the notebook pipeline, after refresh_data()
and after required_return.apply(). Idempotent — safe to re-run.

    import cff_forecast
    cff_forecast.apply("DCF_Final.xlsm")
"""
from __future__ import annotations
import os
from typing import Tuple
from openpyxl import load_workbook


# Rows on the Cash Flow Forecast tab that we rewrite.
# Column layout: B = Y1, C = Y2, D = Y3, E = Y4, F = Y5.
CAPEX_ROW   = 60   # "CapEx % of Sales Forecast (see avg. H31)"
NWC_ROW     = 62   # "NWC % of Sales Forecast (see avg. H33)"
CAPEX_HIST  = "$H$31"
NWC_HIST    = "$H$33"

# Canonical "see avg. H##" labels we re-write so the user sees exactly
# what drives the forecast.
CAPEX_LABEL = "CapEx % of Sales Forecast  (avg H31 × CONFIG.capex_mid_cycle_factor)"
NWC_LABEL   = "NWC % of Sales Forecast   (avg H33 × CONFIG.nwc_mid_cycle_factor)"


def _interp_formula(hist_ref: str, factor: float, k: int, n_years: int = 5) -> str:
    """
    Build the Excel formula for year k (1-indexed) that linearly
    interpolates from the historical-average ratio to
    hist_ref * factor over n_years.

        ratio_k = hist_ref * (1 + (k/n) * (factor - 1))
    """
    # Guard: factor == 1 → just the historical average, no drift.
    if abs(factor - 1.0) < 1e-9:
        return f"={hist_ref}"
    frac = k / n_years
    # Excel-safe formula; parentheses to avoid operator-precedence bugs.
    return f"={hist_ref}*(1+({frac:.6f}*({factor:.6f}-1)))"


def _write_row(ws, row: int, label: str, hist_ref: str, factor: float,
               rationale_col: str = "G") -> None:
    """Overwrite columns A..G on the given forecast row."""
    ws.cell(row, 1).value = label
    for k, col_letter in enumerate(["B", "C", "D", "E", "F"], start=1):
        ws[f"{col_letter}{row}"] = _interp_formula(hist_ref, factor, k)
    ws[f"{rationale_col}{row}"] = "formula-linked — edit CONFIG, not cells"


def apply(workbook_path: str) -> Tuple[float, float]:
    """
    Rewrite CFF!B60:F60 and B62:F62 as formulas tied to historical
    averages and CONFIG factors. Returns (capex_factor, nwc_factor)
    that were applied, so the caller can log them.
    """
    # Late import so this module stays usable standalone if a user
    # points it at a custom workbook without touching dcf_config.
    #
    # Audit #5 (Apr-2026): factors are now Optional[float]. If a CONFIG
    # field is None, resolve it from CONFIG.sector via SECTOR_PRESETS so
    # each sector gets a industry-defensible default without requiring the
    # analyst to hand-set the factor on every repoint. An explicit float
    # in CONFIG always overrides the sector-derived value.
    try:
        from dcf_config import CONFIG, resolve_mid_cycle_factors
        cfg_capex = getattr(CONFIG, "capex_mid_cycle_factor", None)
        cfg_nwc   = getattr(CONFIG, "nwc_mid_cycle_factor",   None)
        sector = getattr(CONFIG, "sector", "") or ""

        if cfg_capex is None or cfg_nwc is None:
            sector_capex, sector_nwc, rationale = resolve_mid_cycle_factors(sector)
            capex_factor = float(cfg_capex) if cfg_capex is not None else sector_capex
            nwc_factor   = float(cfg_nwc)   if cfg_nwc   is not None else sector_nwc
            print(f"  ✓  cff_forecast: sector='{sector}' → "
                  f"CapEx factor {capex_factor:.2f}, NWC factor {nwc_factor:.2f}")
            print(f"     rationale: {rationale}")
        else:
            capex_factor = float(cfg_capex)
            nwc_factor   = float(cfg_nwc)
            print(f"  ✓  cff_forecast: explicit CONFIG override — "
                  f"CapEx factor {capex_factor:.2f}, NWC factor {nwc_factor:.2f}")
    except Exception as e:
        print(f"  ⚠  cff_forecast: could not load CONFIG ({e}). Using factor=1.0.")
        capex_factor = 1.0
        nwc_factor   = 1.0

    if not os.path.exists(workbook_path):
        raise FileNotFoundError(f"Workbook not found: {workbook_path}")

    wb = load_workbook(workbook_path, keep_vba=True)
    if "Cash Flow Forecast" not in wb.sheetnames:
        print("  ⚠  cff_forecast: 'Cash Flow Forecast' tab missing — skipped.")
        return (capex_factor, nwc_factor)

    ws = wb["Cash Flow Forecast"]

    _write_row(ws, CAPEX_ROW, CAPEX_LABEL, CAPEX_HIST, capex_factor)
    _write_row(ws, NWC_ROW,   NWC_LABEL,   NWC_HIST,   nwc_factor)

    wb.save(workbook_path)
    print(f"  ✓  Cash Flow Forecast drivers rebuilt:")
    print(f"       CapEx/Rev  FY+1..FY+5  = H31 × [{_ramp_str(capex_factor)}]")
    print(f"       NWC/Rev    FY+1..FY+5  = H33 × [{_ramp_str(nwc_factor)}]")
    return (capex_factor, nwc_factor)


def _ramp_str(factor: float) -> str:
    """Pretty-print the 5-year multiplier ramp for logging."""
    if abs(factor - 1.0) < 1e-9:
        return "1.00, 1.00, 1.00, 1.00, 1.00"
    pts = [1 + (k / 5) * (factor - 1) for k in range(1, 6)]
    return ", ".join(f"{p:.2f}" for p in pts)


if __name__ == "__main__":
    import sys
    path = sys.argv[1] if len(sys.argv) > 1 else "DCF_Final.xlsm"
    apply(path)
