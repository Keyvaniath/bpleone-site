"""
dcf_config.py — Central configuration for the portable DCF template.

This is the ONLY file you need to edit to repoint the model at a new company.
Everything downstream (dcf_refresh.py, ib_fixes.py, the notebook, and the
workbook Cover tab) reads from this module.

USAGE
─────
1. Edit the CONFIG dict below (or build a new one via DCFConfig(...)).
2. In the notebook Cell 2, simply do:
       from dcf_config import CONFIG
       TARGET = CONFIG.ticker
       PEERS  = CONFIG.peers
3. ib_fixes.apply() will pick up CONFIG automatically.

The defaults below describe Micron (MU) so the existing workbook keeps working
with no edits. Swap the values to move to any other public company.
"""
from __future__ import annotations
import re
from dataclasses import dataclass, field
from typing import List, Optional, Tuple


# ═══════════════════════════════════════════════════════════════════════════
#  SECTOR_PRESETS — mid-cycle factor matrix (Audit #5)
# ═══════════════════════════════════════════════════════════════════════════
#
# Each row maps a sector pattern (regex, case-insensitive) to defensible
# (capex_factor, nwc_factor) defaults. The first matching pattern wins.
# Used by cff_forecast.py when CONFIG.capex_mid_cycle_factor is None.
#
# IB context: cyclical capital-heavy names at the peak (memory, oil
# E&P, autos) should taper CapEx toward through-cycle averages. Capital-
# light names (software, consumer brands) project flat. Defensive utilities
# project flat or slightly above (steady reinvestment).
#
# When repointing, set CONFIG.sector to something descriptive — the regex
# will match and pick a reasonable default. If no pattern matches, falls
# through to the "default" row (1.00 / 1.00) and prints a soft warning.
SECTOR_PRESETS: List[Tuple[str, float, float, str]] = [
    # (sector regex, capex factor, nwc factor, rationale)
    (r"memory|hbm|dram|nand",                 0.75, 0.85,
        "Memory/Storage — peak HBM cycle digesting; CapEx tapers ~25% over 5Y, "
        "NWC eases as inventory cycles normalize."),
    (r"semiconductor|semis|fab|foundry",      0.85, 0.90,
        "Semis (broad) — mid-cycle reinvestment; modest CapEx/NWC taper."),
    (r"oil|gas|energy|e&p|exploration",       0.80, 0.95,
        "Energy / E&P — commodity cycle; CapEx normalizes toward through-cycle "
        "DD&A coverage."),
    (r"auto|automotive|vehicle|truck",        0.90, 0.95,
        "Autos — cyclical with platform refresh CapEx; modest taper."),
    (r"steel|metal|mining|chemical",          0.85, 0.95,
        "Heavy industrials — through-cycle CapEx normalization."),
    (r"airline|airlines|aerospace|defense",   0.95, 1.00,
        "Aerospace/Defense — fleet renewal CapEx near mid-cycle."),
    (r"reit|real estate|property",            0.95, 1.05,
        "REITs — maintenance CapEx steady; receivables/payables grow with portfolio."),
    (r"util|utility|utilities|power",         1.00, 1.00,
        "Utilities — regulated CapEx schedule; flat."),
    (r"telecom|wireless|cable",               1.05, 1.00,
        "Telecom — 5G/fiber buildout; slight CapEx step-up."),
    (r"bank|financial|insurance",             1.00, 1.00,
        "Financials — minimal CapEx; flat."),
    (r"software|saas|cloud|internet|platform",1.00, 1.00,
        "Software/SaaS — capital-light; no taper."),
    (r"pharma|biotech|drug|medical|health",   1.00, 1.05,
        "Healthcare — R&D intensive but stable CapEx; modest NWC build."),
    (r"consumer|retail|staples|discretion",   1.00, 1.00,
        "Consumer — steady reinvestment."),
    (r"media|entertainment|gaming",           1.00, 1.00,
        "Media — variable but flat as default."),
    # Catch-all — used when no pattern matches CONFIG.sector
    (r".*",                                    1.00, 1.00,
        "Default (no sector match) — flat factors."),
]


def resolve_mid_cycle_factors(sector: str) -> Tuple[float, float, str]:
    """Return (capex_factor, nwc_factor, rationale) for a given sector string.

    Used by cff_forecast.py and ib_fixes.py when
    CONFIG.capex_mid_cycle_factor is None. Case-insensitive substring/regex
    match against SECTOR_PRESETS. Always returns a tuple — falls through
    to the catch-all if nothing matches.
    """
    s = (sector or "").strip()
    for pattern, capex, nwc, rationale in SECTOR_PRESETS:
        if re.search(pattern, s, re.IGNORECASE):
            return capex, nwc, rationale
    return 1.00, 1.00, "Default (empty sector)."


@dataclass
class Segment:
    """One revenue segment in the bottoms-up build."""
    name: str                              # e.g. "DRAM", "Data Center", "iPhone"
    row: int                               # row in Segment Revenue tab (6, 9, 12, ...)
    growth_path: Tuple[float, ...] = ()    # 5Y growth: FY+1 ... FY+5


@dataclass
class DCFConfig:
    """Everything that changes when you swap companies."""

    # ─── Identity ─────────────────────────────────────────────────────
    ticker: str = "MU"
    company_name: str = "MICRON TECHNOLOGY, INC."
    exchange: str = "NASDAQ"
    sector: str = "Semiconductors — Memory"
    currency: str = "USD"

    # Peer set for the Relative Valuation / Peer Comparison tabs
    peers: List[str] = field(default_factory=lambda: [
        "INTC", "AMD", "NVDA", "QCOM", "TXN"
    ])

    # ─── Rating & targets ─────────────────────────────────────────────
    rating: str = "UNDERWEIGHT"            # OVERWEIGHT / NEUTRAL / UNDERWEIGHT
    price_target: float = 120.00
    fair_value_2stage: float = 62.48
    fair_value_weighted: float = 63.21

    # Audit #3 — Consensus Analyst PT fallback for the Cover tab's VLOOKUP
    # on Estimates!A:K (Cover!C19, row labeled "Analyst Price Target —
    # Consensus").  The PRIMARY source is the live VLOOKUP against
    # Estimates!A9 ("Target Price", populated by dcf_refresh from yfinance's
    # targetMeanPrice).  This fallback only fires when that lookup fails —
    # thinly-covered names, yfinance schema drift, API outage.
    #
    # CRITICAL: this is the STREET CONSENSUS target, NOT `price_target`
    # above. `price_target` is OUR firm's rating (e.g. UNDERWEIGHT $120 for
    # MU). Consensus is what the sell-side average is saying (MU ≈ $526).
    # Never chain-fallback to `price_target` — it would display our rating
    # where market consensus belongs, which is semantically wrong on a
    # IB Cover page.
    #
    # For MU: 526.48 preserves the prior hardcoded consensus. Refresh by
    # hand (or pull from yfinance.info['targetMeanPrice']) when repointing.
    # Set to None to emit IFNA(..., "N/A") and make missing data visible.
    analyst_pt_fallback: Optional[float] = 526.48

    # ─── Stage-1 revenue growth (FY+1 ... FY+5) ──────────────────────
    # Written to Cash Flow Forecast!B39:F39.
    # For MU: 28% → 15% → 7% → 4% → 3% (consensus-aligned decay).
    growth_path: Tuple[float, float, float, float, float] = (0.28, 0.15, 0.07, 0.04, 0.03)

    # Stage-2 end growth (VE!B69) — mid-cycle hand-off to terminal
    stage1_end_growth: float = 0.05

    # Terminal growth (VE!H6) — long-run nominal GDP proxy
    terminal_growth: float = 0.025

    # ─── Mid-cycle / normalized-earnings assumptions ─────────────────
    # Used by relative_valuation.py to cascade row-6 drivers from editable
    # margin/conversion assumptions. Defaults are calibrated for MU
    # (memory semis). For different sectors, override these in your CONFIG:
    #   • Software / Consumer Staples: rev_factor ~0.95, margins near NTM.
    #   • Cyclical semis / Memory: rev_factor 0.65–0.75, margins well below NTM.
    #   • Deep cyclicals (steel, autos): rev_factor 0.60–0.70, margins 40–50% of NTM.
    # Each value is a DECIMAL (0.70 = 70%, not 70).
    mid_cycle_revenue_factor:   float = 0.70   # Revenue_mid = Rev_NTM × factor
    mid_cycle_bvps_factor:      float = 1.00   # BVPS_mid = BVPS_NTM × factor (stable)
    mid_cycle_ebitda_margin:    float = 0.32   # EBITDA_mid = Rev_mid × margin  (MU 10Y-avg ~30–35%)
    mid_cycle_net_margin:       float = 0.15   # NI_mid     = Rev_mid × margin  (MU 10Y-avg ~12–18%)
    mid_cycle_fcf_conversion:   float = 0.20   # FCF_mid    = EBITDA_mid × conversion (MU heavy capex)

    # ─── Cash Flow Forecast drivers (B1 — cff_forecast.py) ───────────────────
    # CFF!B62:F62 = CapEx % Revenue:  historical 3Y avg × capex_mid_cycle_factor
    # CFF!B60:F60 = ΔNWC  % Revenue:  historical 3Y avg × nwc_mid_cycle_factor
    # Factor < 1.0  → forecast tapers BELOW historical (mature/harvest mode,
    #                 or peak-cycle company normalizing toward through-cycle).
    # Factor = 1.0  → flat — uses historical avg unchanged.
    # Factor > 1.0  → forecast OVERSHOOTS historical (early-stage build-out,
    #                 cyclical trough company increasing reinvestment).
    #
    # Default = None means "auto-select from CONFIG.sector via SECTOR_PRESETS".
    # If you want to explicitly override (e.g. you disagree with the preset),
    # set a float — that takes precedence over the sector default.
    capex_mid_cycle_factor:    Optional[float] = None  # auto from sector if None
    nwc_mid_cycle_factor:      Optional[float] = None  # auto from sector if None

    # ─── Audit #4 — Explicit analyst-curated ratio fallbacks ─────────────────
    # These values are the FINAL tier in the CFF!H28–H34 fallback hierarchy:
    #   Tier 1: company historical avg (computed from BS/IS/CF)        ← preferred
    #   Tier 2: peer industry avg (computed by dcf_refresh from peers) ← if Tier 1 missing
    #   Tier 3: these CONFIG values (analyst-curated mid-cycle)        ← if Tier 2 missing
    #   Tier 4: Excel "N/A" string                                     ← if CONFIG is None
    #
    # Each value below is documented MU mid-cycle. They are REPLACEMENTS for
    # the magic numbers that previously lived inside the workbook's IFERROR
    # fallbacks (CFF!H28→0.15, H30→0.21, H31→0.30, H32→0.22, H33→0.40, etc.).
    #
    # If you set any of these to None, the formula chain falls through to a
    # visible "N/A" — you'll see it in Excel, and Cell 8 will warn loudly.
    # That's the point: failures must be visible, not silently papered over.
    #
    # When repointing to a new ticker, update these to that ticker's
    # mid-cycle estimates (e.g. for software, capex_to_sales might be 0.05).
    analyst_capex_to_sales:     Optional[float] = 0.30   # MU: HBM ramp ~30%
    analyst_da_to_sales:        Optional[float] = 0.22   # MU 10Y avg
    analyst_nwc_to_sales:       Optional[float] = 0.40   # MU mid-cycle
    analyst_effective_tax:      Optional[float] = 0.21   # MU effective rate
    analyst_interest_to_sales:  Optional[float] = 0.01   # MU interest burden
    analyst_ebit_to_sales:      Optional[float] = 0.20   # MU mid-cycle EBIT margin
    analyst_revenue_growth:     Optional[float] = 0.05   # mid-cycle revenue growth

    # ─── Sanity gate thresholds ──────────────────────────────────────────────
    # B2 — Price reconcile: warn if |EPS×PE / Price − 1| > tolerance.
    price_reconcile_tolerance: float = 0.15

    # B6 — DDM gate: if dividend-per-share < threshold, mark DDM "N/A".
    dividend_min_threshold:    float = 0.10   # $ per share

    # B4 — Scenario ordering: enforce optim_y1 ≥ base_y1 + ε ≥ pessim_y1 + 2ε
    scenario_epsilon:          float = 0.005   # 0.5% minimum spread

    # Scenario Analysis offsets vs Base Case (decimal, additive).
    # Used when no explicit cycle path (pess_rev_path / opt_rev_path) is set —
    # simple Base ± constant. Fine for steady-state businesses (software,
    # staples). For cyclical names (memory, commodities, deep cyclicals),
    # override the *_path fields below with year-by-year calibrated values.
    pess_revenue_offset:       float = -0.02   # Pessimistic = Base − 2 pp
    optim_revenue_offset:      float = +0.02   # Optimistic  = Base + 2 pp
    pess_ebit_offset:          float = -0.04   # Pessimistic = Base − 4 pp
    optim_ebit_offset:         float = +0.03   # Optimistic  = Base + 3 pp

    # ─── Cycle-aware scenario paths (Audit #2 — memory-cycle MD calibration) ──
    # If ANY *_path is set (non-empty 5-tuple), it's used directly instead of
    # the naive ± offset above. This lets cyclical businesses model a
    # trough-and-recovery shape that a flat ± offset can't capture.
    #
    # For MU (memory): Pess = demand digestion + AI saturation + peer supply
    #                  flood; Opt = sustained HBM4 + AI PC/phone TAM + supply
    #                  discipline.
    # For non-cyclicals: leave as None and rely on the ± offsets above.
    pess_rev_path:  Optional[Tuple[float, float, float, float, float]] = (
        0.15, 0.03, -0.05, 0.00, 0.02
    )
    opt_rev_path:   Optional[Tuple[float, float, float, float, float]] = (
        0.35, 0.22, 0.12, 0.08, 0.06
    )
    pess_ebit_path: Optional[Tuple[float, float, float, float, float]] = (
        0.136, 0.07, 0.03, 0.06, 0.11
    )
    opt_ebit_path:  Optional[Tuple[float, float, float, float, float]] = (
        0.344, 0.346, 0.311, 0.313, 0.287
    )

    # CapEx% / NWC% cycle offsets. Pess adds (counter-cyclical capex absorption,
    # inventory bloat). Opt subtracts (operating leverage, lean inventory).
    # Floors prevent unrealistic zeroes in the optimistic case.
    capex_pess_offset:  float = 0.03    # Pess CapEx% = Base + 3pp
    capex_opt_offset:   float = 0.03    # Opt  CapEx% = Base − 3pp
    capex_opt_floor:    float = 0.15    # Opt  CapEx% ≥ 15%
    nwc_pess_offset:    float = 0.02    # Pess NWC%  = Base + 2pp
    nwc_opt_offset:     float = 0.02    # Opt  NWC%  = Base − 2pp
    nwc_opt_floor:      float = 0.20    # Opt  NWC%  ≥ 20%

    # Interest scenario multipliers (symmetric by default).
    interest_pess_mult: float = 1.05    # Pess interest = Base × 1.05
    interest_opt_mult:  float = 0.95    # Opt  interest = Base × 0.95

    # ─── Cyclicality guard thresholds (RV tab Row 13 weight formula) ──
    # MAX(implied/market, market/implied) ratio bands. Weight drops to 0.5
    # between low and high, drops to 0 above high. Tight for peak-cycle semis;
    # loosen for stable-growth businesses.
    cyclicality_halfwt_threshold:  float = 1.75   # implied/market ≤ 1.75× → full weight
    cyclicality_zero_threshold:    float = 3.00   # implied/market ≤ 3.00× → half weight; above → zero

    # ─── Street consensus revenue (Revenue Bridge tab, row 14) ──────
    # Audit #3 — previously the Revenue Bridge tab hardcoded an MU-specific
    # consensus strip (37378, 48000, ..., 61000) that silently drifted when
    # the workbook was repointed. Provide a 6-tuple (FY-1A, FY+1E ... FY+5E)
    # in dollars millions to populate the Consensus row. Leave as None to
    # blank the row with "N/A" — the tab still renders cleanly.
    consensus_revenue: Optional[Tuple[float, float, float, float, float, float]] = (
        37378.0, 48000.0, 54500.0, 57000.0, 59000.0, 61000.0
    )

    # ─── Segment build ────────────────────────────────────────────────
    # One dict per reported segment. growth_path is FY+1..FY+5.
    # For MU: DRAM, HBM, NAND. Rows match the Segment Revenue tab template.
    # For a non-semis company, re-label and re-row these OR pass
    # `segments=[]` to skip the segment override entirely.
    segments: List[Segment] = field(default_factory=lambda: [
        Segment(name="DRAM", row=6,  growth_path=(0.30, 0.16, 0.07, 0.04, 0.03)),
        Segment(name="HBM",  row=9,  growth_path=(1.20, 0.60, 0.30, 0.15, 0.08)),
        Segment(name="NAND", row=12, growth_path=(0.20, 0.12, 0.05, 0.03, 0.03)),
    ])

    # ─── Narrative strings for Cover tab thesis bullets ──────────────
    # Keep to 8 short lines. Use {company} / {ticker} placeholders and they
    # will be .format()-substituted at write time.
    thesis_lines: List[str] = field(default_factory=lambda: [
        "1. DCF SAYS OVERVALUED: Two-Stage DCF fair value of ~${fair_value:.0f} vs "
            "${current_price:.0f} market implies the stock is priced at "
            "~{price_multiple:.1f}x DCF fair value.",
        "2. REVERSE DCF IMPLIES 10% PERPETUAL GROWTH: Market pricing requires {company_short} "
            "to grow terminal FCF at 10%/year forever — structurally unjustifiable.",
        "3. CONSENSUS IS STRETCHED: Street analyst PT embeds peak-cycle assumptions "
            "sustained through 2030 and compressed multiples.",
        "4. SEGMENT VALIDATION: Bottoms-up revenue build reconciles to top-down — "
            "no ghosts in the model.",
        "5. TERMINAL CONCENTRATION: Two-Stage DCF drops TV share to <65% of EV, "
            "passing the desk's terminal-value gate.",
        "6. MARGIN ASSUMPTIONS: Peak EBIT margin decays to mid-cycle through FY30 — "
            "defensible per sector cyclicality.",
        "7. SENSITIVITY: ±10% moves in WACC/margin shift price in a reasonable band.",
        "8. RATING: {rating}. PT ${price_target:.0f} (weighted DCF + multiples with risk adj.).",
    ])

    # Short form of the company name used inside thesis prose
    @property
    def company_short(self) -> str:
        # "MICRON TECHNOLOGY, INC." → "Micron"
        return self.company_name.split(",")[0].split()[0].title()

    @property
    def banner(self) -> str:
        return f"{self.company_name}  ({self.exchange}: {self.ticker})"


# ───────────────────────────────────────────────────────────────────────
# DEFAULT CONFIG — edit here, or import DCFConfig and build your own.
# ───────────────────────────────────────────────────────────────────────
CONFIG = DCFConfig()


# ── Example: repoint at NVIDIA ─────────────────────────────────────────
# from dcf_config import DCFConfig, Segment
# CONFIG = DCFConfig(
#     ticker="NVDA",
#     company_name="NVIDIA CORPORATION",
#     exchange="NASDAQ",
#     sector="Semiconductors — Accelerators",
#     peers=["AMD", "INTC", "AVGO", "QCOM", "MRVL"],
#     rating="NEUTRAL",
#     price_target=145.00,
#     growth_path=(0.55, 0.25, 0.12, 0.08, 0.05),
#     segments=[
#         Segment("Data Center", 6, (0.70, 0.30, 0.15, 0.08, 0.05)),
#         Segment("Gaming",      9, (0.10, 0.08, 0.06, 0.05, 0.04)),
#         Segment("Auto/Other", 12, (0.40, 0.25, 0.15, 0.10, 0.08)),
#     ],
# )
