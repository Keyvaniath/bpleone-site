#!/usr/bin/env bash
#
# DCF Template — One-command setup for macOS / Linux.
# Usage:  ./setup.sh
#
# Installs Python dependencies and launches the notebook.

set -e

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  DCF Template — Universal Edition (v4)"
echo "  Setup running..."
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# Verify Python 3.10+
python3 -c 'import sys; assert sys.version_info >= (3,10), f"Python 3.10+ required, got {sys.version}"'
echo "  ✓ Python $(python3 --version | awk '{print $2}')"

# Install requirements
echo "  Installing dependencies (yfinance, openpyxl, pandas, jupyter)..."
python3 -m pip install -r requirements.txt --quiet
echo "  ✓ Dependencies installed"

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Setup complete."
echo ""
echo "  Next steps:"
echo "    1. jupyter notebook DCF_Notebook_v4.ipynb"
echo "    2. Edit Cell 3 with your ticker, peers, rating, PT"
echo "    3. Run all cells (Kernel → Restart & Run All)"
echo "    4. Open DCF_Final.xlsm in Excel"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
