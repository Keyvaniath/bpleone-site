# DCF Template — Analyst Guide

**A working manual for the Universal DCF Template. Built to teach you how to read every tab, defend every number, and pitch like an MD has been doing this for fifteen years.**

---

## Table of contents

**Part I — Getting started**
1. What this template is, and what it isn't
2. Setup — getting from download to first run
3. The 9-step pipeline at a glance
4. The 20 tabs, what each one does

**Part II — Reading the model**
5. The Cover tab — your IC one-pager
6. The Required Return tab — building WACC
7. The Cash Flow Forecast — where the cash flows come from
8. The Valuation Estimates tab — the DCF math
9. The Valuation Summary — the headline picture
10. Scenario Analysis — Pess / Base / Opt
11. Driver Sensitivity — the tornado
12. The Reverse DCF tab — the bear-thesis kill shot
13. Relative Valuation — peer-blended multiples
14. Peer Comparison + Industry tab — the ratio chain
15. Revenue Bridge + Segment Revenue — top-down vs bottoms-up

**Part III — Thinking like an analyst**
16. The four numbers that decide every pitch
17. Nine pitfalls every analyst makes
18. How to defend your call to an MD
19. Worked example — MU UNDERWEIGHT
20. Worked example — NVDA OVERWEIGHT
21. Worked example — KO defensive NEUTRAL

**Part IV — Reference**
22. Glossary
23. Key cell reference table
24. Sector preset matrix

---

# Part I — Getting started

## 1. What this template is, and what it isn't

This template is a **IB-style two-stage DCF** packaged as a Python pipeline + Excel workbook. You give it a ticker, it pulls financial data from yfinance, builds a 10-year forecast, computes intrinsic value four different ways, and writes the answer into a 20-tab Excel file ready for an Investment Committee meeting.

**What you get:**

- A Two-Stage DCF (5-year explicit + 5-year stage-2 + Gordon perpetuity terminal)
- Three explicit scenarios (Pessimistic / Base / Optimistic)
- Multiples valuation (P/E, P/B, EV/Sales, EV/EBITDA, P/FCF — peer-blended)
- A Reverse DCF that quantifies what the market's price implies
- WACC built from scratch with Damodaran ERP, beta blend, and a sanity gate
- Sensitivity tables across WACC × terminal growth and EBIT margin × CapEx %
- A live driver-sensitivity tornado tied to every key input
- Peer comparison across 32 metrics
- Live data — no manual entry — refreshed every run

**What it is not:**

- It is **not a stock-picker.** It tells you what a company is worth under your assumptions. If your assumptions are wrong, the answer is wrong.
- It is **not an oracle.** A DCF cannot price M&A optionality, regulatory shifts, demand inflection, AI revolutions, or "this time is different." The Reverse DCF tab tells you when the market is pricing one of those things.
- It is **not a substitute for industry knowledge.** The template can compute MU's 5-year average CapEx/Sales of 41%, but only you can decide whether that ratio is structural (memory needs huge fab investment forever) or cyclical (HBM ramp is a 3-year peak).

If you treat this as a calculator, you'll get a number. If you treat it as a framework for thinking through every assumption, you'll get an investment thesis.

---

## 2. Setup — getting from download to first run

### What you need

- Python 3.10 or later. Free from python.org. On Windows, check "Add Python to PATH" during install.
- Microsoft Excel or LibreOffice. The workbook is `.xlsm` (with macros — keep them enabled when Excel asks).
- An internet connection. yfinance pulls live data each time.
- 5 minutes for first-time setup, ~60 seconds per refresh after that.

### One-time setup

1. Download `dcf_template_v4.zip` and unzip anywhere on your computer.
2. Open a terminal in the unzipped folder.
3. **Mac/Linux:** run `./setup.sh`. **Windows:** double-click `setup.bat`.

The setup script verifies your Python version, installs dependencies (`yfinance`, `openpyxl`, `pandas`, `jupyter`), and prints next steps. ~2 minutes on a fresh machine.

### Running the model

```bash
jupyter notebook DCF_Notebook_v4.ipynb
```

The notebook opens in your browser. You'll see 10 cells — markdown documentation in Cell 0, then code Cells 1-8 plus a blank Cell 9.

**The only cell you ever edit is Cell 3.**

Cell 3 has a header that says **"⭐ REPOINT THE MODEL"**. Underneath are roughly 30 input lines. The most important ones at the top:

```python
TARGET       = "MU"                     # Your ticker (any yfinance-covered)
COMPANY_NAME = "MICRON TECHNOLOGY, INC."
EXCHANGE     = "NASDAQ"
SECTOR       = "Semiconductors — Memory"

PEERS        = ["INTC", "AMD", "NVDA", "QCOM", "TXN"]
RATING       = "UNDERWEIGHT"            # OVERWEIGHT / NEUTRAL / UNDERWEIGHT
PRICE_TARGET = 120.00                   # Your firm's PT

GROWTH_PATH  = (0.28, 0.15, 0.07, 0.04, 0.03)   # FY+1 .. FY+5 revenue growth
TERMINAL_G   = 0.025                    # Long-run terminal growth
```

Edit those, scroll down for scenarios and segments if relevant to your sector, then click **Kernel → Restart & Run All**. The pipeline runs ~60 seconds. When it's done, open `DCF_Final.xlsm` in Excel.

That's the whole loop. **Edit Cell 3 → Run All → Open Excel.** Repeat any time the data is stale or your assumptions change.

---

## 3. The 9-step pipeline at a glance

When you run Cell 4 (the data refresh), you'll see 9 numbered steps stream into the output. Each does one thing:

| Step | What runs | Where it writes |
|---|---|---|
| 1/4 | Macro data fetch | 10Y Treasury yield + Damodaran ERP → Required Return |
| 2/4 | Target financials | yfinance IS / BS / CF for the target ticker |
| 3/4 | Statement write | IS, BS, CF, Key Items, Estimates tabs populated |
| 4/4 | Peer fetch | Peer Comparison tab — target + 5 peers × 32 metrics |
| 4b/4 | Peer industry ratios | CapEx/D&A/NWC/Tax/Interest peer averages → Industry tab col B |
| 4c/4 | Target multi-year history | Same ratios but 5Y average for the target → Industry tab col E |
| 5/9 | Required Return polish | WACC sanity gate, Damodaran hyperlink, audit comments |
| 6/9 | CFF driver rebuild | CapEx/NWC ratios with sector-aware mid-cycle taper |
| 7/9 | Fallback chain | CFF!H## formulas → 4-tier hierarchy (target → peer → CONFIG → "N/A") |
| 8/9 | Workbook polish | Cross-tab text purge, formatting, ticker normalization |
| 9/9 | Reverse DCF tab | Decomposition + reverse-solve for implied perpetual growth |

Then Cell 5 runs `ib_fixes` (Cover tab build, FCFE→FCFF switch, scenario ordering). Cell 6 runs Relative Valuation. Cell 7 runs the Peer Scorecard. Cell 8 runs the verification pass that prints all audit invariants.

If any step fails, the pipeline keeps going (each module is independent). Read the output to see what skipped.

---

## 4. The 20 tabs, what each one does

| Order | Tab | One-line purpose |
|---|---|---|
| 1 | **Cover** | The IC one-pager. Rating, PT, weighted DCF, thesis bullets, key model assumptions. |
| 2 | Instructions | Static guide. Mostly safe to ignore once you've read this manual. |
| 3 | Peer Comparison | Target + 5 peers × 32 metrics — beta, P/E, EV/EBITDA, margins, growth, ROE, etc. |
| 4 | **Relative Valuation** | Peer-blended multiples valuation. Mid-cycle median is the headline ($401 for MU). |
| 5 | **Required Return** | WACC build from scratch. Beta blend, ERP, sanity gate, conservative/aggressive variants. |
| 6 | **Cash Flow Forecast** | 5-year revenue/EBIT/D&A/CapEx/NWC forecast → FCFF Y1-Y5. |
| 7 | Scenario Analysis | Same forecast structure for Pess and Opt cases (separate from Base in CFF). |
| 8 | **Valuation Estimates** | The DCF math. PV of FCFF, terminal value, EV bridge, scenario-weighted price. |
| 9 | Valuation Summary | One-page summary with WACC × g and EBIT × CapEx sensitivity matrices. |
| 10 | Debt Maturity Schedule | Year-by-year debt maturities (data-only, manual review). |
| 11 | IS | yfinance income statement, 5 years. Plus Historical Analysis ratios at the bottom. |
| 12 | BS | yfinance balance sheet, 5 years. Plus Historical Analysis. |
| 13 | CF | yfinance cash flow statement, 5 years. Plus Historical Analysis (CapEx/Rev, FCF/Rev, etc.). |
| 14 | Key Items | EPS, share count, key ratios. Lookup source for several formulas. |
| 15 | Estimates | yfinance consensus — Sales, EPS, Free CF, Target Price. Source for Cover row 19. |
| 16 | Segment Revenue | Bottoms-up build (DRAM/HBM/NAND for MU, or your segments via Cell 3). |
| 17 | Industry | DCF Driver Ratios block (rows 13-20). Peer / CONFIG / Effective / Target columns. |
| 18 | Driver Sensitivity | Tornado of 8 drivers + price-range footer. Live-linked. |
| 19 | Revenue Bridge | Top-down (CONFIG.growth_path) vs Bottoms-up (CONFIG.segments) reconciliation. |
| 20 | **Reverse DCF** | Decomposes market price into PV(forecast) + PV(reasonable terminal) + residual. |

Bold tabs are where you'll spend 90% of your time. The rest are data plumbing.

---

# Part II — Reading the model

## 5. The Cover tab — your IC one-pager

The Cover tab is the first thing your MD will look at. If it's not clean, nothing else matters. Read it top-to-bottom:

### Row 1 — banner
`MICRON TECHNOLOGY, INC. (NASDAQ: MU)` — auto-built from `CONFIG.banner`. If you repointed in Cell 3, this updates automatically.

### Row 4-7 — INVESTMENT RECOMMENDATION
The headline numbers:

| Cell | What it is | What to look for |
|---|---|---|
| C6 | Current Price | Live from yfinance via Required Return!C5 |
| D6 | Base Case DCF | Single-scenario fair value |
| F6 | Two-Stage DCF | The 10-year horizon DCF |
| H6 | Weighted Avg | 25% Pess + 50% Base + 25% Opt |

If the Weighted Avg is materially below current price, you have an UNDERWEIGHT setup. Materially above → OVERWEIGHT. Within 10% → NEUTRAL.

### Rows 9-19 — VALUATION SUMMARY (the meat)

| Row | Method | What to read |
|---|---|---|
| 12 | DCF — Two-Stage (10-Year) | Most rigorous DCF — explicit through Y10 + terminal |
| 13 | DCF — Base Case | 5-year explicit + Gordon perpetuity |
| 14 | DCF — Pessimistic | Bear scenario |
| 15 | DCF — Optimistic | Bull scenario |
| 16 | DCF — Probability Weighted | 25/50/25 blend |
| 17 | Multiples (Peer Comps — Blended) | **Mid-cycle median across 5 multiples — the through-cycle answer** |
| 18 | Dividend Discount Model | N/A unless company pays meaningful dividends (>10% payout) |
| 19 | Analyst Price Target | Live VLOOKUP on Estimates → yfinance consensus mean target |

The **Implied Price** column is the model's answer. **vs Market** is the dollar gap. **% Δ** is the gap relative to market. **Signal** flags Overvalued / Fair / Undervalued.

> **Read the spread between rows 12 and 17.** If DCF says $40 and Multiples say $400, you're looking at a "market is pricing AI revolution" situation (NVDA, MU). If DCF says $80 and Multiples say $90, you have a converging-views situation where intrinsic and relative agree.

### Rows 22-37 — KEY MODEL ASSUMPTIONS

These are the inputs that drive everything else. Memorize the position of each one:

| Row | Assumption | Source |
|---|---|---|
| 25 | Revenue FY+1E | CFF!B40 — first forecast year revenue |
| 26 | Revenue FY+5E | CFF!F40 — fifth forecast year revenue |
| 27 | Revenue 5Y CAGR | Compounded |
| 28 | Peak EBIT Margin | CFF!B44 — Y1 forecast margin |
| 29 | Terminal EBIT Margin | CFF!F44 — Y5 forecast margin (where you "land") |
| 30 | WACC (Base) | RR!C54 — median of 3 WACC variants |
| 31 | Terminal Growth | CONFIG.terminal_growth — long-run g |
| 32 | Tax Rate | RR!C44 — your WACC tax rate |
| 33 | Net Debt | VE!B16 — ST + LT debt − cash |
| 34 | Shares Outstanding | RR!C6 — diluted |
| 35 | Reverse DCF Implied g | Live from Reverse DCF tab — what market is pricing |
| 36-37 | Terminal % of EV | Two-Stage DCF terminal share — should be < 75% (5Y) and < 65% (10Y) |

If row 35 (Reverse DCF Implied g) is > 5%, the market is pricing super-GDP perpetual growth — the textbook bear setup.

If rows 36-37 fail the < 75% / < 65% targets, your DCF is too dependent on terminal value (the most uncertain part). Re-run with a longer Stage 2 to push more value into the explicit forecast.

### Rows 41-48 — INVESTMENT THESIS — KEY TAKEAWAYS

Eight bullets, CONFIG-driven via `CONFIG.thesis_lines`. Bullets 1-7 are general; bullet 8 should always state the rating and PT.

These are your IC bullets — print this section, walk into the meeting.

---

## 6. The Required Return tab — building WACC

WACC is the discount rate you apply to future cash flows. Wrong WACC = wrong DCF. The Required Return tab builds it from scratch with three different methods and presents the median as your base case. **Trust column C (Conservative) for the base, but always show all three.**

### Rows 5-15 — INPUTS (yellow / peach cells)
yfinance / SEC pulls — current price, shares outstanding, debt, equity, interest expense, tax expense.

> **Critical:** if C8 (Short Term Debt) and C9 (Long Term Debt) both show $0 but C13 (Interest Expense) shows a number, you have a label-mismatch bug — yfinance reports debt under a different row name than the formula expects. The template's Audit #2/B fixed this for the most common case, but for some illiquid tickers you may need to check the BS tab manually.

### Rows 17-22 — yfinance / SEC reference values
What yfinance reports as MU's WACC (11%), Cost of Equity (11.54%), beta (1.61). Reference only; the model doesn't use these directly.

### Rows 24-34 — beta blend
Three different beta sources are shown side-by-side:

| Cell | What |
|---|---|
| F27 | 3-year beta (yfinance) |
| G27 | 1-year beta (yfinance) |
| H27 | Peer average beta |

The template uses the **maximum** of company beta, peer average, and the SEC-reported beta — for conservatism. If your target's beta is unstable (cyclical name during a peak), the peer average is a more defensible anchor.

### Rows 32-33 — Required Market Return
Three risk-premium rows for Large/Mid/Small Cap (7% / 8.5% / 10%). The model uses the cap-appropriate one.

### Row 39 — OUTPUTS
The four-by-three WACC matrix. Read it like this:

| | Conservative | Aggressive |
|---|---|---|
| Cost of Equity (RE) | Higher Ke (uses Damodaran 4.5% ERP) | Lower Ke (uses yfinance's reported MRP) |
| Total Capitalization (V) | E + D | E + D |
| Tax Rate | 23% statutory | 23% statutory |

### Row 52-54 — the WACC numbers
Three variants:

- **Average WACC** (C52) — blend of conservative and aggressive
- **Conservative WACC** (D52) — uses Damodaran ERP, conservative beta
- **yfinance/SEC WACC** (C54) — what yfinance reports

The template uses **Conservative as the base WACC** (C54). For MU: 11.00%.

### Row 63 — WACC sanity gate
A formula that checks `WACC > 4%`. If it fails, the gate flags FAIL in red and you know your DCF will produce nonsense (terminal value blows up when WACC ≈ g). A failed gate usually means a data-quality problem upstream — beta = 0, Treasury yield = 0, etc.

> **MD will ask: "what's your WACC and where did it come from?"** Your answer: "11.00%, conservative variant. Built from Damodaran ERP 4.5% × max-of-three beta 1.61, plus 4.31% 10-year Treasury, blended with after-tax cost of debt 2%, weighted by current capital structure (97% equity / 3% debt)." Cite cells C41 (Ke), C43 (Cost of Debt), C44 (Tax Rate), C54 (final WACC).

---

## 7. The Cash Flow Forecast — where the cash flows come from

This is the most operationally important tab. It's where revenue, margins, CapEx, NWC become FCFF. Read it from top to bottom — every row builds on the row above.

### Rows 7-22 — RAW HISTORICALS
yfinance writes 5 years of IS / BS / CF data here. Each cell is a VLOOKUP into the source tab.

| Row | Line item | Source |
|---|---|---|
| 8 | Total Revenue | IS row 2 (label "Sales") |
| 9 | Operating Income | IS row 10 |
| 10 | Interest Expense | IS row 13 |
| 11 | Tax Provision | IS row 17 |
| 12 | Pretax Income | IS row 16 |
| 13 | D&A | IS row 12 |
| 14 | CapEx | CF row 14 (yfinance reports negative) |
| 15 | Cash & ST Inv | BS row 3 |
| 16 | Total Current Assets | BS |
| 17 | Total Current Liabilities | BS |
| 18 | Short-term Debt | BS |
| 19 | Long-term Debt | BS |

### Rows 26-34 — HISTORICAL RATIOS

The columns B-G are per-year ratios; column H is the 5-year SUMPRODUCT average. After Audit #4, H## resolves through a 4-tier fallback chain:

1. **Tier 1** — company history average (B##:G## SUMPRODUCT)
2. **Tier 2** — peer industry average (Industry!B##)
3. **Tier 3** — CONFIG analyst-curated value (Industry!C##)
4. **Tier 4** — visible "N/A" string

Cell 8's verification will tell you which tier each ratio fired from. For MU:

| Row | Ratio | Tier 1 (MU) | Peer | CONFIG |
|---|---|---|---|---|
| 26 | Revenue Growth | ~20% | ~25% | 5% |
| 28 | EBIT margin | ~30% (cycle avg) | ~30% | 20% |
| 30 | Tax Rate | ~14% (CHIPS credits) | ~18% | 21% |
| 31 | CapEx / Sales | **41%** (high — peak HBM) | ~12% (fabless drag) | 30% |
| 32 | D&A / Sales | **22%** (heavy fab depreciation) | ~9% | 22% |
| 33 | NWC / Sales (level) | ~31% | ~37% | 40% |

> **The 41% CapEx number is the single most important driver of MU's bear DCF.** That's MU's actual through-cycle CapEx ratio. If you believe 41% is structural (memory needs huge fab investment forever), you get a $5-10/sh DCF. If you believe it's peak-cycle (HBM ramp normalizes by 2030), you tune `capex_mid_cycle_factor` lower in Cell 3 and get a $40-60 DCF.

### Rows 38-44 — FORECAST ASSUMPTIONS (blue cells you can edit)

Row 39: BASE CASE Revenue Growth Rate, B-F — the 5-year growth path. Default is `CONFIG.growth_path = (0.28, 0.15, 0.07, 0.04, 0.03)` for MU. **You can override per-year directly in the workbook** (blue input cells).

Row 44: BASE CASE EBIT Profit Margin, B-F — the 5-year margin path. For MU: 23.3% Y1 → 14.3% Y5 (margin compression as HBM peak fades).

### Rows 45-49 — EBIT, Tax, NOPAT, Interest, Net Income

Every cell is a formula. NOPAT = EBIT × (1 − Tax). Net Income = NOPAT − Interest.

> **After Audit #5, the FCF formula at row 65 uses NOPAT (B47), not Net Income (B49).** That makes the model FCFF (unlevered), which is what an EV-bridge DCF requires.

### Rows 59-64 — D&A, CapEx, NWC change

| Row | Formula | What it does |
|---|---|---|
| 59 | D&A = $H$32 × revenue | Constant ratio |
| 60 | CapEx ratio = $H$31 × taper | Audit #5 — sector-aware taper |
| 61 | CapEx = revenue × −CapEx ratio | Negative (cash outflow) |
| 62 | NWC ratio = $H$33 × taper | Audit #5 |
| 63 | NWC level = revenue × NWC ratio | Working capital level |
| 64 | ΔNWC = forecast NWC − base year NWC | Year-over-year change |

> **Note on row 60-62 tapers:** the sector preset for memory is `[0.95, 0.90, 0.85, 0.80, 0.75]` for CapEx — meaning Y1 CapEx is 95% of historical avg, Y5 is 75%. Override in Cell 3 by setting `CAPEX_MID_CYCLE_FACTOR = 0.55` for more aggressive normalization (DCF goes up) or `CAPEX_MID_CYCLE_FACTOR = 0.95` for less normalization (DCF goes down).

### Row 65 — FREE CASH FLOW TO FIRM (FCFF)
The headline output. `=B47 + B59 + B61 - B64` = NOPAT + D&A − CapEx − ΔNWC. Five values for Y1-Y5. These flow into Valuation Estimates.

---

## 8. The Valuation Estimates tab — the DCF math

This is where the cash flows from CFF become a fair value per share. Three scenarios run side by side: Pessimistic (column B), Base (D), Optimistic (F).

### Rows 9-12 — Cash Flow Present Values

Each row is one year. Each cell is `FCFF × discount factor`. Y1 has the smallest discount factor; Y5 has the largest.

**Read these vertically.** Negative numbers mean negative FCF for that year (cash burn). For MU base case:

```
Y1 (2026): -$8,249  ← peak HBM CapEx, ΔNWC swing
Y2 (2027): +$4,861
Y3 (2028): +$4,233
Y4 (2029): +$3,504
Y5 (2030): +$2,854
Sum:       +$7,203  ← Σ PV(Y1-Y5)
```

If Year 1 is deeply negative and Years 2-5 are modestly positive, you've got a **near-term-investment, long-term-payoff** profile. Common for cyclical capex-heavy names at the cycle peak.

### Row 14 — Total Present Value of Cash Flows (EV)
`=SUM(rows 9-12) + Terminal Value PV`. For MU base: $41,616M.

### Row 16 — Net Debt
`=ST Debt + LT Debt − Cash`. Pulled from Required Return. For MU: $4,411M.

### Row 17 — Equity Value
`=EV − Net Debt`. The portion of enterprise value that belongs to shareholders.

### Row 18 — Number of Shares
From Required Return!C6.

### Row 20 — Estimated Stock Value (DCF Method)
`=Equity Value / Shares`. Three columns for Pess/Base/Opt.

### Rows 21-23 — Comparison to current price + Over/Under flag

### Row 25 — Probability of scenario
Default 25% / 50% / 25%. You can edit these directly in the workbook.

### Row 26 — Wtd. Scenario Valuation
The probability-weighted average price.

### Rows 31-32 — Price Range labels
Pess→Opt range and Wtd-Multiples-DCF range.

### Rows 33-35 — Multiples Valuation Estimates
Five multiples (P/E, P/B, EV/Sales, EV/EBITDA, P/FCF) with weightings, summed to a Wtd. Multiples Valuation. This is the same data as Relative Valuation but presented as a single column.

### Rows 41-48 — Dividend Discount Model
Only meaningful if Payout Ratio > 10%. For MU (payout < 10%), N/A by design.

### Rows 54-64 — REVERSE DCF (legacy)
This block lives on VE for historical reasons. The new Reverse DCF tab (built by Audit #9) is more comprehensive — use that one.

### Rows 66-85 — Two-Stage DCF — Stage 2 (Y6-Y10)
The extended-horizon DCF. Stage 2 grows from Y5 FCF at a constant rate (default 5% from CONFIG.stage1_end_growth) for years 6-10, then hits terminal at Y10. Used to test how much of fair value comes from far-future cash flows.

The result lands in row 84 — `Two-Stage DCF Implied Price` — which is what Cover row 12 references.

---

## 9. The Valuation Summary — the headline picture

Top of tab (rows 1-14): Methodology table — same as Cover rows 12-19 but more compact.

Rows 17-27: **WACC × Terminal Growth sensitivity matrix.** Read it like this:

```
                 Terminal Growth →
WACC ↓     1.5%    2.0%    2.5%    3.0%
9.0%      $40.79  $43.68  $47.00  $50.89
9.5%      $37.46  $39.94  $42.77  $46.04
10.0%     $34.52  $36.67  $39.10  $41.88
10.5%     $31.92  $33.79  $35.90  $38.29
11.0%     $29.58  $31.23  $33.07  $35.14   ← base case (yellow)
11.5%     $27.49  $28.94  $30.56  $32.37
12.0%     $25.60  $26.89  $28.32  $29.91
```

The yellow-highlighted cell is your base-case combination. Read this to answer "what if my WACC is wrong by 100bp?" — slide one row up or down.

Rows 31-38: **Y1 EBIT Margin × Y1 CapEx % matrix.** Same structure but along operational drivers. Use this to test "what if margins compress / CapEx normalizes?"

> **MD will ask: "how sensitive is your fair value to assumptions?"** Your answer: "Within ±100bp of WACC (10% to 12%) the price ranges from $X to $Y — call it $Z midpoint. Within ±400bp of EBIT margin (18% to 26%), price ranges $A to $B. Our $33 base case is the WACC=11%, terminal-g=2.5% intersection." Pull the cells from this tab directly.

---

## 10. Scenario Analysis — Pess / Base / Opt

Rows 4-19: Pessimistic case. Same line-item structure as CFF rows 38-65, but with weaker margins (typically Y1 ~15%) and slower revenue growth.

Rows 23-35: Pessimistic FCF, NOPAT, NWC.

Rows 39-71: Optimistic case. Stronger margins (Y1 ~35%), faster revenue.

The model uses **PATH mode** when CONFIG.pess_rev_path / CONFIG.opt_rev_path is set (cyclical names like MU). Otherwise it falls back to **OFFSET mode** (Base ± constant percentage).

> **For cyclical names, always use PATH mode.** A constant `Pess = Base − 2pp` doesn't capture the actual shape of a memory downturn (revenue falls 30-50%, then U-shapes). PATH lets you specify year-by-year.

> **Audit #2 enforced** Pess(Y1) < Base(Y1) < Opt(Y1) at the structural level — if your scenarios cross, the verification will warn you.

---

## 11. Driver Sensitivity — the tornado

Eight rows (5-12), each one driver. Columns:

| Col | What |
|---|---|
| A | Driver name |
| B | Base value (live formula → upstream cell) |
| C | Low value (B × 0.9) |
| D | High value (B × 1.1) |
| E | "—" (placeholder for Δ price impact) |
| F | "—" (same) |

The Δ price impact columns are blank because computing them accurately requires a full DCF re-run per perturbation — which would be ~80 sensitivities. For directional sensitivity, use the WACC × g matrix on Valuation Summary instead.

Row 22 footer: live formula building "FOR IC: Expected price range under Pess/Opt DCFs: $X − $Y (Base: $Z)" from VE!B20 / D20 / F20. Use this in your IC slide.

---

## 12. The Reverse DCF tab — the bear-thesis kill shot

This is the single most powerful tab in the workbook for a bear thesis. It answers the question: **"What would the market need to believe about the future for the current price to be fair?"**

### How it works mathematically

Standard DCF: `Price = Σ PV(FCFF) + PV(Terminal Value)`

Solve for the terminal growth rate `g` that makes the equation balance against the actual market price:

```
Required TV (PV) = Market EV − Σ PV(FCFF)
Required TV (Y5 nominal) = Required PV × (1+WACC)^5
TV = FCFF_Y5 × (1+g) / (WACC − g)

Solve for g:
    g = (TV × WACC − FCFF_Y5) / (TV + FCFF_Y5)
```

That `g` is what the market is implicitly pricing as the perpetual growth rate. If it comes out 8-12%, the market is pricing super-GDP perpetual growth — which is structurally impossible.

### Reading the tab

| Section | Cells | What to read |
|---|---|---|
| 1. Anchor Inputs | C5-C9 | Stock price, shares, market cap, net debt, market EV |
| 2. WACC & Terminal | C12-C14 | WACC (11%), reasonable g (2.5%), LT GDP (3.5%) |
| 3. 5Y Explicit FCFF | B18:F21 | FCFF Y1-Y5, discount factors, PVs, sum |
| 4. TV @ Reasonable g | C24-C30 | TV at CONFIG g, PV of TV, implied price per share |
| 5. **DECOMPOSITION** | A33:D36 | The bear thesis — what % of market cap is "unjustified premium" |
| 6. **REVERSE-SOLVE** | C42 | The implied perpetual g — the verdict number |
| 7. IC Summary | C49-C53 | Bridge from "implied if you believe" to "market price" |

### The decomposition (Section 5)

For MU at $497 market price:

```
Market EV ≈ $560B mkt cap + $4.4B net debt = $564B
                                                    
Bucket 1: PV of explicit 5Y forecast        $7B    (1%)
Bucket 2: PV of TV @ reasonable 2.5% g      $9B    (2%)
Bucket 3: RESIDUAL — implied growth premium $548B  (97%)  ← THE BEAR THESIS
```

97% of MU's market cap is what the market is paying for that cannot be justified by 5 years of forecast plus a sensible terminal. The bull case has to defend that $548B residual.

### The verdict (Cell C46)

The cell auto-classifies based on implied g:

| Verdict | Implied g range | Meaning |
|---|---|---|
| ✓ FAIR | g ≤ CONFIG g + 0.5% | Market roughly aligns with reasonable terminal |
| ⚠ STRETCHED | CONFIG g < g ≤ LT GDP (3.5%) | Above expected but below GDP — defensible if you believe in moat |
| ⚠ AGGRESSIVE | LT GDP < g ≤ 5% | Above LT GDP — implies sustained super-GDP growth |
| ⛔ STRUCTURALLY UNJUSTIFIABLE | g > 5% | Perpetual super-GDP growth — mathematically impossible |

Conditional formatting paints the cell green for FAIR, red for STRUCTURALLY UNJUSTIFIABLE.

> **MD will ask: "what's your strongest bear point?"** You: "Reverse DCF implies the market is pricing perpetual growth of [implied g] — Cell C42 of the Reverse DCF tab. That's [X bps] above long-run GDP. Even granting a 10-year HBM ramp, the math doesn't survive a finite-economy constraint." Point at Cell C46 — the verdict cell.

---

## 13. Relative Valuation — peer-blended multiples

Two side-by-side comparisons:

### Top half (rows 5-12) — five multiples

For each multiple (P/E, P/B, EV/Sales, EV/EBITDA, P/FCF):

- Row 7: Peer Mean multiple
- Row 8: Peer Median multiple
- Row 9-10: Implied Price using NTM (peak-cycle) drivers
- Row 11-12: Implied Price using Mid-Cycle drivers

The mid-cycle drivers (row 6) cascade from the **mid-cycle drivers side block** at columns M-N. CONFIG-driven:

```
Revenue factor: 0.70 × NTM revenue       (mid-cycle revenue)
EBITDA margin: 32% × mid-cycle revenue   (mid-cycle EBITDA)
Net margin: 15% × mid-cycle revenue       (mid-cycle NI)
FCF conversion: 20% × mid-cycle EBITDA   (mid-cycle FCF)
```

Edit the YELLOW cells at N5:N9 to recast the entire mid-cycle picture. The downstream rows recalculate live.

### Row 17 — Face-Value Blended (Peak-Cycle, upper bound)
Peak-cycle blend across the five multiples. For MU: ~$1,010. This is the bull's anchor — "if the cycle holds and multiples don't compress, MU is worth $1,000."

### Row 18 — **NORMALIZED BLENDED (Mid-Cycle × Median) — HEADLINE**
Mid-cycle median across the five multiples. For MU: $401. This is the through-cycle answer. **This is what Cover row 17 references.**

### Cyclicality guard (row 13)
Each multiple gets an auto-weight based on how stretched it is vs market price:

- 1.0 (full weight) if implied/market < 1.75
- 0.5 (half weight) if 1.75 < ratio < 3.0
- 0.0 (zero weight) if ratio > 3.0

This prevents one wildly-inflated multiple (P/E during peak earnings, EV/EBITDA during cycle peak) from dominating the blend. CONFIG-tunable.

### Rows 21-31 — Comparable Companies Detail
Same data as Peer Comparison but with the target highlighted and Peer Mean / Peer Median rows below.

### Rows 33-40 — MU Premium / (Discount) to Peer Group
Compares MU on each multiple vs peer mean and median. Green if MU is "favorable" (cheaper on valuation multiples, better on margin metrics), red if "unfavorable."

> **For mid-cycle multiples, always cite RV row 18.** That's the headline blended through-cycle answer. RV row 17 (Face-Value Peak Blend) is the bull case ceiling — useful for "what's the upside if the cycle holds" but not your primary number.

---

## 14. Peer Comparison + Industry tab — the ratio chain

### Peer Comparison
Static data table, 32 metrics × 6 companies (target + 5 peers). yfinance pulls each peer's `info` dict. Column H is the auto-computed peer average (excluding the target).

Most useful rows:

| Row | Metric | What to read |
|---|---|---|
| 8 | Beta (3-yr) | Used in Required Return WACC build |
| 10-14 | Multiples | Cross-check vs Relative Valuation |
| 17-22 | Margins, ROE, Debt/Equity | Operational quality vs peers |
| 24-26 | Revenue, EBITDA, FCF ($M) | Scale comparison |
| 27-28 | Div yield, payout | Determines if DDM is meaningful |
| 29 | Analyst Rating | Sentiment indicator (Strong Buy / Buy / Hold / Sell) |
| 30-32 | Price Target, Target Range, # Analysts | Consensus PT |

### Industry tab
Two sections.

**Top section (rows 5-10)** — derived from Peer Comparison column H. After Audit #4, each cell uses `=IFERROR('Peer Comparison'!H##, "N/A")` — visible failure if the peer data is missing.

**Bottom section (rows 13-20)** — DCF Driver Ratios block. Four columns:

| Col | What |
|---|---|
| B | Peer Avg (T2) — current-year cross-peer ratio |
| C | CONFIG (T3) — analyst-curated mid-cycle from `dcf_config.py` |
| D | Effective — `=IF(ISNUMBER(E),E, IF(ISNUMBER(B),B, IF(ISNUMBER(C),C, "N/A")))` |
| E | Target Hist (T1a) — Python-computed multi-year average for the target |

These feed into CFF!H## as the fallback chain. Verified by Cell 8 verification each run.

> **The 4-tier hierarchy is the heart of the data quality story.** When you run Cell 8, it tells you which tier each ratio resolved from. For a well-covered ticker like MU with 5 years of yfinance data, every ratio fires Tier 1 (target history). For a thinly-covered ticker, it falls through to peer or CONFIG. The verification surfaces the tier — never silent.

---

## 15. Revenue Bridge + Segment Revenue — top-down vs bottoms-up

The Revenue Bridge tab reconciles three forecasts of revenue:

| Source | Rows | What |
|---|---|---|
| Top-Down | A19 | `CONFIG.growth_path` — your assumed growth |
| Bottoms-Up | A20 | Sum of segment growth from `CONFIG.segments` |
| Consensus | Row 14 | Street analyst consensus (CONFIG.consensus_revenue) |

If all three roughly agree, your forecast is defensible. If top-down says 28% but bottoms-up says 18%, you have a **segment mismatch** — one or more segment growth paths in CONFIG.segments doesn't compose to the top-down rate. Walk through the segment mix and reconcile.

The **Segment Revenue tab** is where the bottoms-up build happens. Each segment has a growth path in CONFIG.segments and a row on this tab. For MU:

- DRAM at row 6: growth path (30%, 16%, 7%, 4%, 3%)
- HBM at row 9: growth path (120%, 60%, 30%, 15%, 8%)
- NAND at row 12: growth path (20%, 12%, 5%, 3%, 3%)

Segment Y1 revenue = base year × (1 + growth Y1). Y2-Y5 compound.

> **For non-segment companies (single-product or services), set `SEGMENTS = []` in Cell 3.** The Bottoms-Up row will blank out, the Revenue Bridge will show "Top-Down only," and the model uses CONFIG.growth_path exclusively. No segment build needed.

---

# Part III — Thinking like an analyst

## 16. The four numbers that decide every pitch

When an MD spends 90 seconds on your model before walking into the IC, they look at four numbers:

### 1. Cover row 6 (`Weighted Avg`) vs current price
This is the headline call. If it's 50% below market → STRONG underweight. 20% below → moderate. Within ±10% → NEUTRAL. Above market → OVERWEIGHT.

### 2. Cover row 17 (`Multiples`) — peer-blended mid-cycle
The cross-check. If DCF says $40 and Multiples say $400, you're claiming the market is wildly mispriced — be ready to defend why.

### 3. Cover row 35 (`Reverse DCF Implied g`)
The bear-thesis quantifier. Above 5% → market is pricing perpetual super-GDP growth. Above 8% → mathematically impossible. Below LT GDP (3.5%) → no obvious bear thesis on growth.

### 4. Required Return row 63 (WACC sanity gate)
PASS or FAIL. If FAIL, the rest of the model is suspect — fix the upstream data before pitching.

If those four are all in agreement, your call is defensible. If they're in tension, you have an investment thesis to articulate.

---

## 17. Nine pitfalls every analyst makes

### 1. Anchoring on peak-cycle margins
A company at the cycle peak shows beautiful margins, ROE, and FCF. Projecting those forward is the most common bear-thesis mistake (extrapolating peak forever) and bull-thesis trap (refusing to taper).

**The template's defense:** sector-aware mid-cycle factors that taper CapEx and NWC. EBIT margin path is YOUR call — input it intentionally, not by accident.

### 2. Peer-cohort traps
A "semis peer" cohort that mixes fabless (NVDA, AMD) with integrated (MU, INTC) gives meaningless averages. CapEx ratios diverge by 20-30 percentage points between the two groups.

**The template's defense:** explicit peer list in Cell 3. Choose peers thoughtfully — 3-5 truly comparable names, not "5 random semis tickers."

### 3. Terminal-g abuse
Setting terminal_growth = 4-5% to bridge to the price you want is the single most common form of "torturing the data until it confesses." Long-run g must be ≤ long-run GDP nominal.

**The template's defense:** Reverse DCF tab's verdict cell flags terminal g > 5% as STRUCTURALLY UNJUSTIFIABLE.

### 4. WACC manipulation
Lowering WACC by 200bp magically transforms a $40 fair value into a $60 fair value. Don't do this without justification.

**The template's defense:** WACC built from scratch with three blended methods, conservative variant used. Sanity gate ensures WACC > 4%.

### 5. Confusing FCFE with FCFF
If you discount levered cash flows (FCFE = NI + D&A − CapEx − ΔNWC) at WACC, you're double-counting. EV-DCF must use unlevered FCFF (NOPAT + D&A − CapEx − ΔNWC).

**The template's defense:** Audit #5 switched the FCF formula to use NOPAT (B47) not Net Income (B49). Labels updated to "FCFF (unlevered)."

### 6. Stale data
Running yesterday's model on today's stock price gives you yesterday's call. Always re-run Cell 4 before an IC.

**The template's defense:** Cell 8 verification + the price reconcile gate (Cell 4 step 4) flags drift.

### 7. Ignoring the cycle
Cyclical companies at the peak look investment-grade and at the trough look distressed. The DCF using current-year ratios reflects the snapshot, not the through-cycle reality.

**The template's defense:** Tier-1a Python multi-year history (5-year avg). The fallback chain uses through-cycle values, not just the current quarter.

### 8. Missing the segment story
For multi-segment companies, the consolidated forecast can hide segment-level inflections. MU's HBM segment grows at 120% Y1 while DRAM grows 30% — averaging to 28% top-down hides the dynamic.

**The template's defense:** Revenue Bridge tab reconciles top-down vs bottoms-up vs consensus.

### 9. Overconfidence
Every assumption in your model is wrong by at least 10%. The right answer is a range, not a point estimate.

**The template's defense:** Three explicit scenarios (Pess/Base/Opt) + sensitivity tables (WACC × g, EBIT × CapEx). Always quote both the base case AND the range.

---

## 18. How to defend your call to an MD

The MD has seen 1,000 DCFs. They will press on three things:

### "What's your single most important assumption?"

Pull up the Driver Sensitivity tab. Pick the driver with the largest swing in implied price (usually CapEx % or EBIT margin). Say: "My fair value is most sensitive to [X]. At base case [%] my fair value is $Y. At ±10% on [X], range is $Z to $W."

### "Why disagree with the market?"

Pull up the Reverse DCF tab. Cite the implied g (Cell C42). If it's > 5%, say: "Market is pricing [X%] perpetual growth. Long-run nominal GDP is 3.5%. Even granting a 10-year [thesis], the math doesn't survive past Y10. Cell C46 verdict: STRUCTURALLY UNJUSTIFIABLE."

If implied g is reasonable (≤ 3.5%), the bear thesis isn't on growth — it's on margin compression, CapEx deflation, or competitive dynamics. Pull from your industry knowledge.

### "What changes your call?"

Be honest about the inputs that would flip your view. For UNDERWEIGHT MU: "If sector preset moves from 0.75 to 0.55 (HBM normalization 5 years rather than 10), DCF moves to ~$45. If we believe HBM oligopoly margins persist past 2030 (currently model decays from 23% to 14%), DCF moves to ~$70. Below ~$80 fair value, UNDERWEIGHT holds; above, NEUTRAL."

> **The single highest-leverage IC behavior:** quote ranges, not points. "Our DCF base case is $33 with a Pess/Opt range of $-10 to $138. The weighted scenario PT is $48. Multiples mid-cycle is $401. Final PT $120 reflects 75% weight on through-cycle multiples discounted for cycle risk." That's defensible.

---

## 19. Worked example — MU UNDERWEIGHT

**Setup:** Cell 3 with `RATING = "UNDERWEIGHT"`, `PRICE_TARGET = 120`, default sector preset.

**Numbers:**
- Current price: $497 (peak HBM cycle)
- Two-Stage DCF: $34
- Base Case DCF: $33
- Optimistic DCF: $138
- Probability Weighted: $48
- Multiples Mid-Cycle: $401
- Reverse DCF Implied g: 10.1%

**Thesis to write into Cover bullets:**

1. **DCF SAYS DEEPLY OVERVALUED** — Two-Stage DCF $34 vs $497 market = stock priced at 14× through-cycle DCF.
2. **REVERSE DCF IMPLIES 10% PERPETUAL GROWTH** — market pricing growth rate above long-run GDP forever; mathematically impossible (Cell C42, Reverse DCF tab).
3. **CONSENSUS IS STRETCHED** — 23 of 24 sell-side analysts BULLISH at all-time-high stock = textbook cycle peak signal.
4. **CAPEX BURDEN IS STRUCTURAL** — 5Y avg CapEx/Sales 41%; HBM ramp creates persistent cash drag through 2027+.
5. **TERMINAL DEPENDENCY** — Two-Stage DCF Y10 terminal share 56% (within IB-spec 65% gate, but high).
6. **MARGIN COMPRESSION RISK** — EBIT decays 23% → 14% as Samsung/SK Hynix HBM4 ramps in 2027.
7. **SENSITIVITY** — ±10% WACC moves price $25-50; even at WACC 9% / g 3%, fair value $50 (still 90% below market).
8. **RATING: UNDERWEIGHT. PT $120** (15% weight DCF + 75% weight through-cycle multiples discounted for cycle risk + 10% weight reverse-DCF gap).

**The defensible MD pitch (90 seconds):**

> "MU is at peak HBM cycle. DCF-base $33, Multiples-mid-cycle $401, market $497. The gap between the two intrinsic methods reflects whether you believe HBM is structural (multiples win) or cyclical (DCF wins). We come down on cyclical: 5-year average CapEx is 41%, depreciation 22%, and reverse-DCF requires 10% perpetual growth to support market price. Our $120 PT weighs both methods — bearish but defensible."

---

## 20. Worked example — NVDA OVERWEIGHT

**Setup:** Cell 3 with `RATING = "OVERWEIGHT"`, `PRICE_TARGET = 200`, sector "Software" (or Semiconductors with capex factor 0.30 if you want to stress NVDA's fabless model).

**Numbers (illustrative):**
- Current price: $208
- Two-Stage DCF: $250 (low CapEx 4%, high growth 65%, mid-cycle margin 55%)
- Multiples Mid-Cycle: $180
- Reverse DCF Implied g: 4.2%

**Thesis to write into Cover bullets:**

1. **DCF AND MARKET ALIGN** — Two-Stage DCF $250 vs $208 market = stock priced at 0.83× DCF.
2. **REVERSE DCF AT GDP+0.7%** — Cell C42 shows 4.2% implied perpetual growth, just above LT GDP. Verdict: STRETCHED but defensible.
3. **MARGINS HOLDING** — 65% gross margin sustainable due to CUDA moat.
4. **CAPEX LIGHT** — fabless model — CapEx/Revenue ~3-4% — minimal cash drag.
5. **TERMINAL CONCENTRATION ACCEPTABLE** — Two-Stage Y10 terminal share 62% (below 65% gate).
6. **MARGIN UPSIDE** — possible — H100 → H200 → B100 GPU pipeline supports continued ASP increases.
7. **SENSITIVITY** — within ±100bp WACC, $230-$275; below $200 fair value would warrant downgrade.
8. **RATING: OVERWEIGHT. PT $200** (50% weight DCF + 30% multiples + 20% reverse-DCF cushion).

The Reverse DCF here is the BULL case argument: implied g of 4.2% is GDP+0.7% — barely above LT growth. That's a reasonable bar for an oligopoly with structural moat.

---

## 21. Worked example — KO defensive NEUTRAL

**Setup:** Coca-Cola — `RATING = "NEUTRAL"`, `PRICE_TARGET = 70`, sector "Consumer".

**Numbers (illustrative):**
- Current price: $68
- Two-Stage DCF: $65
- Multiples Mid-Cycle: $72
- Reverse DCF Implied g: 2.8%

**Thesis bullets:**

1. **FAIR VALUE INTACT** — DCF $65 / Multiples $72 / market $68 — converging views.
2. **REVERSE DCF AT 2.8%** — Verdict: ✓ FAIR — market roughly aligns with reasonable terminal.
3. **DEFENSIVE PROFILE** — Beta 0.55 — pricing power through cycles.
4. **STABLE FCF** — 5Y average FCF margin 21%; no surprises.
5. **DIVIDEND ANCHOR** — payout 71% — DDM IS meaningful here ($65 implied, matches DCF).
6. **GEO RISK MODEST** — 30%+ revenue in EM but priced through.
7. **SENSITIVITY** — narrow band ±5% on every dimension.
8. **RATING: NEUTRAL. PT $70.** No clear edge for OVERWEIGHT or UNDERWEIGHT call.

For KO, all three valuation methods converge ($65/$70/$72) and Reverse DCF says FAIR. The right call is NEUTRAL. Don't manufacture a thesis — the market has it about right.

---

# Part IV — Reference

## 22. Glossary

**FCFF (Free Cash Flow to Firm):** unlevered cash flow to all capital providers. = NOPAT + D&A − CapEx − ΔNWC. Discounted at WACC.

**FCFE (Free Cash Flow to Equity):** levered cash flow to equity holders only. = Net Income + D&A − CapEx − ΔNWC + Net Borrowing. Discounted at Cost of Equity (Ke), not WACC. **Don't use FCFE in this template — it's unlevered FCFF throughout.**

**WACC (Weighted Average Cost of Capital):** blended discount rate. = (E/V)·Ke + (D/V)·Kd·(1−Tax).

**Ke (Cost of Equity):** return required by equity holders. CAPM: Ke = Rf + β·(Rm−Rf).

**ERP (Equity Risk Premium):** Rm − Rf. Damodaran reports it monthly; ~4.5% as of Apr 2026.

**Beta:** stock's volatility relative to market. β = Cov(stock,market) / Var(market). Template uses max-of-three for conservatism.

**NOPAT (Net Operating Profit After Tax):** EBIT × (1 − Tax). Tax rate is statutory, not effective, for through-cycle consistency.

**NWC (Net Working Capital):** Operating Current Assets − Operating Current Liabilities. Excludes cash and short-term debt (those are financing items, not operating).

**Terminal Value (TV):** Gordon perpetuity capitalization of FCFF at the end of the explicit forecast. TV = FCFF_terminal × (1+g) / (WACC−g).

**Stage 2:** in a Two-Stage DCF, the years between the explicit forecast end (Y5) and the terminal year (Y10). Growth rate in Stage 2 typically blends from end-of-explicit growth toward terminal g.

**Reverse DCF:** solve the DCF equation for the perpetual growth rate g that matches market price. Useful for surfacing what the market implicitly believes.

**Mid-cycle factor:** multiplier on historical CapEx/Sales (or NWC/Sales) ratio to normalize toward through-cycle averages over the forecast horizon. Memory at peak: 0.75. Software (no cycle): 1.00.

**Sanity gate:** structural check. WACC > 4% guarantees the Gordon perpetuity converges. Terminal share < 75% (5Y) / < 65% (10Y) guards against terminal-value-driven valuations.

**Cyclicality guard:** weight reduction on multiples that are stretched vs market price. Prevents one peak-cycle multiple from dominating the blend.

---

## 23. Key cell reference table

| Cell | What |
|---|---|
| Required Return!C5 | Current stock price |
| Required Return!C6 | Shares outstanding |
| Required Return!C8/C9 | Short-term / Long-term debt |
| Required Return!C44 | Tax rate (23% statutory default) |
| Required Return!C52 | Conservative WACC |
| Required Return!C54 | Average WACC (base) |
| Required Return!C63 | Sanity gate (PASS/FAIL) |
| Cash Flow Forecast!B8 | Total Revenue base year |
| Cash Flow Forecast!B39 | Y1 revenue growth assumption |
| Cash Flow Forecast!B44 | Y1 EBIT margin |
| Cash Flow Forecast!H26-H33 | Historical ratio averages (4-tier fallback) |
| Cash Flow Forecast!B65:F65 | FCFF Y1-Y5 |
| Valuation Estimates!B16 | Net Debt |
| Valuation Estimates!B20 | Pessimistic DCF/share |
| Valuation Estimates!D20 | Base Case DCF/share |
| Valuation Estimates!F20 | Optimistic DCF/share |
| Valuation Estimates!H25 | Wtd. Scenario Valuation |
| Valuation Estimates!B84 | Two-Stage (10-Year) DCF |
| Cover!C12-C19 | Valuation Summary methodology table |
| Cover!C30 | WACC (Base) |
| Cover!C33 | Net Debt |
| Cover!C35 | Reverse DCF Implied g |
| Reverse DCF!C9 | Market Enterprise Value |
| Reverse DCF!C36 | Premium for unjustified perpetual growth ($M) |
| Reverse DCF!C42 | IMPLIED REQUIRED PERPETUAL g |
| Reverse DCF!C46 | VERDICT cell (FAIR / STRETCHED / AGGRESSIVE / STRUCTURALLY UNJUSTIFIABLE) |
| Industry!E14:E20 | Target multi-year ratios (Tier 1a Python) |
| Industry!B14:B20 | Peer industry ratios (Tier 2) |
| Industry!C14:C20 | CONFIG analyst values (Tier 3) |
| Industry!D14:D20 | Effective ratio used by CFF formulas |

---

## 24. Sector preset matrix

When `CAPEX_MID_CYCLE_FACTOR = None` and `NWC_MID_CYCLE_FACTOR = None` in Cell 3, the model auto-detects from `CONFIG.sector`:

| Sector pattern (regex) | CapEx | NWC | Rationale |
|---|---|---|---|
| `memory|hbm|dram|nand` | 0.75 | 0.85 | Memory/HBM peak — CapEx normalizes 25% over 5Y |
| `semiconductor|semis|fab|foundry` | 0.85 | 0.90 | Broad semis at mid-cycle reinvestment |
| `oil|gas|energy|e&p|exploration` | 0.80 | 0.95 | Commodity cycle DD&A normalization |
| `auto|automotive|vehicle|truck` | 0.90 | 0.95 | Platform refresh cadence |
| `steel|metal|mining|chemical` | 0.85 | 0.95 | Through-cycle CapEx |
| `airline|airlines|aerospace|defense` | 0.95 | 1.00 | Fleet renewal mid-cycle |
| `reit|real estate|property` | 0.95 | 1.05 | Steady maintenance CapEx |
| `util|utility|utilities|power` | 1.00 | 1.00 | Regulated CapEx schedule |
| `telecom|wireless|cable` | 1.05 | 1.00 | 5G/fiber buildout step-up |
| `bank|financial|insurance` | 1.00 | 1.00 | Minimal CapEx |
| `software|saas|cloud|internet|platform` | 1.00 | 1.00 | Capital-light, no taper |
| `pharma|biotech|drug|medical|health` | 1.00 | 1.05 | Stable CapEx, working-capital build |
| `consumer|retail|staples|discretion` | 1.00 | 1.00 | Steady reinvestment |
| `media|entertainment|gaming` | 1.00 | 1.00 | Variable, default flat |
| (no match) | 1.00 | 1.00 | Fall-through |

To override the sector default, set an explicit float in Cell 3:
- `CAPEX_MID_CYCLE_FACTOR = 0.55` — more aggressive normalization (DCF goes up)
- `CAPEX_MID_CYCLE_FACTOR = 0.95` — less normalization (DCF goes down)

The taper is **linear** from year 1 to year 5: CapEx ratio Y_k = historical_avg × (1 + (k/5) × (factor − 1)).

---

## End

You have everything you need. Open the workbook, edit Cell 3, run the pipeline, defend the output. Every number traces back to a documented source. Every assumption is yours to own.

If your DCF is right and you can articulate why, you'll outperform 80% of analysts in your cohort. If your assumptions are wrong, no model will save you.

The template is a tool. The analysis is yours.
