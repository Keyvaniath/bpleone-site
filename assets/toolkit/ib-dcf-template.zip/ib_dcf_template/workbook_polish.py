"""
workbook_polish.py — Audit #7 — workbook-wide cosmetic + text cleanup pass.

WHY THIS EXISTS
───────────────
The `required_return.py` module already does text substitutions (FactSet →
yfinance/SEC, EFP → ERP, TCM → WACC, "me gusta la stocka" purge), but ONLY
on the Required Return tab. A full audit found 10+ stale TCM occurrences
on Cash Flow Forecast and Scenario Analysis, plus a large block of stale
FactSet documentation on the Instructions tab that the user-facing model
shouldn't ship with.

This module extends those substitutions across EVERY tab in the workbook,
plus applies a small set of formatting normalizations so the output looks
IB-presentable: consistent fonts, clean number formats, no stray
fills, sensible column widths.

It does NOT touch:
  - Formula logic (the Audit-#1..#6 modules own that).
  - Cell values that are real financial data (skips numeric cells).
  - Cell colors that are part of the documented input/output convention
    (yellow = manual input, theme-5 = formula pull, navy = section header).

Idempotent — safe to re-run on a clean or dirty workbook.

USAGE
─────
Called at the END of dcf_refresh.refresh_data() pipeline, after all the
other audits have run:

    import workbook_polish
    workbook_polish.apply(workbook_path)

Returns a dict of {tab: {fix: count}} for logging.
"""
from __future__ import annotations
import os
import re
from openpyxl import load_workbook
from openpyxl.styles import Font, Alignment, PatternFill
from openpyxl.comments import Comment


# ═══════════════════════════════════════════════════════════════════════════
#  Text substitutions — workbook-wide
# ═══════════════════════════════════════════════════════════════════════════
#
# Each rule is (pattern, replacement). re.IGNORECASE is applied. Order
# matters — earlier rules run first, so put more specific patterns before
# general ones.
TEXT_SUBS = [
    # Audit #7 user-explicit: purge "TCM" anywhere it appears.
    # Example phrasing in CFF/SA:
    #   "< Annualized avg TCM forecast revenue growth"
    # becomes:
    #   "< Annualized avg forecast revenue growth"
    # We strip TCM with surrounding whitespace and collapse, so the result
    # reads naturally.
    (re.compile(r"\bTarget Cost of Money\b", re.IGNORECASE), "Average WACC"),
    (re.compile(r"\s+TCM\s+", re.IGNORECASE), " "),     # interior occurrence
    (re.compile(r"^TCM\s+", re.IGNORECASE), ""),        # leading
    (re.compile(r"\s+TCM$", re.IGNORECASE), ""),        # trailing
    (re.compile(r"\bTCM\b", re.IGNORECASE), ""),        # standalone catch-all

    # Audit #1..#3 carryovers — required_return.py only handles the RR tab,
    # but FactSet references show up on Instructions and SA too.
    (re.compile(r"FactSet", re.IGNORECASE), "yfinance/SEC"),
    (re.compile(r"\bEFP\b"), "ERP"),

    # Joke purge (Session-1 cleanup that never ran outside RR).
    (re.compile(r"me gusta la stocka", re.IGNORECASE), ""),
]

# Cells we DON'T touch — labels that are essential to formula lookups.
# (The TCM patterns above won't hit these because none contain "TCM".)
PROTECTED_LABELS = {
    "Sales", "Total Revenue", "EBIT", "EBITDA", "Net Income", "Pretax Income",
    "Long-Term Debt", "Long-Term Debt (incl. Leases)",
    "Short-Term Debt", "ST Debt & Curr. Portion LT Debt",
    "Capital Expenditures", "Depreciation, Depletion & Amortization",
    "Common Equity", "Cash & Short-Term Investments",
    "Total Current Assets", "Total Current Liabilities",
    "Target Price", "Diluted Shares Outstanding",
    "Effective Tax Rate", "Free Cash Flow",
}


# ═══════════════════════════════════════════════════════════════════════════
#  Formatting normalization
# ═══════════════════════════════════════════════════════════════════════════
NAVY_BOLD   = Font(name="Calibri", size=11, bold=True, color="1F3864")
GREY_ITAL   = Font(name="Calibri", size=10, italic=True, color="595959")
BLACK_REG   = Font(name="Calibri", size=11, color="000000")

# A faint header fill for new section dividers (only applied to cells we
# explicitly add — we don't repaint the user's existing headers).
HEADER_FILL = PatternFill("solid", start_color="DDEBF7")  # light navy tint


# ═══════════════════════════════════════════════════════════════════════════
#  Helpers
# ═══════════════════════════════════════════════════════════════════════════
def _apply_text_subs(text: str) -> tuple[str, bool]:
    """Apply all TEXT_SUBS to a string. Return (new_string, was_modified).

    Protects the PROTECTED_LABELS — if the input matches one of them
    exactly, return it unchanged (those are formula lookup keys; modifying
    them would silently break VLOOKUPs across the workbook).
    """
    if text in PROTECTED_LABELS:
        return text, False
    out = text
    for pat, repl in TEXT_SUBS:
        out = pat.sub(repl, out)
    # Collapse repeated whitespace introduced by deletions.
    out = re.sub(r"\s{2,}", " ", out).strip()
    return out, (out != text)


# ═══════════════════════════════════════════════════════════════════════════
#  Polish passes
# ═══════════════════════════════════════════════════════════════════════════
def _pass_text_subs_all_tabs(wb) -> dict:
    """Apply TEXT_SUBS across every cell value, every formula's literal
    string portions (CAREFULLY — we don't want to rewrite cell references),
    and every comment.

    For formulas, we only rewrite if the formula contains a literal
    string in quotes (e.g. VLOOKUP("Target Cost of Money", ...)) — that
    way we don't accidentally munge cell ranges or function names.
    """
    counts = {}
    for ws in wb.worksheets:
        n = 0
        for row in ws.iter_rows():
            for cell in row:
                v = cell.value
                # Plain text
                if isinstance(v, str) and not v.startswith("="):
                    new, changed = _apply_text_subs(v)
                    if changed:
                        # Empty result → blank the cell entirely
                        cell.value = new if new else None
                        n += 1
                # Formulas — only modify if a quoted-string literal needs subbing
                elif isinstance(v, str) and v.startswith("="):
                    # Find quoted-string literals
                    quoted = re.findall(r'"([^"]*)"', v)
                    new_v = v
                    changed_any = False
                    for q in quoted:
                        new_q, changed = _apply_text_subs(q)
                        if changed and q not in PROTECTED_LABELS:
                            new_v = new_v.replace(f'"{q}"', f'"{new_q}"')
                            changed_any = True
                    if changed_any:
                        cell.value = new_v
                        n += 1
                # Comments
                if cell.comment and cell.comment.text:
                    new_t, changed = _apply_text_subs(cell.comment.text)
                    if changed:
                        cell.comment = (
                            Comment(new_t, cell.comment.author or "polish")
                            if new_t else None
                        )
                        n += 1
        if n > 0:
            counts[ws.title] = n
    return counts


def _pass_template_normalization(wb) -> int:
    """Audit #10 — make user-facing strings ticker-agnostic.

    A handful of cells on Segment Revenue and Instructions tabs were
    written into the original .xlsm as static text mentioning "MU",
    "Micron", or the obsolete notebook name "DCF_Notebook_v3.ipynb".
    These don't auto-update when the user repoints — they need an
    explicit pass that pushes the current CONFIG values in.

    Without this, a downloader who opens the .xlsm fresh sees Micron
    references on tabs that should be ticker-neutral.
    """
    n = 0

    # Late import — preserve standalone usability if dcf_config absent
    try:
        from dcf_config import CONFIG
        ticker = getattr(CONFIG, "ticker", "TICKER") or "TICKER"
        segments = getattr(CONFIG, "segments", []) or []
        seg_names = " / ".join(s.name for s in segments) if segments else "(no segments)"
    except Exception:
        ticker = "TICKER"
        seg_names = "(no segments)"

    # 1. Segment Revenue!A1 — title with ticker + segment names
    if "Segment Revenue" in wb.sheetnames:
        seg = wb["Segment Revenue"]
        if seg["A1"].value:
            new_a1 = f"{ticker} Bottoms-Up Revenue Build — {seg_names}"
            if seg["A1"].value != new_a1:
                seg["A1"].value = new_a1
                n += 1

        # 2. Segment Revenue!A23 — base-year reference note
        # Use a live formula so the dollar figure auto-updates with revenue refresh
        new_a23 = (
            f'="FY base $"&TEXT(\'Cash Flow Forecast\'!B8/1000,"0.0")'
            f'&"B matches CFF!B8 actuals. Segment split per {ticker} 10-K disclosure."'
        )
        if seg["A23"].value and "MU" in str(seg["A23"].value):
            seg["A23"].value = new_a23
            n += 1

        # 3. Segment Revenue!H9 — was hardcoded "NVDA/AMD HBM3E demand..."
        # Replace with a generic analyst-fillable placeholder; user customizes.
        if seg["H9"].value and isinstance(seg["H9"].value, str):
            v = seg["H9"].value
            if any(t in v for t in ("NVDA", "AMD", "HBM3E", "Micron")):
                seg["H9"].value = "Segment-specific demand driver — analyst note"
                n += 1

    # 4. Instructions!C13 — update notebook version + cell reference
    # Use a generic <YOUR_TICKER> placeholder so it's clearly an example,
    # not a holdover from a specific ticker.
    if "Instructions" in wb.sheetnames:
        ins = wb["Instructions"]
        v = ins["C13"].value
        new_c13 = (
            "Open DCF_Notebook_v4.ipynb and edit TARGET ticker in Cell 3 "
            "(e.g., TARGET = \"<YOUR_TICKER>\")"
        )
        if isinstance(v, str) and v != new_c13:
            ins["C13"].value = new_c13
            n += 1

    return n


def _pass_industry_block_format(wb) -> int:
    """Format the new Audit-#4/#6 Industry block (rows 13-20) — section header,
    column headers, consistent decimal-percent format on B14:E20.
    """
    if "Industry" not in wb.sheetnames:
        return 0
    ind = wb["Industry"]
    n = 0

    # Section header A13 — bold navy, fill across B13:E13
    if ind["A13"].value:
        ind["A13"].font = NAVY_BOLD
        for col in "BCDE":
            ind[f"{col}13"].font = NAVY_BOLD
            ind[f"{col}13"].fill = HEADER_FILL
            ind[f"{col}13"].alignment = Alignment(horizontal="center")
        n += 5

    # Body rows 14-20 — italic gray label in column A, percent format on B/C/D/E
    for r in range(14, 21):
        if ind[f"A{r}"].value:
            ind[f"A{r}"].font = GREY_ITAL
            for col in "BCDE":
                ind[f"{col}{r}"].number_format = '0.00%;(0.00%);"—"'
                ind[f"{col}{r}"].alignment = Alignment(horizontal="right")
            n += 1

    # Column widths — A wider for labels, B-E uniform for numbers
    ind.column_dimensions["A"].width = 28
    for col in "BCDE":
        ind.column_dimensions[col].width = 16

    return n


def _fix_zero_alpha_colors(workbook_path: str) -> int:
    """Audit #13 — fix 00-alpha rgb codes in styles.xml.

    BACKGROUND
    ──────────
    OOXML colors use 8-char rgb codes with format AARRGGBB:
      - AA = alpha channel (00 = transparent, FF = opaque)
      - RRGGBB = the actual color

    openpyxl sometimes serializes Font/Fill colors as "00XXXXXX" instead
    of "FFXXXXXX" — meaning fully transparent. For Excel:
      - Fill with 00-alpha: doesn't render the fill (silent issue)
      - FONT with 00-alpha: silent issue OR Excel flags as malformed and
        triggers the "We found a problem with some content" repair dialog

    This pass scans styles.xml and replaces every rgb="00XXXXXX" with
    rgb="FFXXXXXX". Idempotent — no-op once the file is clean.

    Detected because Reverse DCF tab triggered repair dialogs even after
    earlier fixes; root cause was 5 dxf entries with 00-alpha font colors.
    """
    import zipfile, re, shutil
    if not os.path.exists(workbook_path):
        return 0

    tmp = workbook_path + '.alpha_fix'
    fixes = 0
    with zipfile.ZipFile(workbook_path, 'r') as z_in:
        with zipfile.ZipFile(tmp, 'w', zipfile.ZIP_DEFLATED) as z_out:
            for name in z_in.namelist():
                content = z_in.read(name)
                # Scan EVERY xml part — 00-alpha codes can be in sheet XMLs
                # (conditional formatting embedded directly in sheets uses them
                # too), not just styles.xml. Earlier fix that only scanned
                # styles.xml left sheet3.xml and sheet18.xml with bad codes.
                if name.endswith('.xml') or name.endswith('.rels'):
                    try:
                        text = content.decode('utf-8')
                    except UnicodeDecodeError:
                        z_out.writestr(name, content)
                        continue
                    new_text = re.sub(
                        r'rgb="00([0-9A-Fa-f]{6})"',
                        lambda m: f'rgb="FF{m.group(1).upper()}"',
                        text
                    )
                    fixes += (text.count('rgb="00') - new_text.count('rgb="00'))
                    content = new_text.encode('utf-8')
                z_out.writestr(name, content)
    shutil.move(tmp, workbook_path)
    return fixes


def _strip_broken_charts(workbook_path: str) -> int:
    """Audit #12 — strip chart XML/drawings that openpyxl has corrupted.

    BACKGROUND
    ──────────
    The original template ships with 5 embedded Excel charts. openpyxl
    loads them as `ChartSpace` objects but does NOT preserve their cell
    range references (`<c:f>` elements) on save. After each round-trip the
    chart files have all their formatting/colors but ZERO data bindings.

    Excel sees a chart shell with no data and triggers the "Repairs to
    workbook.xlsm" dialog every open: "Removed Records: Drawing from
    /xl/drawings/drawing*.xml part" and similar. Even after Excel
    "repairs" the file, the next pipeline run re-introduces the
    corruption — perpetual repair loop.

    THE FIX
    ───────
    Strip charts entirely from the .xlsm zip after the last save:
      - Delete every `xl/charts/chart*.xml` file
      - Delete `xl/drawings/drawing*.xml` files that contain chart refs
        (preserve image-only drawings like the Damodaran brain icon)
      - Update [Content_Types].xml to drop chart + chart-drawing types
      - Update each sheet's `_rels/sheetN.xml.rels` to drop chart-drawing
        relationships
      - Remove `<drawing>` element references from sheet XML where the
        target drawing was deleted

    Charts are cosmetic — every number they visualize is in the workbook
    tables (Cover, Valuation Summary, Peer Comparison, Debt Maturity).
    Trade-off: lose 5 chart visualizations, gain a workbook that opens
    cleanly without ever triggering Excel's repair dialog again.
    """
    import zipfile, re, os, tempfile, shutil

    if not os.path.exists(workbook_path):
        return 0

    tmp_path = workbook_path + '.tmp'
    n_removed = 0

    with zipfile.ZipFile(workbook_path, 'r') as z_in:
        all_names = z_in.namelist()

        # 1. Identify chart files + chart-bearing drawing files
        chart_files = {n for n in all_names if re.match(r'xl/charts/chart\d+\.xml$', n)}
        chart_rel_files = {n for n in all_names if re.match(r'xl/charts/_rels/chart\d+\.xml\.rels$', n)}

        chart_drawing_files = set()
        for n in all_names:
            if re.match(r'xl/drawings/drawing\d+\.xml$', n):
                content = z_in.read(n).decode('utf-8', errors='replace')
                if '<chart' in content or 'chart"' in content or 'graphicFrame' in content:
                    # has chart reference — but drawings can also have
                    # images. Only strip if it's chart-only.
                    has_chart = bool(re.search(r'graphicFrame|<chart|chartType', content))
                    has_image = bool(re.search(r'<pic|blipFill|/image\d', content))
                    if has_chart and not has_image:
                        chart_drawing_files.add(n)
                    elif has_chart and has_image:
                        # Mixed: leave alone, would need surgical edit
                        pass

        chart_drawing_rels = set()
        for n in all_names:
            if re.match(r'xl/drawings/_rels/drawing\d+\.xml\.rels$', n):
                # Match drawing*.xml file pattern
                drawing_xml = n.replace('_rels/', '').rstrip('.rels')
                if drawing_xml in chart_drawing_files:
                    chart_drawing_rels.add(n)

        files_to_remove = chart_files | chart_rel_files | chart_drawing_files | chart_drawing_rels

        # Build a mapping: drawing_n.xml → its drawing relationship ID, so we
        # can remove matching <drawing> elements from sheet XMLs.
        drawing_indices_to_drop = set()
        for d in chart_drawing_files:
            m = re.search(r'drawing(\d+)\.xml', d)
            if m:
                drawing_indices_to_drop.add(int(m.group(1)))

        # 2. Walk through and write a new zip without the chart files
        sheets_with_dropped_rids = {}
        with zipfile.ZipFile(tmp_path, 'w', zipfile.ZIP_DEFLATED) as z_out:
            for name in all_names:
                if name in files_to_remove:
                    n_removed += 1
                    continue

                content = z_in.read(name)

                # Patch [Content_Types].xml — drop chart + chart-drawing types
                if name == '[Content_Types].xml':
                    text = content.decode('utf-8')
                    # Remove Override entries pointing at deleted chart parts
                    for f in chart_files:
                        text = re.sub(rf'<Override[^/]*PartName="/{re.escape(f)}"[^/]*/>',
                                      '', text)
                    for f in chart_drawing_files:
                        text = re.sub(rf'<Override[^/]*PartName="/{re.escape(f)}"[^/]*/>',
                                      '', text)
                    content = text.encode('utf-8')

                # Patch sheet *.xml.rels — drop relationships to dead drawings.
                # ORDER-INSENSITIVE: extract attributes from each
                # <Relationship .../> tag individually so we don't depend on
                # whether Id comes before or after Target in the XML.
                elif re.match(r'xl/worksheets/_rels/sheet\d+\.xml\.rels$', name):
                    text = content.decode('utf-8')
                    rIds_dropped = []
                    if drawing_indices_to_drop:
                        new_text = text
                        for tag_match in re.finditer(r'<Relationship\s[^>]*/>', text):
                            tag = tag_match.group(0)
                            target_m = re.search(
                                r'Target="([^"]+drawing(\d+)\.xml)"', tag
                            )
                            id_m = re.search(r'Id="([^"]+)"', tag)
                            if target_m and id_m:
                                idx = int(target_m.group(2))
                                if idx in drawing_indices_to_drop:
                                    rIds_dropped.append(id_m.group(1))
                                    new_text = new_text.replace(tag, '')
                        text = new_text
                    content = text.encode('utf-8')

                    # Stash the dropped rIds so we can patch the sheet XML
                    # in a second pass below
                    sheet_num = re.search(r'sheet(\d+)', name).group(1)
                    sheets_with_dropped_rids.setdefault(sheet_num, []).extend(rIds_dropped)

                z_out.writestr(name, content)

            # Second pass — patch sheet XML files to remove <drawing
            # r:id="rIdN"/> elements whose rId was dropped above.
            # zipfile doesn't let us rewrite during iteration, so we re-open.

        # Re-open and patch sheet XMLs if any rIds were dropped
        if sheets_with_dropped_rids:
            tmp2 = workbook_path + '.tmp2'
            with zipfile.ZipFile(tmp_path, 'r') as z_read:
                with zipfile.ZipFile(tmp2, 'w', zipfile.ZIP_DEFLATED) as z_write:
                    for nm in z_read.namelist():
                        c = z_read.read(nm)
                        msheet = re.match(r'xl/worksheets/sheet(\d+)\.xml$', nm)
                        if msheet and msheet.group(1) in sheets_with_dropped_rids:
                            sn = msheet.group(1)
                            t = c.decode('utf-8')
                            for rid in sheets_with_dropped_rids[sn]:
                                t = re.sub(
                                    rf'<drawing[^>]*r:id="{rid}"[^>]*/>',
                                    '', t
                                )
                            c = t.encode('utf-8')
                        z_write.writestr(nm, c)
            shutil.move(tmp2, tmp_path)

    shutil.move(tmp_path, workbook_path)
    return n_removed


def _pass_fix_equals_prefix_labels(wb) -> int:
    """Audit #16 — convert "= some label text" cells to plain text.

    BACKGROUND
    ──────────
    Cells whose string value starts with '=' are written by openpyxl as
    formulas. Strings like "= Market Enterprise Value ($M)" — meant as a
    visual prefix — Excel tries to parse as a formula, fails, and reports:
        Removed Records: Formula from /xl/worksheets/sheetN.xml part
    triggering the "We found a problem with some content" repair dialog.

    HEURISTIC
    ─────────
    A real formula has '=' followed immediately by a function name,
    cell ref, sheet ref, or operator/number. A label has '=' followed by
    a SPACE. We rewrite cells matching the label pattern by stripping the
    leading '=' and any whitespace, then writing the value as plain text
    (Excel won't try to parse it as a formula).

    Returns the count of cells fixed.
    """
    fixed = 0
    for ws in wb.worksheets:
        for row in ws.iter_rows():
            for cell in row:
                v = cell.value
                if not isinstance(v, str):
                    continue
                if not v.startswith("="):
                    continue
                # Real formulas don't have a space immediately after '='.
                if v[1:2] == " ":
                    new_value = v[1:].lstrip()
                    cell.value = new_value
                    # Force text format so future edits don't re-promote it
                    if cell.number_format == "General":
                        cell.number_format = "@"
                    fixed += 1
    return fixed


def _pass_kill_stray_borders(wb) -> int:
    """Drop stray border styles inherited from the legacy template that
    add visual noise (random thick borders mid-table). Only touches cells
    where the border is NOT part of an explicit grid (e.g. data tables
    with consistent border patterns are preserved).
    """
    # Conservative — don't touch any borders for now. The current template's
    # borders are mostly fine; aggressive removal could lose intentional
    # section dividers. Left as a hook for a future pass.
    return 0


def _strip_image_drawings(workbook_path: str) -> int:
    """Audit #15 — strip image-only drawings (e.g. the Damodaran brain icon).

    BACKGROUND
    ──────────
    Excel's recovery log on this workbook reported:
        Repaired Records: Drawing from /xl/drawings/drawing1.xml part
        (Drawing shape)
    Even after the chart-strip pass (Audit #12) cleaned chart-bearing
    drawings, an image-anchor drawing remained that Excel flags on every
    open. The drawing references an image part via a relationship; openpyxl
    occasionally writes the relationship target with a path Excel can't
    resolve (case-sensitivity, escaping). Rather than diagnose every
    edge case, this pass removes ALL remaining drawings — they were a
    cosmetic addition (brain icon for "thinking") and not load-bearing
    for any analysis.

    HOW IT WORKS
    ────────────
    Walk the .xlsm zip. For each `xl/drawings/drawingN.xml`:
      1. Mark it for deletion.
      2. Mark `xl/drawings/_rels/drawingN.xml.rels` for deletion.
      3. Drop image media files referenced ONLY by these drawings.
      4. Patch [Content_Types].xml — remove drawing+image overrides.
      5. Patch each sheet's `_rels/sheetN.xml.rels` — drop drawing rels.
      6. Patch each sheet XML — drop the orphan `<drawing r:id="...">`.

    Returns the count of drawing parts removed. Idempotent.
    """
    import zipfile, re, shutil
    if not os.path.exists(workbook_path):
        return 0

    tmp = workbook_path + '.drawing_strip'
    drawings_removed = 0

    with zipfile.ZipFile(workbook_path, 'r') as z_in:
        names = list(z_in.namelist())

        # 1. All drawing parts + their rels
        drawing_files = {n for n in names if re.match(r'xl/drawings/drawing\d+\.xml$', n)}
        drawing_rels  = {n for n in names if re.match(r'xl/drawings/_rels/drawing\d+\.xml\.rels$', n)}

        # 2. Drawing indices being removed (so we know which sheet rels to clean)
        indices_to_drop = set()
        for d in drawing_files:
            m = re.search(r'drawing(\d+)\.xml', d)
            if m:
                indices_to_drop.add(int(m.group(1)))

        # 3. Image media files referenced by these drawing rels.
        # Targets can be either relative (../media/imageN.png) or absolute
        # (/xl/media/imageN.png). Handle both.
        media_files_to_drop = set()
        for rel_path in drawing_rels:
            try:
                rel_xml = z_in.read(rel_path).decode('utf-8', errors='ignore')
            except KeyError:
                continue
            # Relative targets
            for tgt in re.findall(r'Target="(\.\./media/[^"]+)"', rel_xml):
                media_files_to_drop.add('xl/' + tgt.replace('../', ''))
            # Absolute targets (leading slash)
            for tgt in re.findall(r'Target="/xl/(media/[^"]+)"', rel_xml):
                media_files_to_drop.add('xl/' + tgt)

        files_to_remove = drawing_files | drawing_rels | media_files_to_drop
        drawings_removed = len(drawing_files)

        if drawings_removed == 0:
            return 0

        with zipfile.ZipFile(tmp, 'w', zipfile.ZIP_DEFLATED) as z_out:
            for name in names:
                if name in files_to_remove:
                    continue
                data = z_in.read(name)

                # Patch [Content_Types].xml — drop drawing + image type overrides.
                # Use [^>]*? (lazy match-anything-but-close-bracket) instead of
                # [^/]* — ContentType strings contain '/' (e.g. application/vnd...
                # +xml), so the older regex never matched and the override stayed.
                if name == '[Content_Types].xml':
                    text = data.decode('utf-8')
                    for d in drawing_files:
                        partname = '/' + d
                        text = re.sub(
                            rf'<Override\s+PartName="{re.escape(partname)}"[^>]*?/>',
                            '', text)
                    # Also drop overrides for any media files we removed
                    for media in media_files_to_drop:
                        partname = '/' + media
                        text = re.sub(
                            rf'<Override\s+PartName="{re.escape(partname)}"[^>]*?/>',
                            '', text)
                    data = text.encode('utf-8')

                # Patch sheet rels — drop relationships pointing at removed drawings.
                # Targets can be relative ("../drawings/drawingN.xml") OR absolute
                # ("/xl/drawings/drawingN.xml"); the earlier regex only caught the
                # relative form so absolute-path rels survived → Excel choke on load.
                if re.match(r'xl/worksheets/_rels/sheet\d+\.xml\.rels$', name):
                    text = data.decode('utf-8')
                    new_text = text
                    # [^>]*? not [^/]*? — relationship Type URLs contain '/',
                    # so the older regex never matched and dead rels survived.
                    for tag in re.findall(r'<Relationship[^>]*?/>', text):
                        m_target = re.search(
                            r'Target="(?:\.\./|/xl/)drawings/drawing(\d+)\.xml"',
                            tag,
                        )
                        if not m_target:
                            continue
                        if int(m_target.group(1)) in indices_to_drop:
                            new_text = new_text.replace(tag, '')
                    data = new_text.encode('utf-8')

                # Patch sheet XML — drop <drawing r:id="..."/> tags whose rels
                # were just removed. Cheap & safe heuristic: drop ALL <drawing/>
                # tags from sheets, since we removed all drawing parts.
                if re.match(r'xl/worksheets/sheet\d+\.xml$', name):
                    text = data.decode('utf-8')
                    # [^>] not [^/] — be consistent with the rels-patch regex
                    new_text = re.sub(r'<drawing\s+[^>]*?/>', '', text)
                    data = new_text.encode('utf-8')

                z_out.writestr(name, data)

    shutil.move(tmp, workbook_path)
    return drawings_removed


# ═══════════════════════════════════════════════════════════════════════════
#  Public entry point
# ═══════════════════════════════════════════════════════════════════════════
def apply(workbook_path: str) -> dict:
    """Run all polish passes on the workbook. Returns a summary dict."""
    if not os.path.exists(workbook_path):
        raise FileNotFoundError(workbook_path)

    wb = load_workbook(workbook_path, keep_vba=True)

    text_counts = _pass_text_subs_all_tabs(wb)
    template_count = _pass_template_normalization(wb)
    fmt_count   = _pass_industry_block_format(wb)
    border_count = _pass_kill_stray_borders(wb)
    # Audit #16 — convert "= label text" cells to plain strings (Excel was
    # trying to parse them as formulas → repair dialog).
    eq_label_fixes = _pass_fix_equals_prefix_labels(wb)

    # NB: chart strip happens AFTER wb.save() below — has to operate on
    # the saved zip, not the in-memory workbook.

    wb.save(workbook_path)

    # Audit #12 — strip broken charts AFTER save (operates on the zip directly)
    charts_removed = _strip_broken_charts(workbook_path)

    # Audit #13 — fix 00-alpha rgb codes in styles.xml that openpyxl
    # serializes as fully-transparent colors. This was the actual cause of
    # the recurring "We found a problem with some content" Excel dialog.
    alpha_fixes = _fix_zero_alpha_colors(workbook_path)

    # Audit #15 — strip leftover image-only drawings (e.g. brain icon).
    # Excel's recovery log specifically named drawing1.xml as needing
    # repair on every open. Easiest fix is to remove these decorative
    # drawings entirely — they're not load-bearing for any analysis.
    drawings_removed = _strip_image_drawings(workbook_path)

    total_text = sum(text_counts.values())
    print(f"  ✓  workbook_polish complete")
    if charts_removed:
        print(f"     • Stripped {charts_removed} corrupted chart parts (Audit #12)")
    if alpha_fixes:
        print(f"     • Fixed {alpha_fixes} 00-alpha rgb codes in styles.xml (Audit #13)")
    if drawings_removed:
        print(f"     • Stripped {drawings_removed} leftover image drawings (Audit #15)")
    if eq_label_fixes:
        print(f"     • Demoted {eq_label_fixes} '= label' cells to plain text (Audit #16)")
    print(f"     • Text substitutions applied: {total_text} cells across {len(text_counts)} tabs")
    for tab, n in sorted(text_counts.items(), key=lambda kv: -kv[1]):
        print(f"         {tab:<25} : {n}")
    if template_count:
        print(f"     • Template normalization (Audit #10): {template_count} cells")
    print(f"     • Industry block format: {fmt_count} cells styled")
    if border_count:
        print(f"     • Stray borders removed: {border_count}")

    return {
        "text_subs": text_counts,
        "industry_format": fmt_count,
    }


if __name__ == "__main__":
    import sys
    apply(sys.argv[1] if len(sys.argv) > 1 else "DCF_Final.xlsm")
