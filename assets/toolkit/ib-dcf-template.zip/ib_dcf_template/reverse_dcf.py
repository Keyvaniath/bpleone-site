"""
reverse_dcf.py - Audit #9 - Reverse DCF Decomposition tab.

WHAT THIS DOES
──────────────
Builds a new "Reverse DCF" worksheet that decomposes the market enterprise
value into three buckets:

    1. PV of the explicit 5Y FCFF forecast      (live-linked to CFF!B65:F65)
    2. PV of the terminal value at "reasonable" g  (CONFIG.terminal_growth)
    3. RESIDUAL - the value the market is paying for that explicit-forecast
       and reasonable-terminal-growth combined cannot justify.

It then **reverse-solves** for the perpetual growth rate the market price
implicitly requires:

    EV_market = Σ PV(FCFF_y) + TV_required / (1+WACC)^5
    TV_required = FCFF_Y5 × (1+g) / (WACC − g)
    →  g = (TV_required × WACC − FCFF_Y5) / (TV_required + FCFF_Y5)

The verdict cell auto-classifies the implied g vs. long-run GDP growth
(~3.5% US nominal). For an UNDERWEIGHT thesis, the strongest argument is
"market is pricing perpetual-growth assumptions that are mathematically
impossible." This tab quantifies that argument live and lets you point at
the cell during the IC pitch.

PORTABILITY
───────────
Fully ticker-agnostic. Every value flows from:
  - 'Required Return'!C5  (live stock price from yfinance)
  - 'Required Return'!C6  (shares outstanding)
  - 'Required Return'!C54 (WACC base)
  - 'Valuation Estimates'!B16  (Net Debt)
  - 'Cash Flow Forecast'!B65:F65  (FCFF Y1-Y5)
  - CONFIG.terminal_growth  (reasonable terminal g - sector-tunable)

No company names hardcoded. Anyone downloads the template, runs the
notebook on their ticker, this tab populates correctly.

USAGE
─────
Wired into dcf_refresh.py as step [9/9]. Idempotent - safe to re-run.

    import reverse_dcf
    reverse_dcf.apply(workbook_path)
"""
from __future__ import annotations
import os
from openpyxl import load_workbook
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
# Audit #14 — DifferentialStyle / Rule imports removed. Conditional formatting
# on the verdict cell was a recurring source of Excel "repair dialog" warnings
# (CF rules referencing long-string formulas occasionally serialize as malformed
# XML). The new tier-number + INDEX lookup pattern is bulletproof and needs no
# conditional formatting — color emphasis is applied via static font colors.


# ── Style constants (match the rest of the template) ──────────────────────
NAVY_BOLD     = Font(name="Calibri", size=12, bold=True, color="FFFFFFFF")
NAVY_FILL     = PatternFill("solid", start_color="FF1F3864")
SECTION_HDR   = Font(name="Calibri", size=11, bold=True, color="FF1F3864")
LIGHT_NAVY    = PatternFill("solid", start_color="FFDDEBF7")
SUBTLE_GREY   = PatternFill("solid", start_color="FFF2F2F2")
LABEL_FONT    = Font(name="Calibri", size=11, color="FF000000")
NOTE_FONT     = Font(name="Calibri", size=10, italic=True, color="FF595959")
NUM_FONT      = Font(name="Calibri", size=11, color="FF000000")
HIGHLIGHT_FONT = Font(name="Calibri", size=11, bold=True, color="FFC00000")
GREEN_FONT    = Font(name="Calibri", size=11, bold=True, color="FF548235")
THIN_BORDER   = Border(top=Side(style="thin", color="FFBFBFBF"),
                       bottom=Side(style="thin", color="FFBFBFBF"))


def _set(ws, coord, value, font=None, fill=None, fmt=None, align=None, border=None):
    cell = ws[coord]
    cell.value = value
    if font   is not None: cell.font = font
    if fill   is not None: cell.fill = fill
    if fmt    is not None: cell.number_format = fmt
    if align  is not None: cell.alignment = align
    if border is not None: cell.border = border


def apply(workbook_path: str) -> str:
    """Build the Reverse DCF tab. Idempotent - clears and rebuilds each run."""
    if not os.path.exists(workbook_path):
        raise FileNotFoundError(workbook_path)

    wb = load_workbook(workbook_path, keep_vba=True)

    # Drop existing Reverse DCF tab if present (rebuild clean each run)
    if "Reverse DCF" in wb.sheetnames:
        del wb["Reverse DCF"]
    ws = wb.create_sheet("Reverse DCF")

    # ── Column widths ──────────────────────────────────────────────────────
    # Column C is wide enough to hold the verdict text without needing a
    # merged-cell range (Excel's conditional formatting on merged cells can
    # trigger repair dialogs on open). Verdict cell C46 stays single-cell.
    widths = {"A": 42, "B": 14, "C": 64, "D": 14, "E": 14, "F": 14, "G": 18}
    for col, w in widths.items():
        ws.column_dimensions[col].width = w

    # ── Title bar ──────────────────────────────────────────────────────────
    ws.merge_cells("A1:G1")
    _set(ws, "A1",
         "REVERSE DCF - What does the market price imply about future growth?",
         font=NAVY_BOLD, fill=NAVY_FILL,
         align=Alignment(horizontal="center", vertical="center"))
    ws.row_dimensions[1].height = 22

    ws.merge_cells("A2:G2")
    _set(ws, "A2",
         "Decomposes market enterprise value into PV(explicit 5Y forecast) + "
         "PV(reasonable terminal) + residual. Reverse-solves for the implied "
         "perpetual growth rate the market price requires. All cells live-linked.",
         font=NOTE_FONT, align=Alignment(horizontal="left", wrap_text=True))
    ws.row_dimensions[2].height = 30

    # ── Section 1: Anchor inputs ──────────────────────────────────────────
    _set(ws, "A4", "1. ANCHOR INPUTS", font=SECTION_HDR, fill=LIGHT_NAVY)
    ws.merge_cells("A4:G4")

    rows_anchor = [
        ("A5", "Current Stock Price ($)",        "='Required Return'!C5",         '"$"#,##0.00'),
        ("A6", "Shares Outstanding (M)",         "='Required Return'!C6",         '#,##0'),
        ("A7", "Market Cap ($M)",                "=C5*C6",                         '"$"#,##0'),
        ("A8", "+ Net Debt ($M)",                "='Valuation Estimates'!B16",     '"$"#,##0'),
        ("A9", "Market Enterprise Value ($M)", "=C7+C8",                         '"$"#,##0'),
    ]
    for label_cell, label, formula, fmt in rows_anchor:
        _set(ws, label_cell, label, font=LABEL_FONT)
        row_num = label_cell[1:]
        _set(ws, f"C{row_num}", formula, font=NUM_FONT, fmt=fmt,
             align=Alignment(horizontal="right"))
    # bold the "Market EV" total row
    _set(ws, "A9", "Market Enterprise Value ($M)",
         font=Font(name="Calibri", size=11, bold=True))
    _set(ws, "C9", "=C7+C8", font=Font(name="Calibri", size=11, bold=True),
         fmt='"$"#,##0', align=Alignment(horizontal="right"),
         border=THIN_BORDER)

    # ── Section 2: WACC & terminal assumptions ────────────────────────────
    _set(ws, "A11", "2. WACC & TERMINAL ASSUMPTIONS", font=SECTION_HDR, fill=LIGHT_NAVY)
    ws.merge_cells("A11:G11")

    rows_wacc = [
        ("A12", "WACC (Base)",                       "='Required Return'!C54",        '0.00%'),
        ("A13", "Reasonable Terminal Growth",        "='Valuation Estimates'!H6",     '0.00%'),
        ("A14", "LT GDP Growth Reference (US nominal)", 0.035,                        '0.00%'),
    ]
    for label_cell, label, formula, fmt in rows_wacc:
        _set(ws, label_cell, label, font=LABEL_FONT)
        row_num = label_cell[1:]
        _set(ws, f"C{row_num}", formula, font=NUM_FONT, fmt=fmt,
             align=Alignment(horizontal="right"))
    # Note next to LT GDP
    _set(ws, "D14",
         "Approximately 2 percent real plus 1.5-2 percent inflation. Any company growing above this forever "
         "must capture share from the rest of the economy in perpetuity.",
         font=NOTE_FONT, align=Alignment(horizontal="left", wrap_text=True))

    # ── Section 3: 5Y explicit FCFF forecast ───────────────────────────────
    _set(ws, "A16", "3. 5-YEAR EXPLICIT FCFF FORECAST",
         font=SECTION_HDR, fill=LIGHT_NAVY)
    ws.merge_cells("A16:G16")

    # Year headers
    _set(ws, "A17", "FCFF (live-linked)", font=LABEL_FONT)
    for i, col in enumerate("BCDEF", start=1):
        _set(ws, f"{col}17", f"Y{i}", font=Font(bold=True, size=11),
             align=Alignment(horizontal="center"), fill=SUBTLE_GREY)

    # FCFF Y1-Y5 - pull from CFF (FCFF post-Audit #5 = NOPAT-based)
    _set(ws, "A18", "FCFF ($M)", font=LABEL_FONT)
    for i, col in enumerate("BCDEF", start=1):
        cff_col = chr(ord("B") + i - 1)   # B, C, D, E, F
        _set(ws, f"{col}18", f"='Cash Flow Forecast'!{cff_col}65",
             font=NUM_FONT, fmt='"$"#,##0', align=Alignment(horizontal="right"))

    # Discount factor row
    _set(ws, "A19", "Discount Factor (WACC)", font=LABEL_FONT)
    for i, col in enumerate("BCDEF", start=1):
        _set(ws, f"{col}19", f"=1/(1+$C$12)^{i}",
             font=NUM_FONT, fmt='0.000', align=Alignment(horizontal="right"))

    # PV row
    _set(ws, "A20", "PV(FCFF) ($M)", font=Font(name="Calibri", size=11, bold=True))
    for col in "BCDEF":
        _set(ws, f"{col}20", f"={col}18*{col}19",
             font=Font(name="Calibri", size=11, bold=True),
             fmt='"$"#,##0', align=Alignment(horizontal="right"),
             border=THIN_BORDER)

    # Sum row
    _set(ws, "A21", "Sum PV(Y1-Y5)", font=Font(name="Calibri", size=11, bold=True))
    _set(ws, "C21", "=SUM(B20:F20)",
         font=Font(name="Calibri", size=11, bold=True),
         fmt='"$"#,##0', align=Alignment(horizontal="right"))

    # ── Section 4: Terminal value at reasonable g ──────────────────────────
    _set(ws, "A23", "4. TERMINAL VALUE at REASONABLE g",
         font=SECTION_HDR, fill=LIGHT_NAVY)
    ws.merge_cells("A23:G23")

    _set(ws, "A24", "FCFF Y5 ($M)",                      font=LABEL_FONT)
    _set(ws, "C24", "=F18",                              font=NUM_FONT, fmt='"$"#,##0',
         align=Alignment(horizontal="right"))

    _set(ws, "A25", "Reasonable g (from CONFIG)",        font=LABEL_FONT)
    _set(ws, "C25", "=C13",                              font=NUM_FONT, fmt='0.00%',
         align=Alignment(horizontal="right"))

    _set(ws, "A26", "TV at reasonable g - Y5 nominal ($M)", font=LABEL_FONT)
    _set(ws, "C26", "=C24*(1+C25)/(C12-C25)",            font=NUM_FONT, fmt='"$"#,##0',
         align=Alignment(horizontal="right"))

    _set(ws, "A27", "PV of TV ($M)",                     font=Font(bold=True))
    _set(ws, "C27", "=C26/(1+C12)^5",                    font=Font(bold=True),
         fmt='"$"#,##0', align=Alignment(horizontal="right"),
         border=THIN_BORDER)

    # Audit #16 — leading "= " was parsed as a formula by Excel and triggered
    # repair dialogs (Removed Records: Formula from sheet20.xml). Use a plain
    # label without the equals prefix.
    _set(ws, "A28", "Implied EV at reasonable g ($M)",  font=Font(bold=True))
    _set(ws, "C28", "=C21+C27",                          font=Font(bold=True),
         fmt='"$"#,##0', align=Alignment(horizontal="right"),
         border=THIN_BORDER)

    _set(ws, "A29", "Implied Equity Value ($M)",         font=LABEL_FONT)
    _set(ws, "C29", "=C28-C8",                           font=NUM_FONT, fmt='"$"#,##0',
         align=Alignment(horizontal="right"))

    _set(ws, "A30", "Implied Price per Share ($)",       font=Font(bold=True, size=12))
    _set(ws, "C30", "=C29/C6",                           font=Font(bold=True, size=12),
         fmt='"$"#,##0.00', align=Alignment(horizontal="right"),
         fill=LIGHT_NAVY)

    # ── Section 5: Decomposition of market EV ─────────────────────────────
    _set(ws, "A32", "5. DECOMPOSITION OF MARKET ENTERPRISE VALUE",
         font=SECTION_HDR, fill=LIGHT_NAVY)
    ws.merge_cells("A32:G32")

    _set(ws, "A33", "Component", font=Font(bold=True), fill=SUBTLE_GREY)
    _set(ws, "C33", "$M",         font=Font(bold=True), fill=SUBTLE_GREY,
         align=Alignment(horizontal="right"))
    _set(ws, "D33", "% of Mkt EV",font=Font(bold=True), fill=SUBTLE_GREY,
         align=Alignment(horizontal="right"))

    _set(ws, "A34", "1. PV of Y1-Y5 FCFF (explicit forecast)",  font=LABEL_FONT)
    _set(ws, "C34", "=C21",                                     font=NUM_FONT, fmt='"$"#,##0', align=Alignment(horizontal="right"))
    _set(ws, "D34", "=C34/$C$9",                                font=NUM_FONT, fmt='0.0%',     align=Alignment(horizontal="right"))

    _set(ws, "A35", "2. PV of TV @ reasonable g (CONFIG)",      font=LABEL_FONT)
    _set(ws, "C35", "=C27",                                     font=NUM_FONT, fmt='"$"#,##0', align=Alignment(horizontal="right"))
    _set(ws, "D35", "=C35/$C$9",                                font=NUM_FONT, fmt='0.0%',     align=Alignment(horizontal="right"))

    _set(ws, "A36", "3. RESIDUAL - premium for unjustified perpetual growth",
         font=Font(bold=True, color="FFC00000"))
    _set(ws, "C36", "=C9-C34-C35",
         font=Font(bold=True, color="FFC00000"), fmt='"$"#,##0',
         align=Alignment(horizontal="right"), border=THIN_BORDER)
    _set(ws, "D36", "=C36/$C$9",
         font=Font(bold=True, color="FFC00000"), fmt='0.0%',
         align=Alignment(horizontal="right"), border=THIN_BORDER)

    _set(ws, "E36",
         "<-- THE BEAR THESIS: what percent of market price requires terminal "
         "growth above CONFIG.terminal_growth?",
         font=NOTE_FONT, align=Alignment(horizontal="left", wrap_text=True))
    ws.merge_cells("E36:G36")

    # ── Section 6: Reverse-solve for required g ───────────────────────────
    _set(ws, "A38", "6. REVERSE-SOLVE - REQUIRED PERPETUAL GROWTH",
         font=SECTION_HDR, fill=LIGHT_NAVY)
    ws.merge_cells("A38:G38")

    _set(ws, "A39", "Required TV (PV) to bridge market EV ($M)",  font=LABEL_FONT)
    _set(ws, "C39", "=C9-C21",                                     font=NUM_FONT, fmt='"$"#,##0', align=Alignment(horizontal="right"))

    _set(ws, "A40", "Required TV (Y5 nominal) ($M)",               font=LABEL_FONT)
    _set(ws, "C40", "=C39*(1+C12)^5",                              font=NUM_FONT, fmt='"$"#,##0', align=Alignment(horizontal="right"))

    _set(ws, "A41", "FCFF Y5 ($M)",                                font=LABEL_FONT)
    _set(ws, "C41", "=C24",                                        font=NUM_FONT, fmt='"$"#,##0', align=Alignment(horizontal="right"))

    # Solve: g = (TV*WACC - FCFF_Y5) / (TV + FCFF_Y5)
    _set(ws, "A42", "IMPLIED REQUIRED PERPETUAL g",
         font=Font(bold=True, size=12, color="FF1F3864"))
    _set(ws, "C42", "=IFERROR((C40*C12-C41)/(C40+C41),\"N/M\")",
         font=Font(bold=True, size=12, color="FF1F3864"),
         fmt='0.00%', align=Alignment(horizontal="right"),
         fill=PatternFill("solid", start_color="FFF4B083"),
         border=THIN_BORDER)

    _set(ws, "A43", "Reasonable g (CONFIG)",                       font=LABEL_FONT)
    _set(ws, "C43", "=C13",                                        font=NUM_FONT, fmt='0.00%', align=Alignment(horizontal="right"))

    _set(ws, "A44", "GAP - required g minus reasonable g",             font=Font(bold=True))
    _set(ws, "C44", "=IFERROR(C42-C43,\"N/M\")",                   font=Font(bold=True),
         fmt='0.00%', align=Alignment(horizontal="right"))

    _set(ws, "A45", "Required g vs LT GDP (3.5%)",                 font=LABEL_FONT)
    _set(ws, "C45", "=IFERROR(C42-C14,\"N/M\")",                   font=NUM_FONT, fmt='0.00%', align=Alignment(horizontal="right"))

    # Verdict cell - auto-classify (Audit #14 - REPAIR DIALOG FIX)
    # ─────────────────────────────────────────────────────────────────────
    # Excel was rejecting the deeply-nested IF formula with long string
    # branches (5 levels deep, each branch holding a 40+ char string).
    # The recovery log specifically named "Removed Records: Formula from
    # /xl/worksheets/sheet18.xml part" — that's THIS sheet, THIS cell.
    #
    # New approach: split into two cells.
    #   C46  → tier number 0..4 (simple shallow IF, no string branches)
    #   D46  → INDEX into a static lookup table for the verdict text
    # The lookup table sits hidden in F50:G54.
    # No conditional formatting (it was a repeated source of repair dialogs).
    # Color emphasis comes from the static font color on D46.
    _set(ws, "A46", "VERDICT",
         font=Font(bold=True, size=12, color="FF1F3864"))

    # Tier number formula — short, no strings, Excel-bulletproof.
    # 0 = N/M, 1 = FAIR, 2 = STRETCHED, 3 = AGGRESSIVE, 4 = UNJUSTIFIABLE
    _set(ws, "C46",
         '=IF(NOT(ISNUMBER(C42)),0,'
         'IF(C42<=C43+0.005,1,'
         'IF(C42<=C14,2,'
         'IF(C42<=0.05,3,4))))',
         font=Font(bold=True, size=12, color="FF1F3864"),
         fmt='0', align=Alignment(horizontal="center"),
         fill=LIGHT_NAVY)

    # Verdict text via INDEX — Excel parses INDEX trivially.
    _set(ws, "D46",
         '=INDEX($G$60:$G$64,C46+1)',
         font=Font(bold=True, size=12, color="FFC00000"),
         fmt='@', align=Alignment(horizontal="left", wrap_text=True),
         fill=LIGHT_NAVY)

    # ── Section 7: IC Summary ──────────────────────────────────────────────
    _set(ws, "A48", "7. INVESTMENT COMMITTEE - ONE-LINE SUMMARY",
         font=SECTION_HDR, fill=LIGHT_NAVY)
    ws.merge_cells("A48:G48")

    _set(ws, "A49", "If you believe in CONFIG terminal g - Implied Price",  font=LABEL_FONT)
    _set(ws, "C49", "=C30",                                                  font=Font(bold=True), fmt='"$"#,##0.00', align=Alignment(horizontal="right"))

    _set(ws, "A50", "Market Price",                                          font=LABEL_FONT)
    _set(ws, "C50", "=C5",                                                   font=Font(bold=True), fmt='"$"#,##0.00', align=Alignment(horizontal="right"))

    _set(ws, "A51", "Premium / (Discount) per share",                        font=LABEL_FONT)
    _set(ws, "C51", "=C50-C49",                                              font=NUM_FONT, fmt='"$"#,##0.00', align=Alignment(horizontal="right"))

    _set(ws, "A52", "Premium / (Discount) %",                                font=LABEL_FONT)
    _set(ws, "C52", "=IFERROR((C50-C49)/C49,\"N/M\")",                       font=NUM_FONT, fmt='0.0%', align=Alignment(horizontal="right"))

    _set(ws, "A53", "Market implies perpetual g of",                         font=Font(bold=True))
    _set(ws, "C53", "=C42",                                                  font=Font(bold=True, size=12, color="FFC00000"),
         fmt='0.00%', align=Alignment(horizontal="right"))

    # ── Section 8: Footnote ────────────────────────────────────────────────
    ws.merge_cells("A55:G56")
    _set(ws, "A55",
         "Methodology: Reverse-DCF inverts the Gordon-perpetuity in the standard "
         "two-stage model. Given market enterprise value, the explicit 5Y FCFF "
         "forecast, and base-case WACC, the formula solves for the constant-perpetual "
         "growth rate g that exactly matches market price. Compare to CONFIG.terminal_growth "
         "(reasonable steady-state) and US LT GDP growth (~3.5% nominal). For an "
         "UNDERWEIGHT thesis, a wide gap means the market is paying a premium for "
         "perpetual growth that is, by definition of finite economy, not achievable.",
         font=NOTE_FONT, align=Alignment(horizontal="left", wrap_text=True, vertical="top"))

    # ── Section 9: Verdict tier lookup table (Audit #14) ───────────────────
    # Static reference for the INDEX formula in D46. Placed below all other
    # content (rows 60-64) so it doesn't crowd the IC summary. Rendered in
    # subdued NOTE_FONT so it reads as audit footnote, not a primary KPI.
    _set(ws, "A59", "Verdict tier mapping (reference for D46)",
         font=Font(name="Calibri", size=10, italic=True, bold=True, color="FF595959"))
    _set(ws, "F60", 0, font=NOTE_FONT, align=Alignment(horizontal="center"))
    _set(ws, "G60", "N/M - check WACC vs g spread", font=NOTE_FONT)
    _set(ws, "F61", 1, font=NOTE_FONT, align=Alignment(horizontal="center"))
    _set(ws, "G61", "FAIR - market aligns with reasonable terminal", font=NOTE_FONT)
    _set(ws, "F62", 2, font=NOTE_FONT, align=Alignment(horizontal="center"))
    _set(ws, "G62", "STRETCHED - above CONFIG g but at/below LT GDP", font=NOTE_FONT)
    _set(ws, "F63", 3, font=NOTE_FONT, align=Alignment(horizontal="center"))
    _set(ws, "G63", "AGGRESSIVE - implies sustained super-GDP growth", font=NOTE_FONT)
    _set(ws, "F64", 4, font=NOTE_FONT, align=Alignment(horizontal="center"))
    _set(ws, "G64", "STRUCTURALLY UNJUSTIFIABLE - perpetual super-GDP", font=NOTE_FONT)

    # ── Tab tab color ──────────────────────────────────────────────────────
    ws.sheet_properties.tabColor = "C00000"   # red - flagging the bear case

    wb.save(workbook_path)

    print("  ✓  Reverse DCF tab built")
    print(f"     • 7 sections, ~50 cells, all live-linked to RR/VE/CFF")
    print(f"     • Verdict cell auto-classifies implied g vs LT GDP threshold")
    print(f"     • Tab is ticker-agnostic - works for any CONFIG repoint")
    return workbook_path


if __name__ == "__main__":
    import sys
    apply(sys.argv[1] if len(sys.argv) > 1 else "DCF_Final.xlsm")
