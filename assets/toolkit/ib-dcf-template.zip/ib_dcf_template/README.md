# IB DCF Template — Universal Edition

**An IB-grade DCF valuation template for any public company.** Edit one cell, run the notebook, get a fully-populated 20-tab Excel workbook with DCF, multiples, scenarios, sensitivity tables, and reverse-DCF decomposition.

---

## What you get

- **Full DCF** (Two-Stage 10Y) with FCFF (unlevered) discounted at WACC, terminal value, EV bridge.
- **Three explicit scenarios** (Pessimistic / Base / Optimistic) with cycle-aware path overrides.
- **Multiples valuation** — peer-blended P/E, P/B, EV/Sales, EV/EBITDA, P/FCF on both peak-cycle and mid-cycle drivers.
- **Sensitivity tables** — WACC × Terminal Growth and EBIT Margin × CapEx %.
- **Driver Sensitivity tornado** — every key driver mapped to a live workbook cell.
- **Required Return tab** — full WACC build with Damodaran ERP, beta blend, sanity gate.
- **Reverse DCF Decomposition** — quantifies what perpetual growth rate the market price implies; the bear-case kill shot.
- **Peer Comparison** — target + 5 peers × 32 metrics, with peer averages auto-computed.
- **Cover tab** — IC-ready summary with rating, PT, thesis bullets, and key model assumptions.

All data flows live from yfinance — no manual data entry required.

---

## Setup (one-time)

### Requirements
- Python 3.10 or later (Anaconda recommended on Windows)
- A modern web browser (for the Jupyter notebook)
- Microsoft Excel (to view the final workbook with full formula recalc)

### Install

```bash
# 1. Download or clone this folder. Put it anywhere on your computer.

# 2. Open a terminal in that folder.

# 3. Install Python dependencies.
pip install -r requirements.txt

# 4. Launch Jupyter Notebook.
jupyter notebook IB_DCF_Notebook.ipynb
```

That's it. The notebook is self-contained — it auto-detects the workbook in the same folder.

---

## Usage — repointing to a new ticker

1. Open `IB_DCF_Notebook.ipynb` in Jupyter.
2. Go to **Cell 3** (the only cell you need to edit — it's clearly marked).
3. Edit the values at the top of the cell:

```python
TARGET       = "NVDA"                           # Ticker
COMPANY_NAME = "NVIDIA CORP"
EXCHANGE     = "NASDAQ"
SECTOR       = "Semiconductors"                 # auto-detects taper preset

PEERS        = ["AMD", "INTC", "AVGO", "QCOM", "MRVL"]
RATING       = "OVERWEIGHT"                     # OVERWEIGHT / NEUTRAL / UNDERWEIGHT
PRICE_TARGET = 200.00                           # Your firm's target

GROWTH_PATH  = (0.50, 0.30, 0.15, 0.08, 0.05)   # FY+1 ... FY+5 revenue growth
TERMINAL_G   = 0.025                            # Long-run terminal growth

# (rest of Cell 3 — scenarios, capex offsets, etc. — defaults work for most tickers)

ANALYST_PT_FALLBACK    = 200.00                 # Street consensus PT
CAPEX_MID_CYCLE_FACTOR = None                   # None = sector auto-detect
NWC_MID_CYCLE_FACTOR   = None                   # None = sector auto-detect
```

4. **Run all cells** (Kernel → Restart & Run All).
5. Watch the pipeline run (Cell 4 prints 9 numbered steps).
6. **Open `IB_DCF_Template.xlsm` in Excel.** All formulas recalc on open. Look at the Cover tab.

The default values in Cell 3 are for **KO (Coca-Cola)** — a stable, easy-to-follow walk-through example. Replace with your own company.

---

## Cell-by-cell reference

| Cell | Purpose |
|---|---|
| 0 | Documentation + 9-step pipeline overview. |
| 1 | Install Python packages (run once per machine). |
| 2 | Auto-detect workbook + load CONFIG defaults. |
| 3 | **REPOINT** — edit ticker, peers, rating, scenarios. |
| 4 | yfinance data refresh + pipeline (9 steps). |
| 5 | IB-ready polish (Cover, scenarios, FCFF switch). |
| 6 | Relative Valuation rebuild (peer-blended multiples). |
| 7 | Peer scorecard ranking. |
| 8 | Verification pass — prints all audit invariants. |

---

## Sector presets (auto-detected from `CONFIG.sector`)

The `capex_mid_cycle_factor` and `nwc_mid_cycle_factor` taper historical CapEx/Sales and NWC/Sales toward a sector-defensible mid-cycle ratio over the 5Y forecast. If you set them to `None` in Cell 3, the sector matrix below picks the right defaults.

| Sector pattern (regex) | CapEx | NWC | Rationale |
|---|---|---|---|
| `memory\|hbm\|dram\|nand` | 0.75 | 0.85 | Peak HBM cycle digesting; capex normalizes to mid-cycle |
| `semiconductor\|semis\|fab` | 0.85 | 0.90 | Broad semis at mid-cycle reinvestment |
| `oil\|gas\|energy\|e&p` | 0.80 | 0.95 | Commodity cycle DD&A normalization |
| `auto\|automotive` | 0.90 | 0.95 | Platform refresh cadence |
| `steel\|metal\|mining` | 0.85 | 0.95 | Through-cycle capex |
| `airline\|aerospace` | 0.95 | 1.00 | Fleet renewal near mid-cycle |
| `reit\|real estate` | 0.95 | 1.05 | Steady maintenance capex |
| `util\|utility\|power` | 1.00 | 1.00 | Regulated capex schedule |
| `telecom\|wireless\|cable` | 1.05 | 1.00 | 5G/fiber buildout step-up |
| `bank\|financial\|insurance` | 1.00 | 1.00 | Minimal capex |
| `software\|saas\|cloud\|platform` | 1.00 | 1.00 | Capital-light |
| `pharma\|biotech\|drug\|health` | 1.00 | 1.05 | Stable capex, working-capital build |
| `consumer\|retail\|staples` | 1.00 | 1.00 | Steady reinvestment |
| `media\|entertainment\|gaming` | 1.00 | 1.00 | Variable, default flat |
| (no match) | 1.00 | 1.00 | Fall-through |

Override per-ticker by setting an explicit float in Cell 3 (`CAPEX_MID_CYCLE_FACTOR = 0.55` for more aggressive normalization, `0.95` for less).

---

## What "audited" means in this template

This template has been audited end-to-end across sixteen dimensions. Every audit produces a clean state with idempotent re-runs.

| # | Audit | Closes |
|---|---|---|
| 1 | Math correctness | Net Debt, Over/Under sign, label drift |
| 2 | Scenario consistency | Pess<Base<Opt enforced; cycle-aware PATH mode |
| 3 | Hardcoded literals | Cover/Driver Sens/Rev Bridge → live formulas |
| 4 | Magic-number IFERROR fallbacks | 24 → 0; 4-tier hierarchy |
| 5 | FCFE→FCFF + sector-aware factors | EV-DCF methodology + auto-tuned per sector |
| 6 | Python target-history Tier-1a | Cross-check vs Excel SUMPRODUCT |
| 7 | Workbook polish | TCM/FactSet/EFP purge cross-tab |
| 8 | NWC level semantic | Workbook expects level (not change) of NWC ratio |
| 9 | Reverse DCF Decomposition | Implied perpetual growth verdict |
| 10 | Template normalization | Ticker-agnostic strings on Cover/Instructions |
| 11 | Live price refresh | RR!C5 written from yfinance currentPrice on every run |
| 12 | Chart strip | openpyxl-corrupted chart parts removed post-save |
| 13 | 00-alpha rgb fix | Transparent-color codes scrubbed from styles.xml |
| 14 | Reverse DCF verdict formula | Tier-number + INDEX lookup (Excel-bulletproof) |
| 15 | Image drawing strip | Decorative drawings removed; orphan rels cleaned |
| 16 | "= label" demotion | Cells with leading "= " text demoted to plain strings |

Run `Cell 8` for a verification pass. It prints every invariant.

---

## Troubleshooting

**Q: yfinance throws an error on Cell 4.**
A: yfinance API can rate-limit. Wait 30 seconds and re-run Cell 4. If it persists, you may need `pip install --upgrade yfinance`.

**Q: Cell 8 says "CACHE EMPTY (open Excel to recalc)".**
A: Expected. After the notebook saves new formulas, Excel's cached values are invalidated. Open the workbook in Excel — it auto-recalcs on open. Save and close. Re-run Cell 8 if you want the populated cross-check table.

**Q: DCF base case looks too low / too high.**
A: Open Cell 3 and tune `CAPEX_MID_CYCLE_FACTOR`. Lower (e.g., 0.55) = more aggressive normalization = higher DCF. Higher (e.g., 0.95) = less normalization = lower DCF. Default `None` picks the sector preset.

**Q: One of the analyst ratios shows N/A on the Industry tab.**
A: That ratio's underlying yfinance data is missing for one or more peers. The workbook handles this gracefully (falls through to CONFIG analyst tier). Open Cell 3 and set `analyst_<ratio>_to_sales` to your view if you need a backstop.

**Q: I want to add a new scenario.**
A: All scenario logic lives in Cell 3 (PESS/OPT REV PATH, EBIT PATH, offsets). The workbook reads CONFIG values and rebuilds Scenario Analysis tab on each Cell 5 run.

**Q: Excel shows a "We found a problem with some content" repair dialog.**
A: This shouldn't happen with the current build (Audits #12–#16 closed all known causes). If it does, the recovery log will name a specific sheet. Re-run the notebook end-to-end and the polish pipeline will rebuild a clean file.

---

## License & attribution

This template is provided as-is for educational and analytical use. Built with `yfinance` (Apache 2.0), `openpyxl` (MIT), and `pandas` (BSD). No proprietary data sources required.

---

## Version

**Universal Edition** — Apr 2026 — 16 audits closed. 9-step pipeline. Reverse DCF Decomposition tab. Repair-dialog-free.
