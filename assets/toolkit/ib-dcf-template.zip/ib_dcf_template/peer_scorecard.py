"""
peer_scorecard.py — Adds a ranking scorecard to the Peer Comparison tab.

For each ranked metric, writes inline 1-6 ranks to the right of the peer
columns (cols J..O) and a composite scorecard table below the raw data
(rows 36+). A green-to-red 3-color scale highlights winners and losers at
a glance.

Direction rules
---------------
VALUATION multiples — lowest = best (cheapest)  → P/E, EV/EBITDA, P/S, P/B
QUALITY metrics     — highest = best             → margins, ROE, ROA
GROWTH metrics      — highest = best             → revenue, earnings growth
LEVERAGE            — lowest = best (D/E);
                      highest = best (Current Ratio, FCF, Div Yield)

Usage (inside the notebook)
---------------------------
    import importlib, peer_scorecard
    importlib.reload(peer_scorecard)
    peer_scorecard.apply()                 # auto-detects DCF_Final.xlsm

Idempotent — safe to run repeatedly. Clears any prior scorecard state in
columns J..P and rows 36+ before rewriting.
"""
from __future__ import annotations
import os
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.formatting.rule import ColorScaleRule
from openpyxl.comments import Comment

AUTHOR = "MD Review"

# ─── Styles ──────────────────────────────────────────────────────────
NAVY = "1F3864"
WHITE_FONT = Font(name="Calibri", color="FFFFFF", bold=True, size=11)
NAVY_FILL = PatternFill("solid", start_color=NAVY)
HDR_LIGHT = PatternFill("solid", start_color="D9E1F2")
LABEL_BOLD = Font(name="Calibri", bold=True, size=11)
RANK_FONT = Font(name="Calibri", size=10, bold=True)
thin = Side(style="thin", color="BFBFBF")
BORDER = Border(top=thin, bottom=thin, left=thin, right=thin)
MID = Side(style="medium", color=NAVY)
BORDER_THICK = Border(top=MID, bottom=MID, left=MID, right=MID)

# ─── Metric configuration ────────────────────────────────────────────
# (row_in_peer_comp_tab, direction, category, label)
#   direction: "HIGH" = highest-best (quality/growth)
#              "LOW"  = lowest-best  (valuation/leverage)
METRICS = [
    (9,  "LOW",  "Valuation",  "P/E (TTM)"),
    (10, "LOW",  "Valuation",  "P/E (NTM)"),
    (11, "LOW",  "Valuation",  "EV/EBITDA"),
    (12, "LOW",  "Valuation",  "EV/Revenue"),
    (13, "LOW",  "Valuation",  "P/Book"),
    (14, "LOW",  "Valuation",  "P/Sales"),
    (15, "HIGH", "Growth",     "Revenue Growth"),
    (16, "HIGH", "Growth",     "Earnings Growth"),
    (17, "HIGH", "Quality",    "Gross Margin"),
    (18, "HIGH", "Quality",    "EBIT Margin"),
    (19, "HIGH", "Quality",    "Net Margin"),
    (20, "HIGH", "Quality",    "ROE"),
    (21, "HIGH", "Quality",    "ROA"),
    (22, "LOW",  "Balance Sheet", "Debt/Equity"),
    (23, "HIGH", "Balance Sheet", "Current Ratio"),
    (26, "HIGH", "Cash Return", "Free CF"),
    (27, "HIGH", "Cash Return", "Div Yield"),
]

# Peer columns in the raw table
PEER_COLS = ["B", "C", "D", "E", "F", "G"]   # MU, INTC, AMD, NVDA, QCOM, TXN
# Rank columns (parallel, inline)
RANK_COLS = ["J", "K", "L", "M", "N", "O"]


# ─── Helpers ──────────────────────────────────────────────────────────
def _auto_detect_workbook() -> str:
    cwd = os.path.abspath("")
    candidates = sorted(
        [f for f in os.listdir(cwd) if f.endswith((".xlsm", ".xlsx"))],
        key=lambda f: os.path.getmtime(os.path.join(cwd, f)),
        reverse=True,
    )
    if not candidates:
        raise FileNotFoundError(f"No .xlsm/.xlsx in {cwd}")
    return os.path.join(cwd, candidates[0])


def _clear_scorecard_area(pc) -> None:
    """Wipe prior scorecard state (cols I..P rows 1-33, rows 34-80 below
    the rank block, and rows 36-80 for the composite scorecard)."""
    # Unmerge any merged ranges that fall in our target area
    for merged in list(pc.merged_cells.ranges):
        if merged.min_row >= 36 or merged.min_col >= 9:  # col I = 9
            pc.unmerge_cells(str(merged))
    for row in range(1, 34):
        for col in "IJKLMNOP":
            cell = pc[f"{col}{row}"]
            cell.value = None
            cell.fill = PatternFill(fill_type=None)
            cell.border = Border()
            cell.font = Font(name="Calibri", size=11)
    # Clear the area BELOW the rank block, to the right (I..P, rows 34..80)
    # so there's no leftover gray/white banding visible to the right of the
    # composite scorecard.
    for row in range(34, 81):
        for col in "IJKLMNOP":
            cell = pc[f"{col}{row}"]
            cell.value = None
            cell.fill = PatternFill(fill_type=None)
            cell.border = Border()
    for row in range(36, 81):
        for col in "ABCDEFGHIJKLMNOP":
            cell = pc[f"{col}{row}"]
            cell.value = None
            cell.fill = PatternFill(fill_type=None)
            cell.border = Border()
    # Remove previous conditional formatting rules that we created
    # (openpyxl stores them on pc.conditional_formatting)
    try:
        pc.conditional_formatting._cf_rules.clear()
    except Exception:
        pass


def _write_inline_ranks(pc, peer_tickers) -> None:
    """
    Rank columns J..O, mirroring peer columns B..G.
    For each metric row, RANK() against the 6 peer values.
    """
    # Merged title banner across J6:O7 — sits just above first ranked metric
    # so header and row labels line up naturally.
    pc.merge_cells("J6:O7")
    banner = pc["J6"]
    banner.value = "PEER RANK   (1 = Best   →   6 = Worst)"
    banner.font = WHITE_FONT
    banner.fill = NAVY_FILL
    banner.alignment = Alignment(horizontal="center", vertical="center")
    banner.border = BORDER_THICK

    # Ticker sub-headers on row 8 (right above row 9 = first ranked metric)
    for rcol, pcol in zip(RANK_COLS, PEER_COLS):
        ticker = pc[f"{pcol}3"].value or pc[f"{pcol}1"].value or pcol
        ticker = str(ticker).replace(" (Target)", "").strip()
        cell = pc[f"{rcol}8"]
        cell.value = ticker
        cell.font = Font(name="Calibri", bold=True, size=10, color="FFFFFF")
        cell.fill = NAVY_FILL
        cell.alignment = Alignment(horizontal="center", vertical="center")
        cell.border = BORDER

    # Per-metric ranks
    for metric_row, direction, _cat, _label in METRICS:
        # ascending order flag for Excel RANK: 0 = descending (HIGH-best),
        #                                      1 = ascending  (LOW-best)
        order = 0 if direction == "HIGH" else 1
        peer_range = f"$B${metric_row}:$G${metric_row}"
        for rcol, pcol in zip(RANK_COLS, PEER_COLS):
            cell_addr = f"{rcol}{metric_row}"
            src = f"{pcol}{metric_row}"
            # Blanks / non-numeric values are penalized as 6 (worst) so
            # missing disclosure hurts the composite instead of hiding it.
            formula = (
                f'=IFERROR(IF(ISNUMBER({src}),'
                f'RANK({src},{peer_range},{order}),6),6)'
            )
            cell = pc[cell_addr]
            cell.value = formula
            cell.font = RANK_FONT
            cell.alignment = Alignment(horizontal="center")
            cell.border = BORDER

    # Fill non-metric rows in the rank block to match adjacent raw-table
    # styling, so the rank panel reads as one continuous block instead of
    # scattered cells floating on a white background.
    from copy import copy
    metric_row_set = {m[0] for m in METRICS}
    # Mirror raw-table fills only on rows below the new header block (row 9+),
    # so rows 1-5 stay blank and rows 6-8 remain the banner/ticker strip.
    for r in range(9, 34):
        if r in metric_row_set:
            continue
        src_fill = pc[f"H{r}"].fill
        for rcol in RANK_COLS:
            cell = pc[f"{rcol}{r}"]
            try:
                cell.fill = copy(src_fill)
            except Exception:
                pass
            cell.border = BORDER

    # Color scale: 1 = dark green, 3.5 = white, 6 = dark red
    rule = ColorScaleRule(
        start_type="num", start_value=1,    start_color="63BE7B",  # green
        mid_type="num",   mid_value=3.5,    mid_color="FFFFFF",    # white
        end_type="num",   end_value=6,      end_color="F8696B",    # red
    )
    # Apply to each metric row's rank range individually so blanks in one
    # row don't affect another.
    for metric_row, _d, _c, _l in METRICS:
        rng = f"J{metric_row}:O{metric_row}"
        pc.conditional_formatting.add(rng, rule)


def _write_composite_scorecard(pc, peer_tickers) -> int:
    """
    Build a summary table BELOW the raw data showing:
      - avg rank per CATEGORY per company
      - overall composite rank
      - color-scaled 1..6 cells
    Returns the last row written.
    """
    start = 36
    # Title banner
    pc.merge_cells(f"A{start}:O{start}")
    cell = pc[f"A{start}"]
    cell.value = (
        "COMPOSITE SCORECARD — Weighted Rank by Category  "
        "(1 = best, 6 = worst  •  edit weights in col H to tilt the score)"
    )
    cell.font = Font(name="Calibri", bold=True, color="FFFFFF", size=12)
    cell.fill = NAVY_FILL
    cell.alignment = Alignment(horizontal="left", vertical="center", indent=1)
    pc.row_dimensions[start].height = 22

    # Header row (peer tickers)
    hdr = start + 2
    pc[f"A{hdr}"] = "Category"
    pc[f"A{hdr}"].font = WHITE_FONT
    pc[f"A{hdr}"].fill = NAVY_FILL
    pc[f"A{hdr}"].alignment = Alignment(horizontal="left", indent=1)
    pc[f"A{hdr}"].border = BORDER_THICK
    # Peer ticker headers (columns B..G)
    for col, pcol in zip(PEER_COLS, PEER_COLS):
        ticker = pc[f"{pcol}1"].value or pcol
        ticker = str(ticker).replace(" (Target)", "").strip()
        c = pc[f"{col}{hdr}"]
        c.value = ticker
        c.font = WHITE_FONT
        c.fill = NAVY_FILL
        c.alignment = Alignment(horizontal="center")
        c.border = BORDER_THICK
    # Weight column header (col H)
    wc = pc[f"H{hdr}"]
    wc.value = "Weight"
    wc.font = WHITE_FONT
    wc.fill = NAVY_FILL
    wc.alignment = Alignment(horizontal="center")
    wc.border = BORDER_THICK

    # Category groupings
    categories: dict[str, list[int]] = {}
    for metric_row, _dir, cat, _lbl in METRICS:
        categories.setdefault(cat, []).append(metric_row)

    # Category order on display
    order = ["Valuation", "Quality", "Growth", "Balance Sheet", "Cash Return"]
    ordered = [c for c in order if c in categories]

    # Per-category average-rank rows + editable weight column (H)
    default_weight = round(1.0 / len(ordered), 4)  # equal split
    row = hdr + 1
    cat_start_row = row
    for cat in ordered:
        metric_rows = categories[cat]
        pc[f"A{row}"] = cat
        pc[f"A{row}"].font = LABEL_BOLD
        pc[f"A{row}"].fill = HDR_LIGHT
        pc[f"A{row}"].border = BORDER
        pc[f"A{row}"].alignment = Alignment(horizontal="left", indent=1)
        for rcol, pcol in zip(RANK_COLS, PEER_COLS):
            refs = ",".join(f"{rcol}{mr}" for mr in metric_rows)
            formula = f'=IFERROR(AVERAGE({refs}),"")'
            out_cell = pc[f"{pcol}{row}"]
            out_cell.value = formula
            out_cell.number_format = "0.00"
            out_cell.alignment = Alignment(horizontal="center")
            out_cell.border = BORDER
        # Editable weight cell (col H)
        wcell = pc[f"H{row}"]
        wcell.value = default_weight
        wcell.number_format = "0.0%"
        wcell.alignment = Alignment(horizontal="center")
        wcell.border = BORDER
        wcell.fill = PatternFill("solid", start_color="FFF2CC")  # light yellow = editable
        wcell.font = Font(name="Calibri", bold=True, size=11, color="1F3864")
        row += 1
    cat_end_row = row - 1
    weight_range = f"$H${cat_start_row}:$H${cat_end_row}"

    # Overall composite row
    composite_row = row
    pc[f"A{row}"] = "OVERALL COMPOSITE"
    pc[f"A{row}"].font = Font(name="Calibri", bold=True, size=11, color="FFFFFF")
    pc[f"A{row}"].fill = NAVY_FILL
    pc[f"A{row}"].border = BORDER_THICK
    pc[f"A{row}"].alignment = Alignment(horizontal="left", indent=1)
    for rcol, pcol in zip(RANK_COLS, PEER_COLS):
        rng = f"{pcol}{cat_start_row}:{pcol}{composite_row - 1}"
        out_cell = pc[f"{pcol}{row}"]
        # Weighted: SUMPRODUCT(ranks, weights) / SUM(weights) — normalizes
        # so user doesn't have to make weights sum to exactly 100%.
        out_cell.value = (
            f'=IFERROR(SUMPRODUCT({rng},{weight_range})/SUM({weight_range}),"")'
        )
        out_cell.number_format = "0.00"
        out_cell.font = Font(name="Calibri", bold=True, size=11)
        out_cell.alignment = Alignment(horizontal="center")
        out_cell.border = BORDER_THICK
    # Weight-sum check in col H of composite row
    wtotal = pc[f"H{row}"]
    wtotal.value = f"=SUM({weight_range})"
    wtotal.number_format = "0.0%"
    wtotal.alignment = Alignment(horizontal="center")
    wtotal.font = Font(name="Calibri", bold=True, italic=True, size=10, color="595959")
    wtotal.border = BORDER_THICK
    row += 1

    # Rank-of-composite row (1..6 across peers based on overall composite)
    rank_row = row
    pc[f"A{row}"] = "Final Rank (1=best)"
    pc[f"A{row}"].font = Font(name="Calibri", bold=True, italic=True, size=11)
    pc[f"A{row}"].fill = HDR_LIGHT
    pc[f"A{row}"].border = BORDER
    pc[f"A{row}"].alignment = Alignment(horizontal="left", indent=1)
    composite_range = f"$B${composite_row}:$G${composite_row}"
    for rcol, pcol in zip(RANK_COLS, PEER_COLS):
        src = f"{pcol}{composite_row}"
        formula = (
            f'=IFERROR(RANK({src},{composite_range},1),"")'  # 1 = ascending (lower avg = better)
        )
        out = pc[f"{pcol}{row}"]
        out.value = formula
        out.font = Font(name="Calibri", bold=True, size=12)
        out.alignment = Alignment(horizontal="center")
        out.border = BORDER_THICK
    row += 1

    # Color scales — apply to each data row in the scorecard
    rule_avg = ColorScaleRule(
        start_type="num", start_value=1,    start_color="63BE7B",
        mid_type="num",   mid_value=3.5,    mid_color="FFFFFF",
        end_type="num",   end_value=6,      end_color="F8696B",
    )
    for r in range(cat_start_row, rank_row + 1):
        pc.conditional_formatting.add(f"B{r}:G{r}", rule_avg)

    # Footer note
    row += 1
    pc.merge_cells(f"A{row}:H{row}")
    pc[f"A{row}"] = (
        "Scoring: Valuation / D/E = lowest best.  Quality / Growth / Current Ratio / Cash Return = highest best.  "
        "Blank values are penalized as rank 6.  Weights (col H, yellow) are user-editable — Overall Composite "
        "auto-renormalizes via SUMPRODUCT, so weights don't need to sum to exactly 100%."
    )
    pc[f"A{row}"].font = Font(name="Calibri", italic=True, size=9, color="595959")
    pc[f"A{row}"].alignment = Alignment(wrap_text=True, vertical="top")

    return row


# ─── Category boxes (thick borders around each group in the rank panel) ──
def _draw_category_boxes(pc) -> None:
    """Put a thick navy border around each category's rank cells in J..O,
    and matching boxes around the raw-data rows in A..H, so the groupings
    are visually obvious."""
    # Gather category → list of rows (in original order)
    cat_rows: dict[str, list[int]] = {}
    for metric_row, _dir, cat, _lbl in METRICS:
        cat_rows.setdefault(cat, []).append(metric_row)

    box_side = Side(style="medium", color=NAVY)
    for _cat, rows in cat_rows.items():
        top, bot = min(rows), max(rows)
        # Box around rank panel J..O
        for r in range(top, bot + 1):
            for cidx, col in enumerate(RANK_COLS):
                cell = pc[f"{col}{r}"]
                old = cell.border
                cell.border = Border(
                    left=box_side if cidx == 0 else old.left,
                    right=box_side if cidx == len(RANK_COLS) - 1 else old.right,
                    top=box_side if r == top else old.top,
                    bottom=box_side if r == bot else old.bottom,
                )
        # Matching box around raw data A..H
        for r in range(top, bot + 1):
            for cidx, col in enumerate("ABCDEFGH"):
                cell = pc[f"{col}{r}"]
                old = cell.border
                cell.border = Border(
                    left=box_side if cidx == 0 else old.left,
                    right=box_side if cidx == 7 else old.right,
                    top=box_side if r == top else old.top,
                    bottom=box_side if r == bot else old.bottom,
                )


# ─── Data normalization (runs BEFORE formatting) ──────────────────────
# yfinance returns Analyst Rating as text strings like "strong_buy" / "hold".
# Map them to the standard 1-5 numeric scale so they can be ranked and
# formatted consistently with the rest of the table.
RATING_MAP = {
    "strong_buy": "Strong Buy", "strongbuy": "Strong Buy",
    "buy": "Buy", "outperform": "Outperform", "overweight": "Overweight",
    "hold": "Hold", "neutral": "Neutral", "market_perform": "Market Perform",
    "marketperform": "Market Perform", "equal_weight": "Equal Weight",
    "equalweight": "Equal Weight",
    "sell": "Sell", "underperform": "Underperform", "underweight": "Underweight",
    "strong_sell": "Strong Sell", "strongsell": "Strong Sell",
}


def _normalize_data(pc) -> None:
    """Clean up messy data before formatting. Logs what it changed so the
    user can see exactly what was touched."""
    changes = []
    for r in range(4, 34):
        label = pc[f"A{r}"].value
        if label is None:
            continue
        key = str(label).strip().lower()

        # Analyst Rating: messy yfinance text → cleaned, title-cased label
        # (e.g. "strong_buy" → "Strong Buy")
        if "analyst rating" in key or "consensus rating" in key or "recommendation" in key:
            for c in "BCDEFG":
                cell = pc[f"{c}{r}"]
                v = cell.value
                if isinstance(v, str):
                    normalized = v.strip().lower().replace("-", "_").replace(" ", "_")
                    pretty = RATING_MAP.get(normalized)
                    if pretty and pretty != v:
                        cell.value = pretty
                        cell.alignment = Alignment(horizontal="center")
                        changes.append(f"    R{r} {c}: '{v}' → '{pretty}'")

        # P/E NTM: flag clearly broken values (<2 or >200) with a comment
        # but leave the value (could be cyclical truth — let ranking handle it).
        if "p/e (ntm)" in key or "forward p/e" in key:
            for c in "BCDEFG":
                cell = pc[f"{c}{r}"]
                v = cell.value
                if isinstance(v, (int, float)) and (v < 2 or v > 200):
                    cell.comment = Comment(
                        f"Outlier forward P/E ({v:.2f}x). "
                        f"Likely stale / bad analyst estimate — verify in FactSet.",
                        AUTHOR,
                    )
                    changes.append(f"    R{r} {c}: flagged outlier P/E={v:.2f}x")

    # Force black text on ALL data cells (cols A-H rows 4-33) — prior runs
    # may have left white-on-white font colors that make values invisible.
    # Preserves bold/italic; just resets color to explicit black.
    _BLACK = "FF000000"
    blackened = 0
    for r in range(4, 34):
        for c in "ABCDEFGH":
            cell = pc[f"{c}{r}"]
            f = cell.font
            try:
                cur_rgb = f.color.rgb if f.color else None
            except Exception:
                cur_rgb = None
            if cur_rgb in (None, "FFFFFFFF", "00FFFFFF", "FFFEFEFE") \
                    or not isinstance(cur_rgb, str):
                cell.font = Font(
                    name=f.name, size=f.size, bold=f.bold,
                    italic=f.italic, color=_BLACK,
                )
                blackened += 1
    if blackened:
        changes.append(f"    Forced black text on {blackened} cells (was white/theme)")

    # Live yfinance fallback for blank Earnings Growth / Revenue Growth cells
    # (runs here in case dcf_refresh.py wasn't rerun). Tries quarterly growth,
    # then computes from trailing EPS change. Never leaves blank.
    try:
        import yfinance as yf
        ticker_row = 3  # row with tickers
        for r in range(4, 34):
            label = pc[f"A{r}"].value
            if not label:
                continue
            key = str(label).strip().lower()
            if "earnings growth" not in key and "revenue growth" not in key:
                continue
            for c in "BCDEFG":
                cell = pc[f"{c}{r}"]
                if cell.value not in (None, "", "—"):
                    continue
                tkr = pc[f"{c}{ticker_row}"].value
                if not tkr:
                    continue
                try:
                    info = yf.Ticker(str(tkr)).info
                    if "earnings" in key:
                        val = info.get("earningsQuarterlyGrowth")
                    else:
                        val = info.get("revenueQuarterlyGrowth") \
                              or info.get("revenueGrowth")
                    if val is not None:
                        try:
                            cell.value = float(val)
                            changes.append(
                                f"    R{r} {c}: live yfinance fallback "
                                f"({tkr} {key}={val:.1%})"
                            )
                        except (TypeError, ValueError):
                            pass
                except Exception as exc:
                    print(f"    ⚠  live fallback {tkr} {key}: {exc}")
    except ImportError:
        pass

    # Safety net: any blank/None in a valuation-multiple row → "N/M"
    # (runs here in the scorecard even when dcf_refresh.py wasn't rerun)
    _MULTIPLE_ROW_KEYS = ("p/e ", "p/e(", "ev/ebitda", "ev/revenue",
                          "p/book", "p/sales", "forward p", "peg")
    # Non-multiple numeric rows: blanks → 0 (IB spec: no blanks)
    _ZERO_FILL_KEYS = (
        "div yield", "payout", "dividend",
        "margin", "roe", "roa", "free cf",
        "ebitda ($", "revenue ($", "market cap", "current ratio",
        "debt/equity", "# analyst", "price target", "target high",
        "target low",
    )
    # Note: earnings growth / revenue growth intentionally excluded —
    # live yfinance fallback runs above to fetch real numbers. If that
    # still fails (prior-year base was negative so % growth is undefined),
    # we stamp N/M via the multiple-row treatment below.
    _MULTIPLE_ROW_KEYS_EXTENDED = (
        "p/e ", "p/e(", "ev/ebitda", "ev/revenue",
        "p/book", "p/sales", "forward p", "peg",
        "earnings growth", "revenue growth",  # undefined if base < 0 → N/M
    )
    for r in range(4, 34):
        label = pc[f"A{r}"].value
        if not label:
            continue
        key = str(label).strip().lower()
        is_multiple = any(k in key for k in _MULTIPLE_ROW_KEYS_EXTENDED)
        is_zero = any(k in key for k in _ZERO_FILL_KEYS)
        for c in "BCDEFGH":
            cell = pc[f"{c}{r}"]
            if cell.value not in (None, "", "—"):
                continue
            if is_multiple:
                cell.value = "N/M"
                changes.append(f"    R{r} {c}: blank → N/M (safety net)")
            elif is_zero:
                cell.value = 0
                changes.append(f"    R{r} {c}: blank → 0 (safety net)")

    # Style any "N/M" cells (negative-earnings multiples, etc.) — gray italic,
    # centered, with a comment explaining the convention for IB
    nm_fill = PatternFill("solid", fgColor="E8E8E8")
    nm_font = Font(italic=True, color="808080", bold=False)
    for r in range(4, 34):
        for c in "BCDEFGH":
            cell = pc[f"{c}{r}"]
            if isinstance(cell.value, str) and cell.value.strip().upper() == "N/M":
                cell.value = "N/M"
                cell.font = nm_font
                cell.fill = nm_fill
                cell.alignment = Alignment(horizontal="center")
                cell.comment = Comment(
                    "N/M = Not Meaningful. Multiple is undefined "
                    "(e.g. negative earnings make P/E mathematically "
                    "invalid). Ranked as worst in scorecard.",
                    AUTHOR,
                )
                changes.append(f"    R{r} {c}: flagged N/M (undefined multiple)")

    if changes:
        print("  Data normalized:")
        for c in changes:
            print(c)
    else:
        print("  Data normalized: (no changes needed)")


# ─── Number-format cleanup ─────────────────────────────────────────────
# Format rules keyed by substrings found in the row label (col A).
# First match wins, so order matters (most-specific first).
_FORMAT_RULES = [
    # 1. Whole-number counts (beats everything analyst-related)
    (("# analyst", "num analyst", "analyst count", "number of analyst",
      "# of analyst", "analyst coverage"), "#,##0"),
    # 2. Dividend Yield — values already in percent form (2.71 = 2.71%)
    (("div yield", "dividend yield"), '0.00"%"'),
    # 3. Percentages stored as decimals (0.12 = 12%)
    #    — includes margin, growth rates, payout ratio, returns on capital
    (("margin", "growth", "roe", "roa", "payout", "return on",
      "tax rate", "1 yr", "1-yr", "ytd", "fcf yield"), "0.0%"),
    # 4. Valuation multiples with "x" suffix
    (("p/e ", "p/e(", "p/e)", "pe ratio", "ev/ebitda", "ev/revenue",
      "ev/sales", "p/book", "p/sales", "price/book", "price/sales",
      "forward p", "peg"), '0.00"x"'),
    # 5. Liquidity / leverage multiples with "x" suffix
    (("current ratio", "quick ratio", "debt/equity", "d/e",
      "debt/ebitda", "net debt/", "interest cover"), '0.00"x"'),
    # 6. Beta — just 2 decimals, no suffix
    (("beta",), "0.00"),
    # 7. Per-share / price dollars — must catch "Price", "52-Wk High/Low",
    #    "Price Target", "Target High", "Target Low", EPS, DPS, per-share
    (("price target", "target price", "stock price", "last price",
      "share price", "current price", "52-wk", "52 wk", "52wk",
      "target high", "target low", "eps", "dps", "per share"),
     '"$"#,##0.00'),
    (("price",), '"$"#,##0.00'),  # bare "Price" row (stock price)
    # 8. Large-cap currency with adaptive scale (percent-labels already
    #    filtered out above by the is_pct_label check in _fix_number_formats)
    (("market cap", "enterprise value", "revenue", "ebitda", "net income",
      "free cash", "fcf", "total debt", "net debt", "cash"),
     '[>=1000000000]"$"#,##0.0,,,"B";[>=1000000]"$"#,##0.0,,"M";"$"#,##0'),
    # 9. Share count / volume
    (("shares out", "share count", "shares outstanding",
      "avg volume", "volume"), "#,##0"),
    # 10. Fallback: generic "analyst" → integer count
    (("analyst",), "#,##0"),
]


_BIG_CURRENCY_KEYS = (
    "market cap", "enterprise value", "revenue", "ebitda", "net income",
    "free cash", "fcf", "free cf", "cf ($", "cash flow",
    "total debt", "cash",
)

# Labels that are valuation multiples (should get "x" suffix, NOT big-$)
_MULTIPLE_KEYS = (
    "ev/", "p/e", "p/s", "p/b", "p/sales", "p/book", "peg",
    "price/", "forward p", "pe ratio",
)


def _detect_currency_scale(values: list[float]) -> str:
    """Pick a Big-$ format based on the magnitude of numeric values on the
    row. Detects whether data is stored as raw dollars, millions, or billions
    so the display is always sensible regardless of the data puller's unit.
    """
    nums = [abs(v) for v in values if isinstance(v, (int, float)) and v != 0]
    if not nums:
        return '"$"#,##0'
    median = sorted(nums)[len(nums) // 2]
    if median >= 1_000_000_000:        # raw dollars, values are in billions
        return '"$"#,##0.0,,,"B"'
    if median >= 1_000_000:            # raw dollars, values are in millions
        return '"$"#,##0.0,,"M"'
    if median >= 1_000:                # stored in $M already (e.g. 120,000)
        return '"$"#,##0.0,"B"'
    if median >= 1:                    # stored in $B already (e.g. 120.5)
        return '"$"#,##0.0"B"'
    return '"$"#,##0.00'


def _fix_number_formats(pc) -> None:
    """Walk every data row in the Peer Comparison table (rows 4..33) and
    apply a consistent number format to cols B..H based on the row label.
    For big-currency rows, auto-detect the scale (dollars / millions /
    billions) from the actual values so the display is always correct."""
    for r in range(4, 34):
        label = pc[f"A{r}"].value
        if label is None:
            continue
        key = str(label).strip().lower()
        if not key:
            continue

        # Adaptive scale for Market Cap / EV / Revenue / EBITDA / FCF / etc.
        # BUT — skip rows that are actually percentages even if the label
        # contains "revenue" / "ebitda" etc. (e.g. "Revenue Growth",
        # "EBITDA Margin", "Net Income Growth").
        is_pct_label = any(kw in key for kw in (
            "growth", "margin", "yield", "ratio", "return on", "roe", "roa",
        ))
        is_multiple = any(kw in key for kw in _MULTIPLE_KEYS)
        if is_multiple:
            for col in "BCDEFGH":
                cell = pc[f"{col}{r}"]
                if isinstance(cell.value, str) and not cell.value.startswith("="):
                    continue
                cell.number_format = '0.00"x"'
            continue
        if not is_pct_label and any(k in key for k in _BIG_CURRENCY_KEYS):
            row_vals = [pc[f"{c}{r}"].value for c in "BCDEFG"]
            fmt = _detect_currency_scale(row_vals)
            for col in "BCDEFGH":
                cell = pc[f"{col}{r}"]
                if isinstance(cell.value, str) and not cell.value.startswith("="):
                    continue
                cell.number_format = fmt
            continue

        fmt = None
        for keywords, f in _FORMAT_RULES:
            if any(k in key for k in keywords):
                fmt = f
                break
        if fmt is None:
            continue
        for col in "BCDEFGH":
            cell = pc[f"{col}{r}"]
            if isinstance(cell.value, str) and not cell.value.startswith("="):
                continue
            cell.number_format = fmt


# ─── Fill audit — clears stale bright fills in the data area ──────────
# Colors we expect in the data area (headers, alternating bands, etc.)
_EXPECTED_FILLS = {
    None, "00000000", "FFFFFFFF",           # default / white
    "FF1F3864", "FF2E5395",                  # navy (headers)
    "FFD9E1F2", "FFF2F2F2", "FFFFF2CC",     # light-blue band / pale gray / edit-yellow
    "FFE7E6E6", "FFF8F9FA",                  # light neutral
}


def _audit_and_clean_fills(pc) -> None:
    """Scan the peer-data block (B..H, rows 4..33) for unexpected bright
    fills left over from prior runs, strip them, and log what was cleared.
    This kills the 'random bright-blue cells' problem."""
    cleared = 0
    for r in range(4, 34):
        # Also scan col A (label col) — orange category-header fills can
        # leak onto data-row labels from prior runs and make the whole row
        # look like a header, visually hiding the numbers next to it.
        for col in "ABCDEFGH":
            cell = pc[f"{col}{r}"]
            rgb_key = None
            try:
                raw = cell.fill.start_color.rgb
                if isinstance(raw, str):
                    rgb_key = raw.upper()
                else:
                    # Theme / indexed color on a DATA row → strip it.
                    # (Data rows should never inherit theme header fills.)
                    cell.fill = PatternFill(fill_type=None)
                    cleared += 1
                    continue
            except Exception:
                continue  # can't read → don't touch
            if rgb_key in _EXPECTED_FILLS:
                continue
            # Unknown bright fill → strip it
            cell.fill = PatternFill(fill_type=None)
            cleared += 1
    if cleared:
        print(f"  Cleared {cleared} stale bright fills in data area.")
    else:
        print("  No stale fills found.")


# ─── Data validator — flags missing values and outliers ──────────────
# Reasonable bounds for large-cap semiconductors. Used only for flagging —
# nothing is mutated. Cells outside these ranges get a red-triangle comment.
_SANITY_BOUNDS = {
    # (row_label_substring, min_ok, max_ok, unit_hint)
    ("p/e (ttm)",      5,   150,  "x"),
    ("p/e (ntm)",      5,   80,   "x"),
    ("ev/ebitda",      5,   80,   "x"),
    ("ev/revenue",     1,   30,   "x"),
    ("p/book",         0.5, 40,   "x"),
    ("p/sales",        1,   30,   "x"),
    ("revenue growth", -0.5, 3.0, "decimal"),
    ("earnings growth", -1.0, 10.0, "decimal"),
    ("gross margin",   0.10, 0.90, "decimal"),
    ("ebit margin",    -0.20, 0.80, "decimal"),
    ("net margin",     -0.20, 0.70, "decimal"),
    ("roe",            -0.30, 1.50, "decimal"),
    ("roa",            -0.20, 0.80, "decimal"),
    ("debt/equity",    0.0,  5.0,  "x"),
    ("current ratio",  0.5,  10.0, "x"),
    ("beta",           0.3,  3.5,  ""),
    ("div yield",      0.0,  10.0, "% (already scaled)"),
    ("payout ratio",   0.0,  2.0,  "decimal"),
    ("price target",   1.0,  10000.0, "$"),
    ("# analyst",      1,    100,    "count"),
}


def _validate_data(pc, peer_tickers) -> None:
    """Scan every numeric cell in the peer data block and report:
       • Missing values (blanks on rows where peers generally have data)
       • Out-of-bounds values (potential data errors)
    Nothing is changed — this is a report-only pass. Cells with outlier
    values get a red-triangle comment for on-screen review."""
    print("\n  === DATA VALIDATION ===")
    missing: list[str] = []
    outliers: list[str] = []

    # Build label → (row, bounds) lookup
    for r in range(4, 34):
        label_raw = pc[f"A{r}"].value
        if not label_raw:
            continue
        label = str(label_raw).strip().lower()

        # Find matching bound rule
        bound = None
        for key, lo, hi, unit in _SANITY_BOUNDS:
            if key in label:
                bound = (lo, hi, unit)
                break

        # Count blanks and check bounds across peers
        blanks_in_row: list[str] = []
        for c, ticker in zip("BCDEFG", peer_tickers):
            v = pc[f"{c}{r}"].value
            if v is None or v == "":
                blanks_in_row.append(str(ticker))
                continue
            if not isinstance(v, (int, float)):
                continue
            if bound is not None:
                lo, hi, unit = bound
                if v < lo or v > hi:
                    tag = f"{ticker} {label_raw} = {v:.4g}{unit}  (expect {lo}-{hi})"
                    outliers.append(f"    ⚠  R{r} {c}: {tag}")
                    try:
                        pc[f"{c}{r}"].comment = Comment(
                            f"Outlier: {v:.4g}{unit}. Expected range {lo}-{hi}. "
                            f"Verify source (yfinance may be stale).",
                            AUTHOR,
                        )
                    except Exception:
                        pass

        if blanks_in_row and len(blanks_in_row) <= 3:  # don't log fully-blank rows
            missing.append(f"    •  R{r} {label_raw}: blank for {', '.join(blanks_in_row)}")

    if missing:
        print(f"  Missing values ({len(missing)} rows):")
        for m in missing[:15]:
            print(m)
        if len(missing) > 15:
            print(f"    ... +{len(missing) - 15} more")
    else:
        print("  No unexpected missing values.")

    if outliers:
        print(f"  Outlier values ({len(outliers)} cells) — flagged with red-triangle comments:")
        for o in outliers[:15]:
            print(o)
        if len(outliers) > 15:
            print(f"    ... +{len(outliers) - 15} more")
    else:
        print("  All values within expected ranges.")

    # Per-row format audit — shows exactly what format was applied to each row.
    print("\n  === FORMAT AUDIT ===")
    print(f"  {'R':>3} {'Label':<22} {'Sample (MU)':<18} {'Format applied'}")
    for r in range(4, 34):
        label = pc[f"A{r}"].value
        if not label:
            continue
        sample_cell = pc[f"B{r}"]
        fmt = sample_cell.number_format
        v = sample_cell.value
        # Simulate what Excel will render (rough preview)
        preview = _preview_format(v, fmt)
        print(f"  {r:>3} {str(label)[:22]:<22} {str(preview):<18} {fmt}")


def _preview_format(value, fmt: str) -> str:
    """Rough preview of how a cell will render in Excel, so the console
    output tells you at a glance whether the format is correct."""
    if value is None or value == "":
        return "—"
    if isinstance(value, str):
        return value
    try:
        v = float(value)
    except Exception:
        return str(value)
    # Percent formats
    if fmt.endswith("%"):
        return f"{v * 100:.1f}%"
    if '"%"' in fmt:
        return f"{v:.2f}%"
    # x-suffix multiples
    if '"x"' in fmt:
        return f"{v:.2f}x"
    # Big currency adaptive
    if "[>=1000000000]" in fmt:
        av = abs(v)
        if av >= 1_000_000_000:
            return f"${v/1e9:,.1f}B"
        if av >= 1_000_000:
            return f"${v/1e6:,.1f}M"
        # Fall-through: value was stored in $M already — single-comma format
    if ',"B"' in fmt and ',,' not in fmt:
        return f"${v/1e3:,.1f}B"
    if ',"M"' in fmt:
        return f"${v:,.1f}M"
    if '"$"' in fmt or fmt.startswith("$"):
        return f"${v:,.2f}"
    if fmt == "#,##0":
        return f"{v:,.0f}"
    if fmt == "0.00":
        return f"{v:.2f}"
    return f"{v:g}"


# ─── Public entry point ──────────────────────────────────────────────
def apply(workbook_path: str | None = None) -> str:
    """Apply the peer scorecard to the Peer Comparison tab."""
    if workbook_path is None:
        workbook_path = _auto_detect_workbook()
    elif not os.path.isabs(workbook_path):
        workbook_path = os.path.join(os.path.abspath(""), workbook_path)

    print(f"  File: {os.path.basename(workbook_path)}")
    wb = load_workbook(workbook_path, keep_vba=True, data_only=False)
    if "Peer Comparison" not in wb.sheetnames:
        raise KeyError("'Peer Comparison' tab not found in workbook.")
    pc = wb["Peer Comparison"]

    # Read peer tickers from row 3 (col B..G)
    peer_tickers = [pc[f"{c}3"].value or c for c in PEER_COLS]
    print(f"  Peers: {', '.join(str(t) for t in peer_tickers)}")

    print("  Clearing prior scorecard state...")
    _clear_scorecard_area(pc)

    print("  Writing inline ranks (cols J..O)...")
    _write_inline_ranks(pc, peer_tickers)

    print("  Normalizing data (rating text → 1-5, flag P/E outliers)...")
    _normalize_data(pc)

    print("  Drawing category boxes around rank groups...")
    _draw_category_boxes(pc)

    print("  Fixing number formats on peer data...")
    _fix_number_formats(pc)

    print("  Auditing cell fills (looking for stale highlights)...")
    _audit_and_clean_fills(pc)

    # ── Cross-check every cell for presence + sanity ──
    _validate_data(pc, peer_tickers)

    # ── Data sanity dump (prints raw values so we can spot-check them) ──
    print("\n  === RAW VALUE AUDIT (rows 4-33) ===")
    print(f"  {'R':>3} {'Label':<26} {'MU(B)':>14} {'INTC(C)':>14} {'AMD(D)':>14} {'NVDA(E)':>14} {'QCOM(F)':>14} {'TXN(G)':>14}")
    for r in range(4, 34):
        label = pc[f"A{r}"].value
        if label is None:
            continue
        vals = []
        for c in "BCDEFG":
            v = pc[f"{c}{r}"].value
            vals.append(f"{v:>14}" if v is not None else f"{'—':>14}")
        print(f"  {r:>3} {str(label)[:26]:<26}" + "".join(vals))

    print("  Writing composite scorecard table (rows 36+)...")
    last_row = _write_composite_scorecard(pc, peer_tickers)

    # Column widths
    pc.column_dimensions["A"].width = 26
    for c in "BCDEFGH":
        pc.column_dimensions[c].width = 14
    pc.column_dimensions["I"].width = 2    # spacer between raw data and ranks
    for c in "JKLMNO":
        pc.column_dimensions[c].width = 7
    pc.column_dimensions["P"].width = 2

    wb.save(workbook_path)
    print(f"  ✅  Peer Scorecard applied.  Scorecard spans rows 36-{last_row}.")
    return workbook_path


if __name__ == "__main__":
    apply()
