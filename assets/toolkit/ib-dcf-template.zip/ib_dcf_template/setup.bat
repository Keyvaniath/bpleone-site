@echo off
REM DCF Template — One-command setup for Windows.
REM Usage:  double-click setup.bat (or run from cmd / PowerShell)

echo ============================================================
echo   DCF Template - Universal Edition (v4)
echo   Setup running...
echo ============================================================

REM Verify Python is installed
python --version >nul 2>&1
if errorlevel 1 (
    echo   ERROR: Python is not installed or not on PATH.
    echo   Download from https://www.python.org/downloads/
    echo   During install, check "Add Python to PATH"
    pause
    exit /b 1
)

for /f "tokens=*" %%i in ('python --version') do set PYVER=%%i
echo   [ok] %PYVER%

REM Install requirements
echo   Installing dependencies (yfinance, openpyxl, pandas, jupyter)...
python -m pip install -r requirements.txt --quiet
if errorlevel 1 (
    echo   ERROR: pip install failed. Try running as administrator.
    pause
    exit /b 1
)
echo   [ok] Dependencies installed

echo.
echo ============================================================
echo   Setup complete.
echo.
echo   Next steps:
echo     1. jupyter notebook DCF_Notebook_v4.ipynb
echo     2. Edit Cell 3 with your ticker, peers, rating, PT
echo     3. Run all cells (Kernel - Restart and Run All)
echo     4. Open DCF_Final.xlsm in Excel
echo ============================================================
pause
