"""
DCF Refresh — Financial Data Engine
Populates the DCF template with data from Yahoo Finance, FRED, and Damodaran.

PRIMARY INTERFACE: DCF_Notebook.ipynb  (open this, run it — works on Mac & Windows)
ALTERNATIVE:       python dcf_refresh.py MU INTC,AMD,NVDA
"""

import sys, os, math
from datetime import datetime, date

# ── Dependency check ───────────────────────────────────────────────────────────
def _require(pkg, install_name=None):
    try:
        return __import__(pkg)
    except ImportError:
        name = install_name or pkg
        sys.exit(f"Missing package. In Jupyter run:  !pip install {name}")

yf    = _require("yfinance")
opxl  = _require("openpyxl")
from openpyxl import load_workbook

try:
    import requests
    REQUESTS = True
except ImportError:
    REQUESTS = False

try:
    import xlwings as xw
    XLWINGS = True
except ImportError:
    XLWINGS = False


# ══════════════════════════════════════════════════════════════════════════════
#  ★  CONFIG — Edit these in the Jupyter notebook instead of here
# ══════════════════════════════════════════════════════════════════════════════
TARGET_TICKER = "MU"
PEER_TICKERS  = ["INTC", "AMD", "NVDA", "QCOM", "TXN"]
# ══════════════════════════════════════════════════════════════════════════════


# ─── Field maps: yfinance → FactSet standardized label ────────────────────────

# NOTE on map ordering:
# _write_stmt walks each (yfinance_label → FactSet_label) pair in order. For any
# FactSet label that appears MORE THAN ONCE, only the first yfinance label that
# actually exists in the dataframe is used. That's the fallback chain — put the
# canonical yfinance label first, alternatives after. Coverage expanded April 2026
# to bring IS/BS/CF up to IB-desk depth (~30+ line items per statement) with
# robust fallbacks for companies that report under alternative yfinance labels.

IS_MAP = {
    # ── Revenue ───────────────────────────────────────────────────────────
    "Total Revenue":                                  "Sales",
    "Operating Revenue":                              "Sales",
    # ── Gross profit block ───────────────────────────────────────────────
    "Cost Of Revenue":                                "Cost of Goods Sold",
    "Reconciled Cost Of Revenue":                     "Cost of Goods Sold",
    "Gross Profit":                                   "Gross Profit",
    # ── Operating expense breakdown ──────────────────────────────────────
    "Research And Development":                       "Research & Development",
    "Selling General And Administration":             "Selling, General & Administrative",
    "General And Administrative Expense":             "General & Administrative",
    "Selling And Marketing Expense":                  "Selling & Marketing",
    "Other Operating Expenses":                       "Other Operating Expenses",
    "Other Non Operating Income Expenses":            "Other Non-Operating Inc. (Exp.)",
    "Operating Expense":                              "Total Operating Expenses",
    # ── Operating income / EBITDA ────────────────────────────────────────
    "Operating Income":                               "EBIT (Operating Income)",
    "EBIT":                                           "EBIT (Operating Income)",
    "Normalized EBITDA":                              "EBITDA",
    "EBITDA":                                         "EBITDA",
    "Reconciled Depreciation":                        "Depreciation & Amortization",
    # ── Non-operating items ──────────────────────────────────────────────
    "Interest Expense":                               "Interest Expense",
    "Interest Expense Non Operating":                 "Interest Expense",
    "Interest Income":                                "Interest Income",
    "Interest Income Non Operating":                  "Interest Income",
    "Net Non Operating Interest Income Expense":      "Net Interest Income (Expense)",
    # ── Pretax / tax / net income ────────────────────────────────────────
    "Pretax Income":                                  "Pretax Income",
    "Tax Provision":                                  "Income Taxes",
    "Tax Rate For Calcs":                             "Effective Tax Rate",
    "Net Income From Continuing Operation Net Minority Interest": "Net Income (Continuing Ops)",
    "Net Income":                                     "Net Income",
    "Net Income Common Stockholders":                 "Net Income (Common)",
    "Normalized Income":                              "Normalized Net Income",
    # ── Per-share data ───────────────────────────────────────────────────
    "Basic EPS":                                      "EPS (Basic)",
    "Diluted EPS":                                    "EPS (diluted)",
    "Basic Average Shares":                           "Basic Shares Outstanding",
    "Diluted Average Shares":                         "Diluted Shares Outstanding",
    # ── Distributions ────────────────────────────────────────────────────
    "Total Unusual Items":                            "Unusual / One-Time Items",
    "Total Unusual Items Excluding Goodwill":         "Unusual / One-Time Items (ex-GW)",
    # Preferred dividends — consumed by Required Return!C12 (cost of preferred)
    "Preferred Stock Dividends":                      "Preferred Dividends",
    "Preferred Dividends":                            "Preferred Dividends",
}

BS_MAP = {
    # ═════ ASSETS ═════════════════════════════════════════════════════════
    # Cash & liquid assets
    "Cash And Cash Equivalents":                        "Cash & Cash Equivalents",
    "Cash Financial":                                   "Cash & Cash Equivalents",
    "Cash Cash Equivalents And Short Term Investments": "Cash & Short-Term Investments",
    "Other Short Term Investments":                     "Short-Term Investments",
    # Working capital assets
    "Accounts Receivable":                              "Receivables",
    "Receivables":                                      "Receivables",
    "Inventory":                                        "Inventories",
    "Prepaid Assets":                                   "Prepaid Expenses & Other",
    "Other Current Assets":                             "Other Current Assets",
    "Current Deferred Assets":                          "Current Deferred Tax Assets",
    "Total Current Assets":                             "Total Current Assets",
    # Long-lived assets
    "Gross PPE":                                        "Gross Property, Plant & Equipment",
    "Accumulated Depreciation":                         "Accumulated Depreciation",
    "Net PPE":                                          "Net Property, Plant & Equipment",
    "Goodwill":                                         "Goodwill",
    "Other Intangible Assets":                          "Other Intangible Assets",
    "Goodwill And Other Intangible Assets":             "Goodwill & Intangibles (Total)",
    "Investmentin Financial Assets":                    "Long-Term Investments",
    "Long Term Equity Investment":                      "Long-Term Equity Investments",
    "Non Current Deferred Assets":                      "Non-Current Deferred Tax Assets",
    "Other Non Current Assets":                         "Other Non-Current Assets",
    "Total Non Current Assets":                         "Total Non-Current Assets",
    "Total Assets":                                     "Total Assets",
    # ═════ LIABILITIES ════════════════════════════════════════════════════
    "Accounts Payable":                                 "Accounts Payable",
    "Payables":                                         "Accounts Payable",
    "Current Accrued Expenses":                         "Accrued Expenses",
    "Payables And Accrued Expenses":                    "Payables & Accrued Expenses",
    # Short-term debt — multiple fallbacks because yfinance label is inconsistent
    "Current Debt":                                     "ST Debt & Curr. Portion LT Debt",
    "Current Debt And Capital Lease Obligation":        "ST Debt & Curr. Portion LT Debt",
    "Short Long Term Debt":                             "ST Debt & Curr. Portion LT Debt",
    "Other Current Borrowings":                         "Other Current Borrowings",
    "Current Deferred Liabilities":                     "Current Deferred Liabilities",
    "Other Current Liabilities":                        "Other Current Liabilities",
    "Total Current Liabilities":                        "Total Current Liabilities",
    # Long-term debt
    "Long Term Debt":                                   "Long-Term Debt",
    "Long Term Debt And Capital Lease Obligation":      "Long-Term Debt (incl. Leases)",
    # NB: exact label text "Long-Term Debt excl Lease Obligations" is required by
    # Required Return!C9 — do NOT rename without updating that formula.
    "Long Term Debt Excluding Lease Obligation":        "Long-Term Debt excl Lease Obligations",
    "Long Term Capital Lease Obligation":               "Long-Term Capital Lease Obligations",
    "Capital Lease Obligations":                        "Capital Lease Obligations (Total)",
    "Non Current Deferred Taxes Liabilities":           "Deferred Tax Liabilities",
    "Non Current Deferred Liabilities":                 "Non-Current Deferred Liabilities",
    "Other Non Current Liabilities":                    "Other Non-Current Liabilities",
    "Total Non Current Liabilities Net Minority Interest": "Total Non-Current Liabilities",
    "Total Liabilities Net Minority Interest":          "Total Liabilities",
    "Total Debt":                                       "Total Debt",
    "Net Debt":                                         "Net Debt",
    # ═════ EQUITY ═════════════════════════════════════════════════════════
    "Preferred Stock":                                  "Preferred Stock (Carrying Value)",
    "Common Stock":                                     "Common Stock (par)",
    "Additional Paid In Capital":                       "Additional Paid-In Capital",
    "Retained Earnings":                                "Retained Earnings",
    "Treasury Stock":                                   "Treasury Stock",
    "Gains Losses Not Affecting Retained Earnings":     "Accumulated OCI",
    "Other Equity Interest":                            "Other Equity Adjustments",
    "Minority Interest":                                "Minority Interest",
    "Stockholders Equity":                              "Common Equity",
    "Common Stock Equity":                              "Common Equity",
    "Total Equity Gross Minority Interest":             "Total Equity (incl. Minority)",
    # ═════ KEY COMPUTED / SUPPLEMENTAL ═══════════════════════════════════
    "Ordinary Shares Number":                           "Shares Outstanding (end of period)",
    "Share Issued":                                     "Shares Issued",
    "Working Capital":                                  "Working Capital",
    "Invested Capital":                                 "Invested Capital",
    "Tangible Book Value":                              "Tangible Book Value",
    "Net Tangible Assets":                              "Net Tangible Assets",
}

CF_MAP = {
    # ═════ OPERATING ══════════════════════════════════════════════════════
    "Net Income From Continuing Operations":         "Net Income (CF start)",
    "Net Income":                                    "Net Income (CF start)",
    "Depreciation And Amortization":                 "Depreciation, Depletion & Amortization",
    "Depreciation Amortization Depletion":           "Depreciation, Depletion & Amortization",
    "Reconciled Depreciation":                       "D&A (from IS)",
    "Stock Based Compensation":                      "Stock-Based Compensation",
    "Asset Impairment Charge":                       "Asset Impairment Charges",
    "Deferred Income Tax":                           "Deferred Income Tax",
    "Deferred Tax":                                  "Deferred Income Tax",
    "Other Non Cash Items":                          "Other Non-Cash Items",
    # Working capital changes
    "Change In Working Capital":                     "Change in Working Capital",
    "Change In Receivables":                         "Δ Receivables",
    "Change In Account Receivable":                  "Δ Receivables",
    "Change In Inventory":                           "Δ Inventory",
    "Change In Payable":                             "Δ Payables",
    "Change In Payables And Accrued Expense":        "Δ Payables & Accrued Exp.",
    "Change In Other Working Capital":               "Δ Other Working Capital",
    "Change In Other Current Assets":                "Δ Other Current Assets",
    "Change In Other Current Liabilities":           "Δ Other Current Liabilities",
    "Operating Cash Flow":                           "Cash from Operations",
    "Cash Flow From Continuing Operating Activities":"Cash from Operations",
    # ═════ INVESTING ══════════════════════════════════════════════════════
    "Capital Expenditure":                           "Capital Expenditures",
    "Capital Expenditure Reported":                  "Capital Expenditures",
    "Net PPE Purchase And Sale":                     "Net PP&E Purchase/Sale",
    "Purchase Of PPE":                               "Purchase of PP&E",
    "Sale Of PPE":                                   "Sale of PP&E",
    "Net Business Purchase And Sale":                "Net Business Purchase/Sale (M&A)",
    "Purchase Of Business":                          "Purchase of Business (Acquisitions)",
    "Sale Of Business":                              "Sale of Business (Divestitures)",
    "Net Investment Purchase And Sale":              "Net Investment Purchase/Sale",
    "Purchase Of Investment":                        "Purchase of Investments",
    "Sale Of Investment":                            "Sale of Investments",
    "Net Other Investing Changes":                   "Other Investing Activities",
    "Investing Cash Flow":                           "Cash from Investing",
    # ═════ FINANCING ══════════════════════════════════════════════════════
    "Issuance Of Debt":                              "Issuance of Debt",
    "Long Term Debt Issuance":                       "Issuance of Long-Term Debt",
    "Repayment Of Debt":                             "Repayment of Debt",
    "Long Term Debt Payments":                       "Repayment of Long-Term Debt",
    "Net Issuance Payments Of Debt":                 "Net Debt Issuance/(Repayment)",
    "Net Short Term Debt Issuance":                  "Net Short-Term Debt Issuance",
    "Issuance Of Capital Stock":                     "Issuance of Common Stock",
    "Common Stock Issuance":                         "Issuance of Common Stock",
    "Repurchase Of Capital Stock":                   "Repurchase of Common Stock",
    "Common Stock Payments":                         "Repurchase of Common Stock",
    "Common Stock Dividend Paid":                    "Common Dividends Paid",
    "Cash Dividends Paid":                           "Total Dividends Paid",
    "Net Other Financing Charges":                   "Other Financing Activities",
    "Financing Cash Flow":                           "Cash from Financing",
    # ═════ RECONCILIATION & KEY METRICS ══════════════════════════════════
    "Effect Of Exchange Rate Changes":               "Effect of Exchange Rate",
    "Change In Cash":                                "Net Change in Cash",
    "Changes In Cash":                               "Net Change in Cash",
    "Beginning Cash Position":                       "Beginning Cash Balance",
    "End Cash Position":                             "Ending Cash Balance",
    "Free Cash Flow":                                "Free Cash Flow",
}

KEY_ITEMS_MAP = {
    # Per-share & share counts
    "Diluted Average Shares":                        "Diluted Shares Outstanding",
    "Basic Average Shares":                          "Basic Shares Outstanding",
    "Ordinary Shares Number":                        "Shares Outstanding (end of period)",
    "Diluted EPS":                                   "EPS (diluted)",
    "Basic EPS":                                     "EPS (Basic)",
    # Top-of-house metrics from IS (for Driver Sensitivity cross-references)
    "Total Revenue":                                 "Total Revenue",
    "Gross Profit":                                  "Gross Profit",
    "Operating Income":                              "Operating Income",
    "EBIT":                                          "EBIT",
    "Normalized EBITDA":                             "EBITDA",
    "Net Income":                                    "Net Income",
    "Net Income Common Stockholders":                "Net Income (Common)",
    "Tax Provision":                                 "Tax Provision",
    "Pretax Income":                                 "Pretax Income",
}

PEER_METRICS = [
    ("Company",          "shortName",                        str),
    ("Ticker",           "__ticker__",                       str),
    ("Market Cap ($M)",  "marketCap",                        lambda v: _n(v)/1e6 if _n(v)!="" else ""),
    ("Price",            "currentPrice",                     _n := (lambda x: (lambda v: "" if v is None or (isinstance(v,float) and math.isnan(v)) else float(v))(x))),
    ("52-Wk High",       "fiftyTwoWeekHigh",                 _n),
    ("52-Wk Low",        "fiftyTwoWeekLow",                  _n),
    ("Beta (3-yr)",      "beta",                             _n),
    ("P/E (TTM)",        "trailingPE",                       _n),
    ("P/E (NTM)",        "forwardPE",                        _n),
    ("EV/EBITDA",        "enterpriseToEbitda",               _n),
    ("EV/Revenue",       "enterpriseToRevenue",              _n),
    ("P/Book",           "priceToBook",                      _n),
    ("P/Sales (TTM)",    "priceToSalesTrailing12Months",     _n),
    ("Revenue Growth",   "revenueGrowth",                    lambda v: _sanitize_growth(v, 0.80)),
    ("Earnings Growth",  "earningsGrowth",                   lambda v: _sanitize_growth(v, 2.00)),
    ("Gross Margin",     "grossMargins",                     _n),
    ("EBIT Margin",      "operatingMargins",                 _n),
    ("Net Margin",       "profitMargins",                    _n),
    ("ROE",              "returnOnEquity",                   _n),
    ("ROA",              "returnOnAssets",                   _n),
    ("Debt/Equity",      "debtToEquity",                     lambda v: _n(v)/100 if _n(v)!="" else ""),
    ("Current Ratio",    "currentRatio",                     _n),
    ("Revenue ($M)",     "totalRevenue",                     lambda v: _n(v)/1e6 if _n(v)!="" else ""),
    ("EBITDA ($M)",      "ebitda",                           lambda v: _n(v)/1e6 if _n(v)!="" else ""),
    ("Free CF ($M)",     "freeCashflow",                     lambda v: _n(v)/1e6 if _n(v)!="" else ""),
    ("Div Yield",        "dividendYield",                    _n),
    ("Payout Ratio",     "payoutRatio",                      _n),
    ("Analyst Rating",   "recommendationKey",                str),
    ("Price Target",     "targetMeanPrice",                  _n),
    ("Target High",      "targetHighPrice",                  _n),
    ("Target Low",       "targetLowPrice",                   _n),
    ("# Analysts",       "numberOfAnalystOpinions",          _n),
]


# ─── Safe numeric helper ───────────────────────────────────────────────────────

def _n(v):
    try:
        f = float(v)
        return "" if math.isnan(f) or math.isinf(f) else f
    except (TypeError, ValueError):
        return ""


# ─── Peer-growth sanitizer (B5) ────────────────────────────────────────────────
# yfinance occasionally returns wildly out-of-band YoY growth values (base-year
# distortions, post-COVID snap-backs, one-off write-downs). Clamp those to "N/M"
# so they never flow into peer medians / Relative Valuation.
def _sanitize_growth(v, cap: float):
    f = _n(v)
    if f == "":
        return ""
    return "N/M" if abs(f) > cap else f

def _n_rev_growth(v):
    return _sanitize_growth(v, 0.80)   # |ΔRev| ≤ 80% YoY

def _n_eps_growth(v):
    return _sanitize_growth(v, 2.00)   # |ΔEPS| ≤ 200% YoY


# ─── Macro data: 10-yr Treasury & Damodaran ERP ────────────────────────────────

def fetch_treasury_yield():
    """
    Fetch the current US 10-year Treasury yield from Yahoo Finance (^TNX).
    Returns decimal (e.g. 0.0435 for 4.35%).
    Falls back to None if unavailable.
    """
    try:
        tnx = yf.Ticker("^TNX")
        info = tnx.info
        # ^TNX quotes in percent (e.g. 4.35 means 4.35%)
        price = (info.get("regularMarketPrice")
                 or info.get("currentPrice")
                 or info.get("previousClose"))
        if price:
            return round(float(price) / 100, 6)
    except Exception:
        pass
    # Second attempt: download last 1 day
    try:
        hist = yf.download("^TNX", period="5d", progress=False)
        if not hist.empty:
            last = float(hist["Close"].iloc[-1])
            return round(last / 100, 6)
    except Exception:
        pass
    return None


def fetch_damodaran_erp():
    """
    Fetch Aswath Damodaran's current Equity Risk Premium from his NYU website.
    He updates this monthly. Returns decimal (e.g. 0.0472 for 4.72%).
    Falls back to a conservative 4.5% if the site is unreachable.
    """
    if not REQUESTS:
        return 0.045  # conservative fallback

    FALLBACK = 0.045  # 4.5% — reasonable long-run ERP if site unreachable

    # He publishes monthly ERP estimates here
    urls = [
        "http://pages.stern.nyu.edu/~adamodar/New_Home_Page/datafile/implprem.html",
        "https://pages.stern.nyu.edu/~adamodar/New_Home_Page/datafile/implprem.html",
    ]
    for url in urls:
        try:
            resp = requests.get(url, timeout=8)
            if resp.status_code != 200:
                continue
            text = resp.text
            # His page has a table — look for the most recent ERP percentage
            import re
            # Pattern: a percentage like 4.72% near "implied ERP"
            matches = re.findall(r'(\d+\.\d+)%', text)
            if matches:
                # The current month's ERP is typically the first large percentage
                candidates = [float(m)/100 for m in matches if 1.5 <= float(m) <= 12.0]
                if candidates:
                    return round(candidates[0], 6)
        except Exception:
            continue

    # Try downloading his Excel file directly
    excel_urls = [
        "http://pages.stern.nyu.edu/~adamodar/pc/implprem/ERPbymonth.xlsx",
        "https://pages.stern.nyu.edu/~adamodar/pc/implprem/ERPbymonth.xlsx",
    ]
    for url in excel_urls:
        try:
            import io
            resp = requests.get(url, timeout=10)
            if resp.status_code == 200:
                from openpyxl import load_workbook as _lw
                wb = _lw(io.BytesIO(resp.content), data_only=True)
                ws = wb.active
                # His file has ERP in a column — find the most recent non-empty value
                for row in reversed(list(ws.iter_rows())):
                    for cell in row:
                        v = _n(cell.value)
                        if v != "" and 0.01 <= v <= 0.20:
                            return round(v, 6)
        except Exception:
            continue

    return FALLBACK


def detect_fiscal_year_quarters(ticker_obj):
    """
    Calculates how many full quarters remain until this company's next fiscal year-end.
    Returns an integer 1–4, or empty string if it can't be determined.

    The template uses this in Instructions!U43.
    """
    try:
        info = ticker_obj.info
        fy_end_month = info.get("fiscalYearEnd")   # e.g. "August"

        if not fy_end_month:
            # Fall back to most recent income statement date
            inc = ticker_obj.income_stmt
            if inc is not None and not inc.empty:
                most_recent_col = sorted(inc.columns, reverse=True)[0]
                fy_end_month_num = most_recent_col.month
            else:
                return ""
        else:
            month_map = {
                "January":1,"February":2,"March":3,"April":4,
                "May":5,"June":6,"July":7,"August":8,
                "September":9,"October":10,"November":11,"December":12
            }
            fy_end_month_num = month_map.get(fy_end_month, None)
            if not fy_end_month_num:
                return ""

        today = date.today()
        # Find the next fiscal year-end date
        next_fy_end = date(today.year, fy_end_month_num, 1)
        if next_fy_end <= today:
            next_fy_end = date(today.year + 1, fy_end_month_num, 1)

        # Count full quarters from today to next FY end
        months_remaining = (next_fy_end.year - today.year) * 12 + (next_fy_end.month - today.month)
        full_quarters = math.ceil(months_remaining / 3)
        return max(1, min(4, full_quarters))

    except Exception:
        return ""


# ─── Sheet write helpers ───────────────────────────────────────────────────────

def _clear_sheet(ws, max_row=700, max_col=16):
    from openpyxl.cell.cell import MergedCell
    for row in ws.iter_rows(min_row=1, max_row=max_row, max_col=max_col):
        for cell in row:
            if isinstance(cell, MergedCell):
                continue
            if not (cell.value and isinstance(cell.value, str) and cell.value.startswith("=")):
                cell.value = None


# ─── Scale rules for _write_stmt ───────────────────────────────────────────
# yfinance returns RAW DOLLARS ($25,111,000,000 for MU revenue). The template
# tabs (Required Return / WACC / CFF / VE / Valuation Summary) all assume
# MILLIONS. Writing raw dollars into IS/BS/CF broke every downstream formula
# and produced the "too many 000s" render. We now divide all $ amounts by 1e6
# before writing, and we apply Excel number formatting so numbers render as
# "25,111" not "25111.0" or "2.5E+10".
#
# Exceptions: per-share figures (EPS) are already per-share and must NOT be
# scaled. Share counts are scaled to millions of shares (same as $M convention).
# Ratios already come through as decimals and are left alone.

SCALE_DIVISOR = 1_000_000.0   # raw $ → $ in millions

# FS labels (the values of the *_MAP dicts) that must NOT be scaled because
# they're per-share quantities.
PER_SHARE_FS_LABELS = {
    "EPS (Basic)",
    "EPS (diluted)",
}

# FS labels that are already ratios/percentages — no scaling, FMT_RATIO applied.
RATIO_FS_LABELS = {
    "Effective Tax Rate",
}

# FS labels that ARE share counts — scale to millions of shares.
SHARE_COUNT_FS_LABELS = {
    "Basic Shares Outstanding",
    "Diluted Shares Outstanding",
    "Shares Outstanding (end of period)",
    "Shares Issued",
}

# Excel number formats per category.
FMT_DOLLARS_M  = '_($* #,##0_);_($* (#,##0);_($* "-"_);_(@_)'   # accountancy style, negatives in parens
FMT_PER_SHARE  = '$#,##0.00;($#,##0.00);"-"'
FMT_SHARES_M   = '#,##0.0;(#,##0.0);"-"'                         # shares in millions with 1 decimal
FMT_RATIO      = '0.0%;(0.0%);"-"'
FMT_YEAR       = '0'


def _scale_and_format(fs_label, raw):
    """
    Given a FactSet-style label and a raw yfinance value, return the
    (scaled_value, excel_format) tuple. Ratios / per-share pass through.
    """
    if raw in ("", None):
        return ("", None)
    if fs_label in PER_SHARE_FS_LABELS:
        try:
            return (float(raw), FMT_PER_SHARE)
        except (TypeError, ValueError):
            return (raw, None)
    if fs_label in RATIO_FS_LABELS:
        try:
            return (float(raw), FMT_RATIO)
        except (TypeError, ValueError):
            return (raw, None)
    if fs_label in SHARE_COUNT_FS_LABELS:
        try:
            return (float(raw) / SCALE_DIVISOR, FMT_SHARES_M)
        except (TypeError, ValueError):
            return (raw, None)
    # Default: dollars → millions
    try:
        return (float(raw) / SCALE_DIVISOR, FMT_DOLLARS_M)
    except (TypeError, ValueError):
        return (raw, None)


def _write_stmt(ws, field_map, df, max_years=10):
    """
    Writes a raw financial statement (IS / BS / CF) to a sheet.
    Row 1 = header with year columns + "(US$ millions except per-share)" caption.
    Rows 2+ = one row per FactSet line item, $ values scaled to millions and
              formatted with accountancy number style for readability.

    Returns (next_free_row, cols) so the caller can append a Historical
    Analysis / ratios block below the raw statement without collisions.
    """
    if df is None or df.empty:
        print(f"  ⚠  No data for {ws.title}")
        return (2, [])
    cols = sorted(df.columns, reverse=True)[:max_years]
    years = [c.year if hasattr(c, "year") else str(c) for c in cols]

    # Row 1 header: statement name + explicit unit caption, then years
    ws.cell(1, 1).value = f"{ws.title}  (US$ millions, except per-share)"
    for i, yr in enumerate(years):
        c = ws.cell(1, i + 2)
        c.value = yr
        c.number_format = FMT_YEAR
    # Blank out prior data (clears old labels, old numbers, old formatting)
    for r in range(2, 400):
        for c in range(1, len(years) + 2):
            cell = ws.cell(r, c)
            cell.value = None
            cell.number_format = 'General'

    row, written = 2, set()
    for yf_lbl, fs_lbl in field_map.items():
        if fs_lbl in written or yf_lbl not in df.index:
            continue
        ws.cell(row, 1).value = fs_lbl
        for j, col in enumerate(cols):
            raw = _n(df.loc[yf_lbl, col])
            scaled, fmt = _scale_and_format(fs_lbl, raw)
            cell = ws.cell(row, j + 2)
            cell.value = scaled
            if fmt:
                cell.number_format = fmt
        written.add(fs_lbl)
        row += 1
    print(f"  ✓  {ws.title}: {len(written)} line items, {len(years)} years  [scaled to millions]")
    return (row, cols)


# ─── Historical Analysis helpers ──────────────────────────────────────────────
# After raw statement data is written, we append a ratios/growth block so the
# Driver Sensitivity tab has a real foundation to forecast from. This is the
# "more historical depth" push — common-size margins, capital structure,
# reinvestment rates, and YoY growth rates all live next to the raw data.

def _df_get(df, label, col):
    """Safe accessor — returns _n(df.loc[label,col]) or '' if missing."""
    if df is None or df.empty or label not in df.index:
        return ""
    try:
        return _n(df.loc[label, col])
    except Exception:
        return ""


def _df_any(df, candidates, col):
    """Return the first non-empty _n-value across a list of candidate labels."""
    for lbl in candidates:
        v = _df_get(df, lbl, col)
        if v not in ("", None):
            return v
    return ""


def _safe_div(a, b):
    """Guarded division — returns '' unless both are numeric and b != 0."""
    if a in ("", None) or b in ("", None):
        return ""
    try:
        bf = float(b)
        return round(float(a) / bf, 4) if bf != 0 else ""
    except (TypeError, ValueError):
        return ""


def _write_is_ratios(ws, df_is, start_row, cols):
    """Writes margins, ETR, and YoY growth rates below the raw IS."""
    if df_is is None or df_is.empty or not cols:
        return start_row
    r = start_row + 1  # 1 blank spacer row
    ws.cell(r, 1).value = "──── HISTORICAL ANALYSIS ────"
    r += 1

    def _margin_row(label, numerator_candidates, denom_label="Total Revenue"):
        nonlocal r
        ws.cell(r, 1).value = label
        for j, col in enumerate(cols):
            num = _df_any(df_is, numerator_candidates, col)
            den = _df_get(df_is, denom_label, col)
            cell = ws.cell(r, j + 2)
            cell.value = _safe_div(num, den)
            cell.number_format = FMT_RATIO
        r += 1

    _margin_row("Gross Margin %",    ["Gross Profit"])
    _margin_row("EBIT Margin %",     ["EBIT", "Operating Income"])
    _margin_row("EBITDA Margin %",   ["Normalized EBITDA", "EBITDA"])
    _margin_row("Net Margin %",      ["Net Income", "Net Income Common Stockholders"])
    _margin_row("R&D % of Revenue",  ["Research And Development"])
    _margin_row("SG&A % of Revenue", ["Selling General And Administration",
                                      "Selling And Marketing Expense",
                                      "General And Administrative Expense"])

    # Effective tax rate = Tax Provision / Pretax Income
    ws.cell(r, 1).value = "Effective Tax Rate %"
    for j, col in enumerate(cols):
        tax = _df_get(df_is, "Tax Provision", col)
        pti = _df_get(df_is, "Pretax Income", col)
        cell = ws.cell(r, j + 2)
        cell.value = _safe_div(tax, pti)
        cell.number_format = FMT_RATIO
    r += 1

    r += 1  # spacer

    # YoY growth rates — cols are reverse chronological, so growth is col[i] vs col[i+1]
    def _growth_row(label, label_candidates):
        nonlocal r
        ws.cell(r, 1).value = label
        for j in range(len(cols)):
            cur = _df_any(df_is, label_candidates, cols[j])
            cell = ws.cell(r, j + 2)
            cell.number_format = FMT_RATIO
            if j + 1 < len(cols):
                prior = _df_any(df_is, label_candidates, cols[j + 1])
                if cur not in ("", None) and prior not in ("", None):
                    try:
                        p = float(prior)
                        cell.value = round((float(cur) - p) / abs(p), 4) if p != 0 else ""
                    except (TypeError, ValueError):
                        cell.value = ""
                else:
                    cell.value = ""
            else:
                cell.value = "—"
                cell.number_format = 'General'
        r += 1

    _growth_row("Revenue YoY Growth",    ["Total Revenue", "Operating Revenue"])
    _growth_row("Gross Profit YoY",      ["Gross Profit"])
    _growth_row("EBIT YoY Growth",       ["EBIT", "Operating Income"])
    _growth_row("EBITDA YoY Growth",     ["Normalized EBITDA", "EBITDA"])
    _growth_row("Net Income YoY Growth", ["Net Income", "Net Income Common Stockholders"])
    _growth_row("Diluted EPS YoY",       ["Diluted EPS"])
    return r


def _write_bs_ratios(ws, df_bs, df_is, start_row, cols):
    """Writes capital structure, liquidity, and efficiency ratios below raw BS."""
    if df_bs is None or df_bs.empty or not cols:
        return start_row
    r = start_row + 1
    ws.cell(r, 1).value = "──── HISTORICAL ANALYSIS ────"
    r += 1

    def _compute_row(label, fn, fmt=None):
        """fmt: FMT_DOLLARS_M for $ values, FMT_RATIO for %, FMT_PER_SHARE for per-share."""
        nonlocal r
        ws.cell(r, 1).value = label
        for j, col in enumerate(cols):
            cell = ws.cell(r, j + 2)
            try:
                v = fn(col)
                # Scale dollar outputs (Working Capital, Net Debt) to millions
                if fmt == FMT_DOLLARS_M and v not in ("", None):
                    try:
                        v = float(v) / SCALE_DIVISOR
                    except (TypeError, ValueError):
                        pass
                cell.value = v
                if fmt:
                    cell.number_format = fmt
            except Exception:
                cell.value = ""
        r += 1

    # Derived capital structure
    def _working_capital(col):
        ca = _df_get(df_bs, "Total Current Assets", col)
        cl = _df_get(df_bs, "Total Current Liabilities", col)
        if ca in ("", None) or cl in ("", None):
            return ""
        return float(ca) - float(cl)

    def _net_debt(col):
        td = _df_any(df_bs, ["Total Debt"], col)
        cash = _df_any(df_bs, ["Cash Cash Equivalents And Short Term Investments",
                               "Cash And Cash Equivalents", "Cash Financial"], col)
        if td in ("", None):
            # Reconstruct from ST + LT debt
            std = _df_any(df_bs, ["Current Debt", "Current Debt And Capital Lease Obligation",
                                   "Short Long Term Debt"], col) or 0
            ltd = _df_any(df_bs, ["Long Term Debt", "Long Term Debt And Capital Lease Obligation"], col) or 0
            td = (float(std) if std not in ("",None) else 0) + (float(ltd) if ltd not in ("",None) else 0)
            if td == 0:
                return ""
        if cash in ("", None):
            cash = 0
        return float(td) - float(cash)

    _compute_row("Working Capital", _working_capital, FMT_DOLLARS_M)
    _compute_row("Net Debt",        _net_debt,        FMT_DOLLARS_M)

    # Liquidity ratios
    def _current_ratio(col):
        ca = _df_get(df_bs, "Total Current Assets", col)
        cl = _df_get(df_bs, "Total Current Liabilities", col)
        return _safe_div(ca, cl)

    def _quick_ratio(col):
        ca = _df_get(df_bs, "Total Current Assets", col)
        inv = _df_get(df_bs, "Inventory", col) or 0
        cl = _df_get(df_bs, "Total Current Liabilities", col)
        if ca in ("", None) or cl in ("", None):
            return ""
        quick_assets = float(ca) - (float(inv) if inv not in ("",None) else 0)
        return _safe_div(quick_assets, cl)

    _compute_row("Current Ratio", _current_ratio)
    _compute_row("Quick Ratio",   _quick_ratio)

    # Leverage ratios
    def _de_ratio(col):
        td = _df_any(df_bs, ["Total Debt"], col)
        eq = _df_any(df_bs, ["Stockholders Equity", "Common Stock Equity"], col)
        return _safe_div(td, eq)

    def _debt_to_assets(col):
        td = _df_any(df_bs, ["Total Debt"], col)
        ta = _df_get(df_bs, "Total Assets", col)
        return _safe_div(td, ta)

    _compute_row("Debt / Equity",  _de_ratio,       FMT_RATIO)
    _compute_row("Debt / Assets",  _debt_to_assets, FMT_RATIO)

    # Book value per share (needs IS shares)
    def _bvps(col):
        eq = _df_any(df_bs, ["Stockholders Equity", "Common Stock Equity"], col)
        sh = _df_any(df_bs, ["Ordinary Shares Number", "Share Issued"], col)
        if sh in ("", None) and df_is is not None:
            sh = _df_any(df_is, ["Diluted Average Shares", "Basic Average Shares"], col)
        return _safe_div(eq, sh)

    _compute_row("Book Value / Share", _bvps, FMT_PER_SHARE)

    # Efficiency (requires IS revenue)
    def _asset_turnover(col):
        rev = _df_any(df_is, ["Total Revenue", "Operating Revenue"], col)
        ta  = _df_get(df_bs, "Total Assets", col)
        return _safe_div(rev, ta)

    _compute_row("Asset Turnover (Rev/Assets)", _asset_turnover)

    # Return on capital — ROE, ROA
    def _roe(col):
        ni = _df_any(df_is, ["Net Income", "Net Income Common Stockholders"], col)
        eq = _df_any(df_bs, ["Stockholders Equity", "Common Stock Equity"], col)
        return _safe_div(ni, eq)

    def _roa(col):
        ni = _df_any(df_is, ["Net Income", "Net Income Common Stockholders"], col)
        ta = _df_get(df_bs, "Total Assets", col)
        return _safe_div(ni, ta)

    _compute_row("ROE",  _roe, FMT_RATIO)
    _compute_row("ROA",  _roa, FMT_RATIO)
    return r


def _write_cf_ratios(ws, df_cf, df_is, start_row, cols):
    """Writes cash-flow-to-revenue ratios and reinvestment metrics below raw CF."""
    if df_cf is None or df_cf.empty or not cols:
        return start_row
    r = start_row + 1
    ws.cell(r, 1).value = "──── HISTORICAL ANALYSIS ────"
    r += 1

    def _compute_row(label, fn, fmt=None):
        """fmt: FMT_RATIO for percentages, FMT_DOLLARS_M for $ values."""
        nonlocal r
        ws.cell(r, 1).value = label
        for j, col in enumerate(cols):
            cell = ws.cell(r, j + 2)
            try:
                v = fn(col)
                if fmt == FMT_DOLLARS_M and v not in ("", None):
                    try:
                        v = float(v) / SCALE_DIVISOR
                    except (TypeError, ValueError):
                        pass
                cell.value = v
                if fmt:
                    cell.number_format = fmt
            except Exception:
                cell.value = ""
        r += 1

    def _ocf_to_rev(col):
        ocf = _df_any(df_cf, ["Operating Cash Flow", "Cash Flow From Continuing Operating Activities"], col)
        rev = _df_any(df_is, ["Total Revenue", "Operating Revenue"], col)
        return _safe_div(ocf, rev)

    def _fcf_to_rev(col):
        fcf = _df_get(df_cf, "Free Cash Flow", col)
        rev = _df_any(df_is, ["Total Revenue", "Operating Revenue"], col)
        return _safe_div(fcf, rev)

    def _capex_to_rev(col):
        # yfinance reports CapEx as negative — take abs for ratio readability
        capex = _df_any(df_cf, ["Capital Expenditure", "Capital Expenditure Reported"], col)
        rev = _df_any(df_is, ["Total Revenue", "Operating Revenue"], col)
        if capex in ("", None) or rev in ("", None):
            return ""
        try:
            return _safe_div(abs(float(capex)), rev)
        except (TypeError, ValueError):
            return ""

    def _capex_to_da(col):
        capex = _df_any(df_cf, ["Capital Expenditure", "Capital Expenditure Reported"], col)
        da = _df_any(df_cf, ["Depreciation And Amortization", "Depreciation Amortization Depletion", "Reconciled Depreciation"], col)
        if capex in ("", None) or da in ("", None):
            return ""
        try:
            return _safe_div(abs(float(capex)), abs(float(da)) if da not in ("",None) else 0)
        except (TypeError, ValueError):
            return ""

    def _nwc_to_rev(col):
        nwc = _df_get(df_cf, "Change In Working Capital", col)
        rev = _df_any(df_is, ["Total Revenue", "Operating Revenue"], col)
        return _safe_div(nwc, rev)

    def _sbc_to_rev(col):
        sbc = _df_get(df_cf, "Stock Based Compensation", col)
        rev = _df_any(df_is, ["Total Revenue", "Operating Revenue"], col)
        return _safe_div(sbc, rev)

    def _div_payout(col):
        divs = _df_any(df_cf, ["Common Stock Dividend Paid", "Cash Dividends Paid"], col)
        ni = _df_any(df_is, ["Net Income", "Net Income Common Stockholders"], col)
        if divs in ("", None) or ni in ("", None):
            return ""
        try:
            return _safe_div(abs(float(divs)), float(ni))
        except (TypeError, ValueError):
            return ""

    def _buyback_to_fcf(col):
        bb = _df_any(df_cf, ["Repurchase Of Capital Stock", "Common Stock Payments"], col)
        fcf = _df_get(df_cf, "Free Cash Flow", col)
        if bb in ("", None) or fcf in ("", None):
            return ""
        try:
            return _safe_div(abs(float(bb)), float(fcf))
        except (TypeError, ValueError):
            return ""

    def _quality_of_earnings(col):
        # OCF / Net Income — > 1.0 is high quality
        ocf = _df_any(df_cf, ["Operating Cash Flow", "Cash Flow From Continuing Operating Activities"], col)
        ni = _df_any(df_is, ["Net Income", "Net Income Common Stockholders"], col)
        return _safe_div(ocf, ni)

    _compute_row("OCF / Revenue",         _ocf_to_rev,    FMT_RATIO)
    _compute_row("FCF / Revenue",         _fcf_to_rev,    FMT_RATIO)
    _compute_row("CapEx / Revenue",       _capex_to_rev,  FMT_RATIO)
    _compute_row("CapEx / D&A (reinv.)",  _capex_to_da)  # multiple, not a %
    _compute_row("ΔNWC / Revenue",        _nwc_to_rev,    FMT_RATIO)
    _compute_row("SBC / Revenue",         _sbc_to_rev,    FMT_RATIO)
    _compute_row("Dividend Payout Ratio", _div_payout,    FMT_RATIO)
    _compute_row("Buybacks / FCF",        _buyback_to_fcf, FMT_RATIO)
    _compute_row("Quality of Earnings (OCF/NI)", _quality_of_earnings)  # multiple
    return r


def _write_key_items(ws, ticker_obj, max_years=10):
    _clear_sheet(ws)
    try:
        inc = ticker_obj.income_stmt
        cols = sorted(inc.columns, reverse=True)[:max_years]
        years = [c.year for c in cols]
        ws.cell(1, 1).value = "Key Items  (US$ millions, except per-share)"
        for i, yr in enumerate(years):
            c = ws.cell(1, i + 2); c.value = yr; c.number_format = FMT_YEAR
        row, written = 2, set()
        for yf_lbl, fs_lbl in KEY_ITEMS_MAP.items():
            if fs_lbl in written or yf_lbl not in inc.index:
                continue
            ws.cell(row, 1).value = fs_lbl
            for j, col in enumerate(cols):
                raw = _n(inc.loc[yf_lbl, col])
                scaled, fmt = _scale_and_format(fs_lbl, raw)
                cell = ws.cell(row, j + 2)
                cell.value = scaled
                if fmt:
                    cell.number_format = fmt
            written.add(fs_lbl)
            row += 1
        # Dividends per share from history (already per-share, no scaling)
        try:
            divs = ticker_obj.dividends
            if not divs.empty:
                annual = divs.resample("YE").sum()
                ws.cell(row, 1).value = "Dividends per Share"
                for j, col in enumerate(cols):
                    match = [d for d in annual.index if d.year == col.year]
                    cell = ws.cell(row, j + 2)
                    cell.value = float(annual.loc[match[0]]) if match else ""
                    cell.number_format = FMT_PER_SHARE
                row += 1
        except Exception:
            pass
        # Free Cash Flow — consumed by Cash Flow Forecast!B66/B68 and Scenario
        # Analysis terminal-growth bridge. Pulled from cashflow statement, scaled.
        try:
            cf = ticker_obj.cashflow
            if cf is not None and not cf.empty and "Free Cash Flow" in cf.index:
                ws.cell(row, 1).value = "Free Cash Flow"
                for j, col in enumerate(cols):
                    try:
                        raw = _n(cf.loc["Free Cash Flow", col]) if col in cf.columns else ""
                    except Exception:
                        raw = ""
                    cell = ws.cell(row, j + 2)
                    if raw not in ("", None):
                        cell.value = float(raw) / SCALE_DIVISOR
                        cell.number_format = FMT_DOLLARS_M
                    else:
                        cell.value = ""
                row += 1
        except Exception:
            pass
        # Return on Equity (trailing) — consumed by Required Return!K69 dividend
        # growth rate helper. Source from info (decimal, e.g. 0.23 = 23%).
        try:
            info = ticker_obj.info
            roe = info.get("returnOnEquity")
            if roe is not None:
                ws.cell(row, 1).value = "Return on Equity"
                cell = ws.cell(row, 2)
                cell.value = float(roe)
                cell.number_format = FMT_RATIO
                row += 1
            # Payout Ratio — also consumed by Required Return!K69
            payout = info.get("payoutRatio")
            if payout is not None:
                ws.cell(row, 1).value = "Payout Ratio"
                cell = ws.cell(row, 2)
                cell.value = float(payout)
                cell.number_format = FMT_RATIO
                row += 1
        except Exception:
            pass
        # Shares outstanding (most recent, in millions) — already pre-scaled here
        try:
            info = ticker_obj.info
            shares = info.get("sharesOutstanding") or info.get("impliedSharesOutstanding")
            if shares:
                ws.cell(row, 1).value = "Diluted Shares Outstanding (M)"
                c1 = ws.cell(row, 2); c1.value = round(shares / 1e6, 2); c1.number_format = FMT_SHARES_M
                c2 = ws.cell(row, 3); c2.value = round(shares / 1e6, 2); c2.number_format = FMT_SHARES_M
        except Exception:
            pass
        print(f"  ✓  Key Items: {row-2} items written  [scaled to millions]")
    except Exception as e:
        print(f"  ⚠  Key Items: {e}")


def _write_estimates(ws, ticker_obj):
    _clear_sheet(ws)
    try:
        info = ticker_obj.info
        ws.cell(1, 1).value = "Metric"
        ws.cell(1, 2).value = "Value  (US$ millions, except ratios/EPS)"
        # (label, raw value, kind) where kind = "$", "%", "eps", "price"
        items = [
            ("Sales",             info.get("totalRevenue"),      "$"),
            ("Net Income - GAAP", info.get("netIncomeToCommon"), "$"),
            ("EPS",               info.get("forwardEps"),        "eps"),
            ("Free Cash Flow",    info.get("freeCashflow"),      "$"),
            ("Revenue Growth",    info.get("revenueGrowth"),     "%"),
            ("Earnings Growth",   info.get("earningsGrowth"),    "%"),
            ("Net Income",        info.get("netIncomeToCommon"), "$"),
            # Street consensus targets — used by Cover!C19 and other consumers
            ("Target Price",      info.get("targetMeanPrice"),   "price"),
            ("Target High",       info.get("targetHighPrice"),   "price"),
            ("Target Low",        info.get("targetLowPrice"),    "price"),
            ("# Analysts",        info.get("numberOfAnalystOpinions"), "int"),
        ]
        r = 2
        for label, val, kind in items:
            v = _n(val)
            if v == "" or v is None:
                continue
            cell_label = ws.cell(r, 1); cell_label.value = label
            cell_val   = ws.cell(r, 2)
            try:
                if kind == "$":
                    cell_val.value = float(v) / SCALE_DIVISOR
                    cell_val.number_format = FMT_DOLLARS_M
                elif kind == "%":
                    cell_val.value = float(v)
                    cell_val.number_format = FMT_RATIO
                elif kind == "price":
                    cell_val.value = float(v)
                    cell_val.number_format = FMT_PER_SHARE
                elif kind == "int":
                    cell_val.value = int(v)
                    cell_val.number_format = '0'
                else:  # eps
                    cell_val.value = float(v)
                    cell_val.number_format = FMT_PER_SHARE
            except (TypeError, ValueError):
                cell_val.value = v
            r += 1
        print(f"  ✓  Estimates: {r-2} items written  [scaled to millions]")
    except Exception as e:
        print(f"  ⚠  Estimates: {e}")


# ─── Peer Industry Ratios (Audit #4 — fallback chain) ─────────────────────────
#
# For each peer in the comparison set, fetch the full income statement,
# balance sheet, and cash flow statement, then compute the 5 ratios that the
# CFF!H28–H33 formulas depend on but yfinance's `info` dict does NOT expose:
#
#   CapEx / Revenue          (cashflow's "Capital Expenditure" / IS Revenue)
#   D&A    / Revenue         (IS or cashflow line / IS Revenue)
#   ΔNWC   / Revenue         (BS year-over-year change in working capital / Rev)
#   Effective Tax Rate       (IS Tax Provision / IS Pretax Income)
#   Interest / Revenue       (IS Interest Expense / IS Revenue)
#
# These become Tier-2 fallbacks for the workbook's CFF!H## cells: if the
# target company's own historicals are missing or sparse (new IPO, foreign
# listing, schema drift), the formula falls back to the peer average. If
# peers also fail, it falls back to CONFIG analyst values. If those are
# None, the formula resolves to a visible "N/A" string — never a silent
# magic number.
#
# Output: a dict like {"capex_to_sales": 0.27, "da_to_sales": 0.21, ...}
# written to a fixed block on the Industry tab so CFF formulas can VLOOKUP
# them by stable references.

def _safe_get_df(df, label, col):
    """Pull a value from a yfinance DataFrame. Returns None on miss."""
    if df is None or df.empty:
        return None
    if label not in df.index:
        return None
    v = df.loc[label, col]
    if v is None or (isinstance(v, float) and math.isnan(v)):
        return None
    return float(v)


def _per_year_ratios_for_one_ticker(sym, multi_year=False):
    """Compute the 7 driver ratios for ONE ticker.

    If multi_year=False (peer-cohort default): use only the most recent year.
    If multi_year=True (target-company default): compute per-year ratios for
    each available year, then return the average across years for that ticker.

    Returns a dict {ratio_key: value or None}.
    """
    out_keys = (
        "capex_to_sales", "da_to_sales", "nwc_to_sales",
        "effective_tax", "interest_to_sales",
        "ebit_to_sales", "revenue_growth",
    )
    blanks = {k: None for k in out_keys}

    try:
        t = yf.Ticker(sym)
        inc = t.income_stmt
        bs  = t.balance_sheet
        cf  = t.cashflow

        if inc is None or inc.empty:
            return blanks

        cols = list(inc.columns)
        if multi_year:
            # Compute each year's ratio (skipping years with bad data) then
            # average across years for THIS ticker.
            year_pairs = [(cols[i], cols[i+1] if i+1 < len(cols) else None)
                          for i in range(len(cols))]
        else:
            # Just the most recent year.
            year_pairs = [(cols[0], cols[1] if len(cols) > 1 else None)]

        accum = {k: [] for k in out_keys}
        for cur, prev in year_pairs:
            rev = _safe_get_df(inc, "Total Revenue", cur)
            if rev is None or rev == 0:
                rev = _safe_get_df(inc, "Operating Revenue", cur)
            if rev is None or rev == 0:
                continue

            # CapEx — yfinance reports negative; we want positive ratio
            capex = _safe_get_df(cf, "Capital Expenditure", cur)
            if capex is not None:
                accum["capex_to_sales"].append(abs(capex) / rev)

            # D&A — try cashflow then IS
            da = _safe_get_df(cf, "Depreciation And Amortization", cur)
            if da is None:
                da = _safe_get_df(cf, "Depreciation Amortization Depletion", cur)
            if da is None:
                da = _safe_get_df(inc, "Reconciled Depreciation", cur)
            if da is not None:
                accum["da_to_sales"].append(abs(da) / rev)

            # NWC LEVEL / Revenue — match the workbook's CFF!B33 formula:
            #   ((Total CA − Cash) − (Total CL − Short-Term Debt)) / Revenue
            # This is "Operating Working Capital" / Revenue — the standard
            # forecasting ratio. CRITICAL: must be LEVEL, not year-over-year
            # CHANGE — the downstream forecast (CFF B62 = $H$33 × taper)
            # treats this as the level NWC intensity, then ΔNWC is computed
            # as (forecast NWC level − base NWC level). If we supplied CHANGE
            # here instead, the forecast would compound a delta where a level
            # was expected, producing absurd FCF numbers.
            ca = _safe_get_df(bs, "Current Assets", cur)
            cl = _safe_get_df(bs, "Current Liabilities", cur)
            cash = _safe_get_df(bs, "Cash And Cash Equivalents", cur)
            if cash is None:
                cash = _safe_get_df(bs, "Cash", cur)
            if cash is None:
                cash = _safe_get_df(bs, "Cash Cash Equivalents And Short Term Investments", cur)
            stdebt = _safe_get_df(bs, "Current Debt", cur)
            if stdebt is None:
                stdebt = _safe_get_df(bs, "Short Term Debt", cur)
            if stdebt is None:
                stdebt = 0.0   # legitimate zero — many companies have no ST debt
            if ca is not None and cl is not None:
                op_ca = ca - (cash or 0.0)
                op_cl = cl - stdebt
                op_wc = op_ca - op_cl
                accum["nwc_to_sales"].append(op_wc / rev)

            tax    = _safe_get_df(inc, "Tax Provision", cur)
            pretax = _safe_get_df(inc, "Pretax Income", cur)
            if tax is not None and pretax is not None and pretax != 0:
                rate = tax / pretax
                if 0 < rate < 0.50:
                    accum["effective_tax"].append(rate)

            interest = _safe_get_df(inc, "Interest Expense", cur)
            if interest is not None:
                accum["interest_to_sales"].append(abs(interest) / rev)

            ebit = _safe_get_df(inc, "EBIT", cur)
            if ebit is None:
                ebit = _safe_get_df(inc, "Operating Income", cur)
            if ebit is not None:
                accum["ebit_to_sales"].append(ebit / rev)

            rev_prev = _safe_get_df(inc, "Total Revenue", prev) if prev is not None else None
            if rev_prev is not None and rev_prev != 0:
                accum["revenue_growth"].append((rev / rev_prev) - 1)

        return {k: (sum(vs) / len(vs)) if vs else None for k, vs in accum.items()}

    except Exception as e:
        print(f"  ⚠  ratios for {sym}: {type(e).__name__}: {e}")
        return blanks


def _fetch_target_company_history_ratios(target_ticker):
    """Multi-year company-history ratios for the TARGET ticker.

    Audit #6 (Apr-2026): Python-computed deterministic Tier-1a cross-check
    that bypasses the in-Excel SUMPRODUCT/IF array formulas in CFF!H##.
    If those formulas silently fail (Excel array-evaluation quirks, stale
    cached values), this layer guarantees we still have a real
    company-history number rather than falling through to peer industry.
    """
    if not target_ticker:
        return {}
    return _per_year_ratios_for_one_ticker(target_ticker, multi_year=True)


def _fetch_peer_industry_ratios(peer_tickers):
    """Cross-peer current-year ratios — the Tier-2 industry fallback.

    For each peer in the cohort, computes the most-recent-year ratio,
    then averages across peers. Single-year cross-section is the right
    semantic for an "industry typical" reading; multi-year would smear
    cycles together and be less useful as a fallback.
    """
    if not peer_tickers:
        return {}
    per_peer = {k: [] for k in (
        "capex_to_sales", "da_to_sales", "nwc_to_sales",
        "effective_tax", "interest_to_sales",
        "ebit_to_sales", "revenue_growth",
    )}
    for sym in peer_tickers:
        ratios = _per_year_ratios_for_one_ticker(sym, multi_year=False)
        for k, v in ratios.items():
            if v is not None:
                per_peer[k].append(v)

    # Average across peers (skip empty buckets → None signals fall-through)
    out = {}
    for k, vals in per_peer.items():
        out[k] = (sum(vals) / len(vals)) if vals else None
    return out


# ─── Peer Comparison ───────────────────────────────────────────────────────────

def _fetch_peer_row(sym):
    try:
        t = yf.Ticker(sym)
        info = t.info
        row = {}
        for label, key, fn in PEER_METRICS:
            if key == "__ticker__":
                row[label] = sym.upper()
            else:
                try:
                    raw = info.get(key)
                    row[label] = fn(raw) if raw is not None else ""
                except Exception:
                    row[label] = ""

        # ── Fallbacks for fields yfinance frequently leaves null ──
        mcap = _n(info.get("marketCap"))
        rev  = _n(info.get("totalRevenue"))
        ev   = _n(info.get("enterpriseValue"))
        price = _n(info.get("currentPrice"))

        # P/Sales fallback: Market Cap / Revenue
        if row.get("P/Sales (TTM)") in ("", None) and mcap != "" and rev not in ("", 0):
            row["P/Sales (TTM)"] = mcap / rev

        # EBITDA fallback: ebitdaMargins * totalRevenue
        if row.get("EBITDA ($M)") in ("", None):
            em = _n(info.get("ebitdaMargins"))
            if em != "" and rev != "":
                row["EBITDA ($M)"] = (em * rev) / 1e6

        # EV/Revenue fallback: EV / Revenue
        if row.get("EV/Revenue") in ("", None) and ev != "" and rev not in ("", 0):
            row["EV/Revenue"] = ev / rev

        # EV/EBITDA fallback: EV / (ebitdaMargins * revenue)
        if row.get("EV/EBITDA") in ("", None) and ev != "":
            em = _n(info.get("ebitdaMargins"))
            if em not in ("", 0) and rev not in ("", 0):
                ebitda_calc = em * rev
                if ebitda_calc:
                    row["EV/EBITDA"] = ev / ebitda_calc

        # Free CF fallback: operatingCashflow - capex (capex is negative in yf)
        if row.get("Free CF ($M)") in ("", None):
            ocf = _n(info.get("operatingCashflow"))
            capex = _n(info.get("capitalExpenditures"))
            if ocf != "" and capex != "":
                row["Free CF ($M)"] = (ocf + capex) / 1e6  # capex already negative

        # P/E TTM fallback: price / trailingEps; "N/M" if earnings negative
        # (negative EPS makes P/E mathematically undefined — Street convention
        #  is "N/M" = Not Meaningful, ranked worst in scorecard)
        if row.get("P/E (TTM)") in ("", None):
            teps = _n(info.get("trailingEps"))
            if teps not in ("", 0) and teps > 0 and price != "":
                row["P/E (TTM)"] = price / teps
            else:
                row["P/E (TTM)"] = "N/M"

        # Earnings Growth fallback: quarterly growth
        if row.get("Earnings Growth") in ("", None):
            eq = _n(info.get("earningsQuarterlyGrowth"))
            row["Earnings Growth"] = eq if eq != "" else 0

        # Dividend-related: non-payers legitimately = 0
        if row.get("Div Yield") in ("", None):
            row["Div Yield"] = 0
        if row.get("Payout Ratio") in ("", None):
            row["Payout Ratio"] = 0

        # Final sweep: replace any remaining blanks in numeric fields with 0.
        # Excludes valuation multiples — when undefined (e.g. negative earnings
        # → P/E), Street convention is "N/M", not 0, so we leave them be and
        # the refresh step tags them "N/M" explicitly where appropriate.
        _NUMERIC_LABELS = {
            "Market Cap ($M)", "Price", "52-Wk High", "52-Wk Low", "Beta (3-yr)",
            "Revenue Growth", "Earnings Growth", "Gross Margin",
            "EBIT Margin", "Net Margin", "ROE", "ROA", "Debt/Equity",
            "Current Ratio", "Revenue ($M)", "EBITDA ($M)", "Free CF ($M)",
            "Div Yield", "Payout Ratio", "Price Target", "Target High",
            "Target Low", "# Analysts",
        }
        for lbl in _NUMERIC_LABELS:
            if row.get(lbl) in ("", None):
                row[lbl] = 0
        # Multiples: if still blank after fallbacks, mark N/M
        _MULTIPLE_LABELS = {"P/E (TTM)", "P/E (NTM)", "EV/EBITDA",
                            "EV/Revenue", "P/Book", "P/Sales (TTM)"}
        for lbl in _MULTIPLE_LABELS:
            if row.get(lbl) in ("", None):
                row[lbl] = "N/M"

        return row
    except Exception as e:
        print(f"  ⚠  {sym}: {e}")
        return {label: "" for label, _, _ in PEER_METRICS}


def _build_peer_comparison(ws, target, peers):
    """Write peer comparison sheet and return (target_beta, peer_avg_beta, peer_avg_pe_ntm)."""
    all_syms = [target] + peers
    print(f"  Fetching: {', '.join(all_syms)}")
    data = {}
    for sym in all_syms:
        print(f"    → {sym} ...", end=" ", flush=True)
        data[sym] = _fetch_peer_row(sym)
        print("✓")

    _clear_sheet(ws, max_row=200, max_col=30)
    labels = [m[0] for m in PEER_METRICS]
    n = len(peers)

    # Header
    ws.cell(1, 1).value = "Metric"
    ws.cell(1, 2).value = f"{target} (Target)"
    for i, sym in enumerate(peers):
        ws.cell(1, i + 3).value = sym
    if n > 0:
        ws.cell(1, n + 3).value = "Peer Average"

    # Data rows
    for ri, label in enumerate(labels):
        ws.cell(ri + 2, 1).value = label
        ws.cell(ri + 2, 2).value = data[target].get(label, "")
        peer_vals = []
        for i, sym in enumerate(peers):
            v = data[sym].get(label, "")
            ws.cell(ri + 2, i + 3).value = v
            if isinstance(v, (int, float)):
                peer_vals.append(v)
        if n > 0 and peer_vals and isinstance(data[target].get(label, ""), (int, float)):
            ws.cell(ri + 2, n + 3).value = round(sum(peer_vals) / len(peer_vals), 4)

    # Wire the three cells the template formulas depend on:
    #   G28 = target company beta  → Required Return pulls this via Instructions!U30
    #   G34 = peer average beta    → Required Return pulls this via Instructions!U31
    #   B11 = peer average P/E NTM → Instructions!U32
    target_beta   = data[target].get("Beta (3-yr)", "")
    peer_betas    = [v for s in peers if isinstance((v := data[s].get("Beta (3-yr)", "")), (int,float))]
    peer_avg_beta = round(sum(peer_betas) / len(peer_betas), 4) if peer_betas else ""
    peer_pes      = [v for s in peers if isinstance((v := data[s].get("P/E (NTM)", "")), (int,float))]
    peer_avg_pe   = round(sum(peer_pes)   / len(peer_pes),   2) if peer_pes   else ""

    ws.cell(28, 7).value = target_beta    # G28
    ws.cell(34, 7).value = peer_avg_beta  # G34
    ws.cell(11, 2).value = peer_avg_pe    # B11

    print(f"  ✓  Peer Comparison: {len(all_syms)} companies, {len(labels)} metrics each")
    if isinstance(peer_avg_beta, float):
        print(f"     Target β={target_beta:.2f}  |  Peer avg β={peer_avg_beta:.2f}  |  Peer avg NTM P/E={peer_avg_pe}")
    return target_beta, peer_avg_beta, peer_avg_pe


# ─── Instructions auto-fill ────────────────────────────────────────────────────

def _fill_instructions(wb, ticker_obj, macro_data, quarters):
    """Populate as many Instructions input cells as possible from live data."""
    try:
        ws   = wb["Instructions"]
        info = ticker_obj.info

        def safe_set(r, c, v):
            if v not in (None, "", float("nan")):
                try:
                    ws.cell(r, c).value = v
                except Exception:
                    pass

        # U43: Quarters to FY end
        safe_set(43, 21, quarters)

        # U77: 10-yr Treasury yield
        if macro_data.get("treasury"):
            safe_set(77, 21, macro_data["treasury"])

        # U89: Damodaran ERP
        if macro_data.get("erp"):
            safe_set(89, 21, macro_data["erp"])

        # U59: Analyst mean price target
        safe_set(59, 21, info.get("targetMeanPrice"))

        # U60: Long-term growth rate
        safe_set(60, 21, info.get("longTermPotentialGrowthRate") or info.get("earningsGrowth"))

        # U65/U66: High/low price targets
        safe_set(65, 21, info.get("targetHighPrice"))
        safe_set(66, 21, info.get("targetLowPrice"))

        # U67: Forward EPS (highest estimate proxy)
        safe_set(67, 21, info.get("forwardEps"))

        # U95: Beta
        safe_set(95, 21, info.get("beta"))

        # U63: Next fiscal year (year number)
        try:
            inc_cols = sorted(ticker_obj.income_stmt.columns, reverse=True)
            if inc_cols:
                last_fy_year = inc_cols[0].year
                safe_set(63, 21, last_fy_year + 1)
        except Exception:
            pass

        # U93/U97: Weight of equity/debt (market cap based)
        try:
            mc  = float(info.get("marketCap") or 0)
            td  = float(info.get("totalDebt")  or 0)
            tot = mc + td
            if tot > 0:
                safe_set(93, 21, round(mc / tot, 4))
                safe_set(97, 21, round(td / tot, 4))
        except Exception:
            pass

        # IS!A1 = company name (header). IS!A2 is reserved for the row label
        # "Sales" written by _write_stmt above — DO NOT WRITE TO IT.
        #
        # CRITICAL bug-fix Apr-2026: this block previously also wrote the
        # current stock price into IS!A2, clobbering the "Sales" row label
        # that 'Cash Flow Forecast'!B8 (and many other) VLOOKUP formulas
        # depend on. The result was a silent collapse of the entire DCF
        # cascade: Sales VLOOKUP → #N/A → IFERROR → 0 → revenue forecast 0
        # → unlevered FCF 0 → DCF fair value negative once Net Debt > 0.
        #
        # The current price has plenty of other homes (Required Return!C5,
        # Cover row 4, Instructions panel) — there's no reason to duplicate
        # it in IS, and no formula downstream reads IS!A2 as a price.
        # Verified: 0 workbook references to IS!A2 in any formula.
        wb["IS"].cell(1, 1).value = info.get("longName") or ticker_obj.ticker

        # ── Audit #11 — write current stock price to Required Return!C5 ─────
        # Without this, RR!C5 stayed at whatever value was last saved in the
        # template (e.g. $457.23 from a Thursday run, even when the user
        # re-ran on Monday with MU at $524). The pipeline pulled `currentPrice`
        # from yfinance for peer-comparison and the price-reconcile gate, but
        # never wrote it back to the canonical RR!C5 cell.
        #
        # The template's RR!C5 is the single source of truth for "current
        # market price" — referenced by Cover row 4/6, every "vs Market"
        # column on the Valuation Summary, the Reverse DCF tab section 1,
        # and dozens of other formulas. If it's stale, everything is stale.
        #
        # We use a 3-tier fallback: regularMarketPrice → currentPrice →
        # ticker.history(). The history fetch is the most reliable in
        # off-hours / weekend / market-closed conditions.
        try:
            cur_price = (info.get("regularMarketPrice")
                         or info.get("currentPrice")
                         or info.get("previousClose"))
            if cur_price is None:
                # Last-resort: pull most recent close from the daily history
                hist = ticker_obj.history(period="2d")
                if hist is not None and not hist.empty:
                    cur_price = float(hist["Close"].iloc[-1])
            if cur_price is not None and float(cur_price) > 0:
                wb["Required Return"]["C5"].value = float(cur_price)
                print(f"  ✓  Required Return!C5 refreshed to ${float(cur_price):.2f} "
                      f"(yfinance live)")
        except Exception as e:
            print(f"  ⚠  RR!C5 price refresh failed: {type(e).__name__}: {e}")

        print(f"  ✓  Instructions: {len([k for k,v in macro_data.items() if v])} macro inputs + analyst data populated")

    except Exception as e:
        print(f"  ⚠  Instructions partial: {e}")


# ─── Main refresh function (all platforms) ────────────────────────────────────

def refresh_data(target_ticker, peer_tickers=None, workbook_path=None):
    """
    The core function. Pulls everything and writes to the workbook.

    Args:
        target_ticker  : e.g. "MU"
        peer_tickers   : list like ["INTC","AMD"] — or None to skip
        workbook_path  : full path to .xlsm/.xlsx — auto-detected if None
    """
    target_ticker = target_ticker.upper().strip()
    peers = [p.upper().strip() for p in (peer_tickers or []) if p.strip()]

    # Auto-find workbook if not specified
    if workbook_path is None:
        script_dir = os.path.dirname(os.path.abspath(__file__))
        candidates = sorted(
            [f for f in os.listdir(script_dir) if f.endswith((".xlsm", ".xlsx"))],
            key=lambda f: os.path.getmtime(os.path.join(script_dir, f)),
            reverse=True
        )
        if not candidates:
            raise FileNotFoundError(f"No Excel file found in {script_dir}")
        workbook_path = os.path.join(script_dir, candidates[0])

    # ── Banner ─────────────────────────────────────────────────────────────────
    width = 60
    print("=" * width)
    print(f"  DCF Data Refresh  |  {target_ticker}  |  {datetime.now():%Y-%m-%d %H:%M}")
    if peers:
        print(f"  Peers: {', '.join(peers)}")
    print(f"  File:  {os.path.basename(workbook_path)}")
    print("=" * width)

    # ── Step 1: Fetch macro data (Treasury + Damodaran ERP) ───────────────────
    print("\n[1/4] Fetching macro data ...")

    treasury = fetch_treasury_yield()
    if treasury:
        print(f"  ✓  10-yr Treasury yield: {treasury*100:.2f}%")
    else:
        print("  ⚠  Treasury yield unavailable — enter manually in Instructions!U77")

    erp = fetch_damodaran_erp()
    if erp:
        print(f"  ✓  Damodaran ERP: {erp*100:.2f}%")
    else:
        print("  ⚠  Damodaran ERP unavailable — enter manually in Instructions!U89")

    macro_data = {"treasury": treasury, "erp": erp}

    # ── Step 2: Fetch target company financials ────────────────────────────────
    print(f"\n[2/4] Fetching financials for {target_ticker} ...")
    t = yf.Ticker(target_ticker)
    inc  = t.income_stmt
    bs   = t.balance_sheet
    cf   = t.cashflow

    if inc is None or inc.empty:
        print(f"\n  ERROR: No data returned for '{target_ticker}'.")
        print("  Double-check the ticker symbol — it must match exactly (e.g. 'MU', not 'Micron').")
        return

    # Detect reporting units
    try:
        rev  = abs(float(inc.loc["Total Revenue", inc.columns[0]]))
        unit = "billions" if rev >= 5e9 else "millions"
        print(f"  ✓  Units: {unit}  (revenue ≈ ${rev/1e9:.1f}B)" if unit=="billions"
              else f"  ✓  Units: {unit}  (revenue ≈ ${rev/1e6:.0f}M)")
    except Exception:
        unit = "millions"
        print(f"  ✓  Units: {unit} (default)")

    # Fiscal year quarters
    quarters = detect_fiscal_year_quarters(t)
    if quarters != "":
        print(f"  ✓  Quarters to fiscal year-end: {quarters}")

    # ── Step 3: Write to workbook ──────────────────────────────────────────────
    print(f"\n[3/4] Writing financial statements ...")
    wb = load_workbook(workbook_path, keep_vba=True)

    # Raw statements first
    _clear_sheet(wb["IS"]); is_next_row, is_cols = _write_stmt(wb["IS"], IS_MAP, inc)
    _clear_sheet(wb["BS"]); bs_next_row, bs_cols = _write_stmt(wb["BS"], BS_MAP, bs)
    _clear_sheet(wb["CF"]); cf_next_row, cf_cols = _write_stmt(wb["CF"], CF_MAP, cf)

    # Historical Analysis — margins, growth rates, leverage, reinvestment ratios.
    # Lives immediately below the raw statement so the Driver Sensitivity tab
    # and CFF forecast have 5-10 years of real historicals to anchor on.
    print("  Writing historical analysis (margins, growth, leverage) ...")
    _write_is_ratios(wb["IS"], inc, is_next_row, is_cols)
    _write_bs_ratios(wb["BS"], bs, inc, bs_next_row, bs_cols)
    _write_cf_ratios(wb["CF"], cf, inc, cf_next_row, cf_cols)

    _write_key_items(wb["Key Items"], t)
    _write_estimates(wb["Estimates"], t)

    # Unit flags in Instructions
    for row in [48, 49, 50]:
        wb["Instructions"].cell(row, 21).value = "millions"

    # ── Step 4: Peer comparison ────────────────────────────────────────────────
    target_beta = peer_avg_beta = peer_avg_pe = ""
    if peers:
        print(f"\n[4/4] Building peer comparison ...")
        target_beta, peer_avg_beta, peer_avg_pe = _build_peer_comparison(
            wb["Peer Comparison"], target_ticker, peers
        )
    else:
        print("\n[4/4] No peers specified — Peer Comparison skipped")

    # ── Step 4b: Peer industry ratios + target-company multi-year history ─────
    # Audit #4: peer-average ratios (Tier-2 fallback) for CapEx/D&A/NWC/Tax/...
    # Audit #6: target-company multi-year history (Tier-1a cross-check) computed
    # in Python to bypass Excel SUMPRODUCT/IF array-evaluation issues that have
    # caused the in-workbook Tier-1 averages to silently fail in some sessions.
    # Writes to Industry!B14:E20 — column B peer, C config, D effective, E target.
    peer_ratios = {}
    target_ratios = {}
    if peers:
        print(f"\n[4b/4] Computing peer industry ratios (CapEx/D&A/NWC/Tax/Interest)...")
        peer_ratios = _fetch_peer_industry_ratios(peers)
        for k, v in peer_ratios.items():
            tag = f"{v*100:>5.1f}%" if v is not None else "  N/A"
            print(f"     peer  {k:<22} : {tag}")

    print(f"\n[4c/4] Computing target multi-year company history ({target_ticker})...")
    target_ratios = _fetch_target_company_history_ratios(target_ticker)
    for k, v in target_ratios.items():
        tag = f"{v*100:>5.1f}%" if v is not None else "  N/A"
        print(f"     target {k:<22} : {tag}")

    # Write peer-derived ratios + CONFIG analyst tier to the Industry tab so
    # the workbook formulas have stable references.  Layout (row → metric):
    #   14: CapEx/Sales       (used by CFF!H31)
    #   15: D&A/Sales         (used by CFF!H32)
    #   16: NWC/Sales         (used by CFF!H33)
    #   17: Effective Tax     (used by CFF!H30)
    #   18: Interest/Sales    (used by CFF!H29)
    #   19: EBIT/Sales        (used by CFF!H28)
    #   20: Revenue Growth    (used by CFF!H26 — and Industry!B5 propagation)
    # Column B = peer industry avg (or "N/A" if unavailable)
    # Column C = CONFIG analyst tier (curated mid-cycle; or "N/A" if None)
    # Column D = which tier the workbook should prefer (peer if num, else config)
    try:
        from dcf_config import CONFIG as _CFG
    except Exception:
        _CFG = None

    def _config_or_na(attr_name):
        v = getattr(_CFG, attr_name, None) if _CFG is not None else None
        return v if v is not None else "N/A"

    industry_block = [
        # (row, label, peer_key, config_attr)
        (14, "CapEx / Sales",    "capex_to_sales",     "analyst_capex_to_sales"),
        (15, "D&A / Sales",      "da_to_sales",        "analyst_da_to_sales"),
        (16, "NWC / Sales",      "nwc_to_sales",       "analyst_nwc_to_sales"),
        (17, "Effective Tax",    "effective_tax",      "analyst_effective_tax"),
        (18, "Interest / Sales", "interest_to_sales",  "analyst_interest_to_sales"),
        (19, "EBIT / Sales",     "ebit_to_sales",      "analyst_ebit_to_sales"),
        (20, "Revenue Growth",   "revenue_growth",     "analyst_revenue_growth"),
    ]
    ind_ws = wb["Industry"]
    # Section header
    ind_ws["A13"].value = "DCF DRIVER RATIOS — Peer / Config / Target / Effective"
    ind_ws["B13"].value = "Peer Avg (T2)"
    ind_ws["C13"].value = "CONFIG (T3)"
    ind_ws["D13"].value = "Effective"
    ind_ws["E13"].value = "Target Hist (T1a)"
    for row, label, peer_key, cfg_attr in industry_block:
        ind_ws.cell(row, 1).value = label
        peer_v = peer_ratios.get(peer_key) if peers else None
        ind_ws.cell(row, 2).value = peer_v if peer_v is not None else "N/A"
        ind_ws.cell(row, 3).value = _config_or_na(cfg_attr)
        # E column (Tier 1a): Python-computed target multi-year history
        target_v = target_ratios.get(peer_key)
        ind_ws.cell(row, 5).value = target_v if target_v is not None else "N/A"
        # D column (effective): prefer target history → peer → config → "N/A"
        ind_ws.cell(row, 4).value = (
            f'=IF(ISNUMBER(E{row}),E{row},'
            f'IF(ISNUMBER(B{row}),B{row},'
            f'IF(ISNUMBER(C{row}),C{row},"N/A")))'
        )

    # Fill Instructions inputs
    _fill_instructions(wb, t, macro_data, quarters)

    # ── Price reconcile gate (B2) ──────────────────────────────────────────────
    # Non-halting sanity check: does market price ≈ trailing EPS × trailing PE?
    # Logs a warning when the IS-derived anchor drifts > tolerance from the
    # live market price, so the desk sees data quality issues without the
    # model silently producing wrong fair values.
    try:
        from dcf_config import CONFIG as _CFG
        _tol = getattr(_CFG, "price_reconcile_tolerance", 0.15)
    except Exception:
        _tol = 0.15
    try:
        _info  = t.info or {}
        _price = _n(_info.get("currentPrice"))
        _eps   = _n(_info.get("trailingEps"))
        _pe    = _n(_info.get("trailingPE"))
        if _price and _eps and _pe:
            _implied = _eps * _pe
            _drift   = abs(_implied / _price - 1.0) if _price else 0
            if _drift > _tol:
                print(f"\n  ⚠  PRICE RECONCILE [{target_ticker}]: "
                      f"EPS×PE={_implied:.2f} vs Price={_price:.2f} "
                      f"(drift {_drift*100:.1f}% > {_tol*100:.0f}% tol).")
                print(f"     Valuation anchors may be stale — verify IS/Estimates tabs.")
            else:
                print(f"  ✓  Price reconcile OK  ({_drift*100:.1f}% drift)")
    except Exception as _e:
        print(f"  ⚠  Price reconcile skipped: {_e}")

    # ── Save ───────────────────────────────────────────────────────────────────
    wb.save(workbook_path)

    # ── Required Return polish (durable backport of v7 cleanup) ───────────────
    # Applies: joke purge, FactSet→yfinance/SEC, EFP→ERP, TCM→Average WACC,
    # Damodaran hyperlink, orange divider bands, WACC sanity gate, and the
    # five 'Fixed:' audit comments. Idempotent — safe on fresh or dirty templates.
    try:
        import required_return
        print("\n[5/6] Applying Required Return polish ...")
        required_return.apply(workbook_path)
    except ImportError:
        print("\n  ⚠  required_return.py not found — Required Return polish SKIPPED.")
        print("     Keep this module next to dcf_refresh.py for durable MD-desk cleanup.")
    except Exception as e:
        print(f"\n  ⚠  Required Return polish raised: {e}")
        print("     Continuing — other tabs are unaffected.")

    # ── Cash Flow Forecast driver rebuild (B1) ────────────────────────────────
    # Ties CFF!B60:F60 (CapEx%) and B62:F62 (NWC%) to H31/H33 historical
    # averages × CONFIG factors, so the forecast automatically follows the
    # target's reinvestment profile when we repoint tickers.
    try:
        import cff_forecast
        print("\n[6/7] Rebuilding Cash Flow Forecast drivers ...")
        cff_forecast.apply(workbook_path)
    except ImportError:
        print("\n  ⚠  cff_forecast.py not found — CFF driver rebuild SKIPPED.")
        print("     Forecast ratios B60:F60 / B62:F62 will stay at shipped defaults.")
    except Exception as e:
        print(f"\n  ⚠  cff_forecast raised: {e}")
        print("     Continuing — other tabs are unaffected.")

    # ── Fallback chain — Audit #4 ──────────────────────────────────────────────
    # Replace every IFERROR magic-number fallback with a 3-tier hierarchy:
    # company history → peer industry avg → CONFIG analyst → visible "N/A".
    # Eliminates the silent textbook-default failure mode that previously
    # masked broken upstream data with plausible-looking but wrong ratios.
    try:
        import fallback_chain
        print("\n[7/8] Wiring fallback chain (Audit #4) ...")
        fallback_chain.apply(workbook_path)
    except ImportError:
        print("\n  ⚠  fallback_chain.py not found — magic-number fallbacks STILL ACTIVE.")
        print("     CFF!H28-H33 will resolve to textbook defaults if historicals fail.")
    except Exception as e:
        print(f"\n  ⚠  fallback_chain raised: {e}")
        print("     Continuing — magic-number fallbacks may still be active.")

    # ── Workbook-wide polish — Audit #7 ────────────────────────────────────────
    # Cross-tab text cleanup (TCM purge, FactSet → yfinance/SEC, EFP → ERP,
    # joke removal applied to ALL tabs not just Required Return), plus
    # formatting consistency on the new Audit-#4/#6 Industry block.
    try:
        import workbook_polish
        print("\n[8/9] Workbook polish — text purge + formatting (Audit #7) ...")
        workbook_polish.apply(workbook_path)
    except ImportError:
        print("\n  ⚠  workbook_polish.py not found — TCM/FactSet/EFP residue may remain.")
    except Exception as e:
        print(f"\n  ⚠  workbook_polish raised: {e}")
        print("     Continuing — model is functional, only cosmetic polish skipped.")

    # ── Reverse DCF Decomposition tab — Audit #9 ───────────────────────────────
    # Builds the "Reverse DCF" tab that decomposes market enterprise value into
    # PV(explicit forecast) + PV(reasonable terminal) + residual ("perpetual
    # growth premium"). Reverse-solves for the implied perpetual growth the
    # market price requires. Powerful one-page argument for UNDERWEIGHT theses
    # at any cycle peak — quantifies "the market is pricing impossible growth".
    # Ticker-agnostic; lives next to your other tabs after each repoint.
    try:
        import reverse_dcf
        print("\n[9/9] Building Reverse DCF Decomposition tab (Audit #9) ...")
        reverse_dcf.apply(workbook_path)
    except ImportError:
        print("\n  ⚠  reverse_dcf.py not found — Reverse DCF tab will not be built.")
    except Exception as e:
        print(f"\n  ⚠  reverse_dcf raised: {e}")
        print("     Continuing — model is functional, only Reverse DCF tab skipped.")

    print("\n" + "=" * width)
    print(f"  ✅  COMPLETE  |  {os.path.basename(workbook_path)} saved")
    print(f"\n  Next steps:")
    print(f"  1. Open {os.path.basename(workbook_path)}")
    print(f"  2. Go to 'Cash Flow Forecast' tab")
    print(f"  3. Set your growth assumptions (blue input cells)")
    print(f"  4. Check 'Valuation Summary' for your final output")
    if not treasury:
        print(f"\n  ⚠  Manual: Enter 10-yr Treasury yield in Instructions!U77")
    if not erp:
        print(f"  ⚠  Manual: Enter Damodaran ERP in Instructions!U89")
    print("=" * width + "\n")


# ─── xlwings entry point (Excel macro button — Windows only) ──────────────────

def refresh_from_excel():
    try:
        wb_xw   = xw.Book.caller()
        wb_path = wb_xw.fullname
        inst    = wb_xw.sheets["Instructions"]
        ticker  = str(inst.range("B3").value or "").strip().upper()
        peers_str = str(inst.range("B4").value or "").strip()

        if not ticker:
            import tkinter as tk
            from tkinter import simpledialog
            root = tk.Tk(); root.withdraw()
            ticker = simpledialog.askstring("DCF Refresh", "Enter ticker (e.g. MU):", parent=root)
            root.destroy()
            if not ticker: return
            inst.range("B3").value = ticker.upper()

        peers = [p.strip().upper() for p in peers_str.split(",") if p.strip()] if peers_str else []
        refresh_data(ticker, peers, wb_path)

        import ctypes
        ctypes.windll.user32.MessageBoxW(
            0,
            f"✅ Data refreshed for {ticker}!\n\nOpen 'Cash Flow Forecast' to run the model.",
            "DCF Refresh Complete", 0x40
        )
    except Exception as e:
        import traceback; traceback.print_exc()
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(0, f"Error: {e}", "Refresh Error", 0x10)
        except Exception:
            pass


# ─── Jupyter / CLI entry point ─────────────────────────────────────────────────

def run():
    """Called from the Jupyter notebook: dcf_refresh.run()"""
    refresh_data(TARGET_TICKER, PEER_TICKERS)


if __name__ == "__main__":
    if len(sys.argv) >= 2:
        tkr   = sys.argv[1]
        peers = sys.argv[2].split(",") if len(sys.argv) >= 3 else []
        path  = sys.argv[3] if len(sys.argv) >= 4 else None
        refresh_data(tkr, peers, path)
    else:
        run()
