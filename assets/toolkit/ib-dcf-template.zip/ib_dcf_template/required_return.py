"""
required_return.py — v1 — Backport of the v7 Required Return cleanup.

Reproduces the Session 1-2 manual polish of the Required Return tab in Python
so a fresh data refresh can't revert the MD-desk cleanup. Idempotent — safe to
run repeatedly on the same or different workbooks.

WHAT IT DOES (from Session 3 handoff §1.2)
------------------------------------------
  1. Deletes the "me gusta la stocka" joke (cell E8 comment / any cell text).
  2. Rewrites all "Target Cost of Money" / stray "TCM" labels to
     "Average WACC" / "Conservative" / "Aggressive".
  3. Fixes the EFP → ERP typo on D24 and anywhere else it appears.
  4. Rewrites "FactSet" → "yfinance/SEC" everywhere it appears.
  5. Turns A25 from a plain Damodaran URL string into a clickable hyperlink
     (navy italic font, underline, proper hyperlink target).
  6. Strips stray green framing fills on Row 8 (keeps the yellow input cell).
  7. Shrinks Rows 36 and 65 to 6pt orange divider bands (theme 5 tint ~0.4).
  8. Adds Row 63 — the NEW WACC sanity gate (PASS/FAIL vs. 4% terminal growth
     floor). Green for PASS, red for FAIL (via conditional formula styling).
  9. Attaches the five "Fixed:" audit comments on C8/C21/C41/C42/C44 so any
     future auditor knows what was corrected and why.

WHAT IT DELIBERATELY DOES NOT DO
--------------------------------
  * It does NOT rebuild the formula logic on Required Return — the formulas
    living in the template are correct as of v7 (Ke = Rf + β·ERP, total debt
    = ST+LT, 23% statutory tax rate, etc.). This module is a polish layer,
    not a formula rewrite. Formula logic changes belong in a separate,
    explicit migration.
  * It does NOT mutate inputs that depend on the company. Tax rate (C44)
    stays at 23% regardless of ticker because every portable config so far
    uses the same US marginal assumption. If a non-US target is added, the
    config can override it.

USAGE
-----
From the notebook (Cell 8b — after CFF / FactSet fixes):

    import required_return, importlib
    importlib.reload(required_return)
    required_return.apply()                  # auto-detect the .xlsm
    # or
    required_return.apply("DCF_Final.xlsm")

From dcf_refresh.run():

    import required_return
    required_return.apply(workbook_path)     # called at end of refresh_data

Returns the absolute path of the workbook that was written.
"""
from __future__ import annotations

import os
import re
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.comments import Comment
from openpyxl.formatting.rule import FormulaRule

try:
    from dcf_config import CONFIG as _CFG
except Exception:
    _CFG = None


AUTHOR = "MD Review"


# ─── Style constants (matches the v7 .xlsm inspection) ─────────────────
BLACK       = Font(name="Calibri", color="000000", size=11)
BLACK_BOLD  = Font(name="Calibri", color="000000", size=11, bold=True)
BLACK_ITAL  = Font(name="Calibri", color="000000", size=11, italic=True)
BLUE        = Font(name="Calibri", color="0000FF", size=11)
BLUE_ITAL   = Font(name="Calibri", color="0000FF", size=11, italic=True)
GREY_ITAL   = Font(name="Calibri", color="595959", size=10, italic=True)
GREEN_PASS  = Font(name="Calibri", color="548235", size=11, bold=True, italic=True)
RED_FAIL    = Font(name="Calibri", color="C00000", size=11, bold=True, italic=True)
HL_FONT     = Font(name="Calibri", color="0563C1", size=11, italic=True, underline="single")

YELLOW      = PatternFill("solid", start_color="FFFFFF00")   # canonical input fill
ORANGE_BAND = PatternFill("solid", start_color="FFF4B183")   # theme-5 tint ~0.4 approximation
NO_FILL     = PatternFill(fill_type=None)


# ─── v7 audit comments ─────────────────────────────────────────────────
AUDIT_COMMENTS = {
    "C8":  "Formula-pull: ST Debt & current portion of LT Debt from BS!A22. "
           "Returns 0 when yfinance doesn't populate the line (common on "
           "fiscal-year pulls where ST debt was fully refinanced into LT). "
           "Previously a manual yellow-input cell — modernized to formula-driven.",
    "C9":  "Formula-pull: Long-Term Debt (incl. Leases) from BS — falls back to "
           "bare 'Long-Term Debt' if the leases-inclusive row is missing. "
           "Fixed Apr-2026: prior label 'Long-Term Debt excl Lease Obligations' "
           "didn't match what yfinance writes, so C9 silently returned 0.",
    "C21": "Fixed: Damodaran ERP 4.5% (Apr 2026). Was 2.0% which understated cost of equity.",
    "C41": "Fixed: Ke = Rf + beta*ERP (direct CAPM using Damodaran ERP).",
    "C42": "Fixed: Total Debt = ST + LT (was only LT). Increases weight of debt.",
    "C44": "Fixed: 23% marginal statutory rate (US 21% + state blend). "
           "Was 11.64% effective (CHIPS-credit contaminated).",
}


# ─── Text substitutions (applied globally) ─────────────────────────────
# Order matters — EFP before ERP, etc.
TEXT_SUBS = [
    ("FactSet",              "yfinance/SEC"),
    ("EFP",                  "ERP"),
    ("Target Cost of Money", "Average WACC"),
    # Stray "TCM" as a whole word — never inside another identifier
    (re.compile(r"\bTCM\b"), "WACC"),
]

# Text patterns to delete outright (empty the cell, keep style)
TEXT_DELETIONS = [
    re.compile(r"me gusta la stocka", re.I),
]


# ═══════════════════════════════════════════════════════════════════════
#  Helpers
# ═══════════════════════════════════════════════════════════════════════
def _auto_detect_workbook() -> str:
    """Most-recent .xlsm/.xlsx in the caller's CWD."""
    cwd = os.path.abspath("")
    cands = sorted(
        [f for f in os.listdir(cwd) if f.endswith((".xlsm", ".xlsx"))],
        key=lambda f: os.path.getmtime(os.path.join(cwd, f)),
        reverse=True,
    )
    if not cands:
        raise FileNotFoundError(f"No .xlsm/.xlsx in {cwd}")
    return os.path.join(cwd, cands[0])


def _apply_text_subs(value: str) -> str:
    """Apply every TEXT_SUBS rule to a string; return possibly-empty result."""
    out = value
    # Check deletions first — if any match, return "" to blank the cell
    for pat in TEXT_DELETIONS:
        if pat.search(out):
            return ""
    for rule, replacement in TEXT_SUBS:
        if isinstance(rule, re.Pattern):
            out = rule.sub(replacement, out)
        else:
            out = out.replace(rule, replacement)
    return out


# ═══════════════════════════════════════════════════════════════════════
#  Polish passes
# ═══════════════════════════════════════════════════════════════════════
def _pass_text_subs(ws) -> int:
    """Pass over every cell value AND every comment, applying TEXT_SUBS."""
    n = 0
    for row in ws.iter_rows():
        for cell in row:
            # Value
            v = cell.value
            if isinstance(v, str) and not v.startswith("="):
                new = _apply_text_subs(v)
                if new != v:
                    cell.value = new if new else None
                    n += 1
            # Comment
            if cell.comment and cell.comment.text:
                new_cmt = _apply_text_subs(cell.comment.text)
                if new_cmt != cell.comment.text:
                    cell.comment = (
                        Comment(new_cmt, cell.comment.author or AUTHOR) if new_cmt else None
                    )
                    n += 1
    return n


def _pass_hyperlink_row25(ws) -> None:
    """A25 — clickable Damodaran ERP database link."""
    ws["A25"].value = "Source: Damodaran ERP database"
    ws["A25"].hyperlink = (
        "http://pages.stern.nyu.edu/~adamodar/New_Home_Page/datafile/implprem.html"
    )
    ws["A25"].font = HL_FONT


def _pass_row51_headers(ws) -> None:
    """Row 51 column headers — Average / Conservative / Aggressive."""
    ws["C51"].value = "Average WACC"
    ws["C51"].font = BLACK_ITAL
    ws["D51"].value = "Conservative"
    ws["D51"].font = BLACK_ITAL
    ws["E51"].value = "Aggressive"
    ws["E51"].font = BLACK_ITAL


def _pass_row39_headers(ws) -> None:
    """Row 39 — OUTPUTS block with Internal / yfinance-SEC / Cross-check columns."""
    ws["A39"].value = "OUTPUTS"
    ws["A39"].font = BLACK_BOLD
    ws["C39"].value = "Conservative Outputs"
    ws["C39"].font = BLACK_ITAL
    ws["D39"].value = "Aggressive Outputs"
    ws["D39"].font = BLACK_ITAL
    ws["G39"].value = "Internal"
    ws["G39"].font = BLACK_ITAL
    ws["H39"].value = "yfinance/SEC"
    ws["H39"].font = BLACK_ITAL
    ws["I39"].value = "Cross-check"
    ws["I39"].font = BLACK_ITAL


def _pass_row8_clean(ws) -> None:
    """Strip non-canonical fills from row 8. C8 is now a formula-pull
    (not a manual input) — paint it to match the sibling pull cells C9/C10
    so the 'yellow = user input' convention stays consistent.

    Fixed Apr-2026 (round 1): previously C8 was forced to YELLOW every run,
    misleading users into thinking the $0 was a hand-entered placeholder.

    Fixed Apr-2026 (round 2): the original cleanup loop kept yellow fills
    everywhere on row 8 (yellow was in the exclusion list) — that left a
    stray yellow patch on B8 (between the label in A8 and the value in C8).
    Now we strip yellow from the whole row except where the new convention
    explicitly belongs (nowhere on row 8 — C8 is a formula cell).
    """
    # Copy the fill from C9 (a known-good formula-pull cell) onto C8 so the
    # visual convention matches the behaviour. If C9 has no fill for some
    # reason, fall back to NO_FILL rather than asserting a specific theme.
    sibling_fill = ws["C9"].fill
    for col in range(1, 11):
        cell = ws.cell(8, col)
        if cell.coordinate == "C8":
            cell.fill = PatternFill(
                fill_type=sibling_fill.patternType,
                start_color=sibling_fill.start_color,
                end_color=sibling_fill.end_color,
            ) if sibling_fill and sibling_fill.patternType else NO_FILL
            continue
        # Clear any stray solid fill — including stale yellow on B8 (the
        # cell between the label and the value). Yellow is no longer a
        # "preserve me" color anywhere on row 8.
        if cell.fill and cell.fill.patternType == "solid":
            rgb = getattr(cell.fill.fgColor, "rgb", None)
            if str(rgb).upper() not in ("00000000", "FF000000", ""):
                cell.fill = NO_FILL


def _pass_orange_bands(ws, rows=(36, 65)) -> None:
    """Rows 36 and 65 — 6pt orange divider bands (theme 5 tint ~0.4)."""
    for r in rows:
        ws.row_dimensions[r].height = 6.0
        for col in range(1, 11):
            ws.cell(r, col).fill = ORANGE_BAND


def _pass_sanity_gate(ws, gate_floor: float = 0.04) -> None:
    """Row 63 — NEW WACC sanity gate (PASS/FAIL vs. terminal growth floor)."""
    ws["A63"].value = "WACC sanity gate (must exceed terminal growth)"
    ws["A63"].font = GREY_ITAL
    ws["C63"].value = (
        f'=IF(C52>{gate_floor:.4g},'
        f'"PASS  (WACC > {gate_floor*100:.0f}% terminal growth)",'
        f'"FAIL  (WACC below terminal growth — model will not converge)")'
    )
    # Default style is PASS-green; a conditional formatting rule flips it to
    # red when the formula evaluates to FAIL.
    ws["C63"].font = GREEN_PASS

    # Conditional-format: if the cell text starts with "FAIL", render red.
    # Using a simple FormulaRule so it survives any Excel/LibreOffice recalc.
    rule = FormulaRule(
        formula=['LEFT($C$63,4)="FAIL"'],
        font=RED_FAIL,
        stopIfTrue=False,
    )
    # Apply only to C63 — avoid collateral damage to other cells.
    ws.conditional_formatting.add("C63", rule)


def _pass_audit_comments(ws) -> None:
    """Attach the v7 'Fixed:' audit comments (idempotent — always overwrites)."""
    for ref, text in AUDIT_COMMENTS.items():
        ws[ref].comment = Comment(text, AUTHOR)


def _pass_yellow_inputs(ws) -> None:
    """Canonical YELLOW input cells — genuinely manual, user-entered values.

    Fixed Apr-2026: removed C8 from this list. C8 is formula-driven
    (VLOOKUP on BS!A:B for 'ST Debt & Curr. Portion LT Debt'), so painting
    it yellow misrepresented it as a manual input. The yellow convention is
    now reserved for values that have no upstream data source and really do
    require the user to type a number (Damodaran ERP, statutory tax rate).
    """
    for ref in ("C21", "C44"):
        ws[ref].fill = YELLOW


def _pass_debt_pull_fix(ws) -> None:
    """Rewrite RR!C9 (Long-Term Debt pull) to match the labels yfinance
    actually writes to the BS tab.

    Background (Apr-2026 bug fix):
    The legacy template formula looked for the label
       "Long-Term Debt excl Lease Obligations"
    in BS!A:B. But dcf_refresh (yfinance) emits the LT-debt row as either
       "Long-Term Debt (incl. Leases)"    (preferred — post-ASC-842 / IFRS-16)
    or, for some ticker/vintage combinations, just
       "Long-Term Debt"                   (conservative — excl. leases)
    The phantom 'excl Lease Obligations' row is never written by any
    modern pipeline, so the VLOOKUP returned #N/A, the outer IFERROR
    caught it, and C9 silently resolved to 0. Downstream: Total Debt in
    WACC understated by the full LT-debt amount, weight-of-debt near 0,
    net debt in VE!B16 reported as pure cash.

    Fix: rewrite C9 with a fallback chain that prefers the
    leases-inclusive label (more defensible for modern WACC capital
    structure) and falls back to the bare label, then 0.

    Preserves the Instructions!U49 'millions/thousands' unit toggle from
    the original formula so this stays portable across reporting units.
    """
    c9_formula = (
        '=IFERROR(IF(Instructions!U49="millions",'
        'IFERROR(VLOOKUP("Long-Term Debt (incl. Leases)",BS!A:B,2,FALSE()),'
        'VLOOKUP("Long-Term Debt",BS!A:B,2,FALSE())),'
        'IFERROR(VLOOKUP("Long-Term Debt (incl. Leases)",BS!A:B,2,FALSE()),'
        'VLOOKUP("Long-Term Debt",BS!A:B,2,FALSE()))*1000),0)'
    )
    ws["C9"].value = c9_formula
    # Preserve the existing number format on C9; don't reset it.


def _pass_k69_dividend_growth(ws) -> None:
    """Rebuild K69 (sustainable growth rate = ROE × retention) to use the
    decimal ROE and Payout Ratio values that dcf_refresh writes to Key Items.

    Legacy formula divided by /100 assuming whole-number percentages AND
    looked for "Payout Ratio" in IS — neither holds after the refresh
    pipeline was modernized. New formula uses decimals from Key Items.
    """
    ws["K69"].value = (
        '=IFERROR(VLOOKUP("Return on Equity",\'Key Items\'!A:K,2,FALSE())'
        '*(1-VLOOKUP("Payout Ratio",\'Key Items\'!A:K,2,FALSE())),0)'
    )
    ws["K69"].number_format = '0.0%;(0.0%);"-"'


# ═══════════════════════════════════════════════════════════════════════
#  Public entry point
# ═══════════════════════════════════════════════════════════════════════
def apply(workbook_path: str | None = None, config=None) -> str:
    """
    Apply the v7 Required Return polish to a workbook. Idempotent.

    Parameters
    ----------
    workbook_path : str, optional
        Path to the .xlsm / .xlsx. Auto-detects the most recent one in CWD.
    config : DCFConfig, optional
        Company config. Reads CONFIG.terminal_growth for the sanity gate
        threshold reference (the actual gate floor is fixed at 4% per
        Session 3 handoff §1.2).

    Returns
    -------
    str : absolute path of the workbook that was written.
    """
    if workbook_path is None:
        workbook_path = _auto_detect_workbook()
    elif not os.path.isabs(workbook_path):
        workbook_path = os.path.join(os.path.abspath(""), workbook_path)

    if config is None:
        config = _CFG

    # Handoff §1.2: sanity gate uses a hard 4% floor, independent of
    # CONFIG.terminal_growth. Rationale: terminal growth can be 2-3% in most
    # models, but WACC must still clear a 4% floor to produce a sensible
    # Gordon perpetuity — if WACC < 4%, something upstream is wrong.
    gate_floor = 0.04

    wb = load_workbook(workbook_path, keep_vba=True)
    if "Required Return" not in wb.sheetnames:
        raise KeyError(
            f"Workbook missing 'Required Return' sheet: {workbook_path}"
        )
    ws = wb["Required Return"]

    # Polish pipeline — order matters (deletions first, then re-adds)
    n_subs = _pass_text_subs(ws)
    _pass_debt_pull_fix(ws)     # MUST run before _pass_row8_clean so C9 fill
                                # is the canonical formula-pull fill that C8
                                # will copy from.
    _pass_row8_clean(ws)
    _pass_row39_headers(ws)
    _pass_row51_headers(ws)
    _pass_hyperlink_row25(ws)
    _pass_sanity_gate(ws, gate_floor=gate_floor)
    _pass_audit_comments(ws)
    _pass_yellow_inputs(ws)
    _pass_orange_bands(ws, rows=(36, 65))
    _pass_k69_dividend_growth(ws)

    wb.save(workbook_path)

    ticker = getattr(config, "ticker", "?") if config else "?"
    print(f"  ✓  Required Return polished ({ticker}): {os.path.basename(workbook_path)}")
    print(f"     • {n_subs} text substitution(s) applied "
          f"(FactSet→yfinance/SEC, EFP→ERP, TCM→WACC, joke deleted)")
    print(f"     • Row 25: Damodaran ERP hyperlink attached")
    print(f"     • Row 39: OUTPUTS headers set (Conservative/Aggressive/Internal/yfinance-SEC/Cross-check)")
    print(f"     • Row 51: Average WACC / Conservative / Aggressive column headers")
    print(f"     • Row 63: WACC sanity gate (PASS/FAIL vs. {gate_floor*100:.0f}% floor) + conditional red/green")
    print(f"     • Rows 36/65: 6pt orange divider bands")
    print(f"     • C9 LT-debt formula rewired (leases-inclusive → plain LT Debt fallback)")
    print(f"     • C8 fill normalized (was yellow 'input', now matches formula-pull cells)")
    print(f"     • Canonical yellow inputs: C21 / C44 (Damodaran ERP, tax rate)")
    print(f"     • {len(AUDIT_COMMENTS)} audit comments attached "
          f"(C8/C9/C21/C41/C42/C44)")
    return workbook_path


if __name__ == "__main__":
    apply()
