"""
fallback_chain.py — Audit #4 — eliminate silent magic-number fallbacks.

WHY THIS EXISTS
───────────────
The original .xlsm template had IFERROR fallbacks throughout that silently
papered over missing data with hardcoded numeric constants:

    Cash Flow Forecast!H28  =IFERROR(<EBIT margin avg>,    0.15)
    Cash Flow Forecast!H29  =IFERROR(<Interest/Sales avg>, 0.01)
    Cash Flow Forecast!H30  =IFERROR(<Tax rate avg>,       0.21)
    Cash Flow Forecast!H31  =IFERROR(<CapEx/Sales avg>,    0.30)
    Cash Flow Forecast!H32  =IFERROR(<D&A/Sales avg>,      0.22)
    Cash Flow Forecast!H33  =IFERROR(<NWC/Sales avg>,      0.40)
    Cash Flow Forecast!H26  =IFERROR(<Revenue growth avg>, 0.05)
    Industry!B5..B10        =IFERROR('Peer Comparison'!H##,  <magic 5/15/20/0.4>)

When upstream data has any kind of glitch — e.g. a corrupted IS!A2 row label
that broke the Sales VLOOKUP and cascaded through the historical-ratio chain
— these IFERRORs would fire silently. The user would see plausible-looking
ratios in column H without realizing they were textbook averages, not the
target company's actuals. Downstream, FCF would be wildly off and the DCF
fair value would land somewhere indefensible — but with no warning.

THE FIX (this module)
─────────────────────
Replace every magic-number fallback with a 3-tier hierarchy:

    Tier 1: Company historical avg (B##:G## SUMPRODUCT/COUNT)
    Tier 2: Peer industry avg      (Industry!D14:D20, computed by
                                    dcf_refresh._fetch_peer_industry_ratios
                                    from each peer's full statements)
    Tier 3: CONFIG analyst value   (analyst_*_to_sales fields, surfaced via
                                    Industry!C14:C20)
    Tier 4: Excel "N/A" string     (visible failure — Cell 8 verification
                                    will warn loudly if a Tier-4 fires)

USAGE
─────
Called from the notebook pipeline AFTER dcf_refresh.refresh_data() (which
populates Industry!B14:D20) and BEFORE ib_fixes / cff_forecast:

    import fallback_chain
    fallback_chain.apply(workbook_path)

Idempotent — safe to re-run on the same workbook.
"""
from __future__ import annotations
import os
from openpyxl import load_workbook


# Each entry maps a CFF!H## fallback cell to its Industry!D## fallback row.
# The historical-avg formula on the LHS is preserved; only the IFERROR
# fallback (RHS of the ',') is rewritten.
CFF_FALLBACKS = [
    # (CFF cell, historical SUMPRODUCT range, Industry row)
    ("H28", "B28:G28", 19, "EBIT margin"),
    ("H29", "B29:G29", 18, "Interest / Sales"),
    ("H30", "B30:G30", 17, "Effective Tax"),
    ("H31", "B31:G31", 14, "CapEx / Sales"),
    ("H32", "B32:G32", 15, "D&A / Sales"),
    ("H33", "B33:G33", 16, "NWC / Sales"),
    ("H26", "B26:G26", 20, "Revenue growth"),
]

# Industry tab rows that previously had magic-number fallbacks (5,15,20,0.4...)
INDUSTRY_TOP_FIXES = [
    # (cell, peer_comp_ref, fallback_industry_ref)
    # Row 5 — Revenue Growth — was *100 fallback to 5
    ("B5",  "'Peer Comparison'!H15*100",  "D20"),    # Industry!D20 already has hierarchy
    ("C5",  "'Peer Comparison'!H15*100",  "D20"),
    ("D5",  "'Peer Comparison'!H15*100",  "D20"),
    ("E5",  "'Peer Comparison'!H15*100",  "D20"),
    ("F5",  "'Peer Comparison'!H15*100",  "D20"),
    # Row 6 — EBIT Margin — was fallback to 0.15
    ("B6",  "'Peer Comparison'!H18",      "D19"),    # Industry!D19 = EBIT/Sales hierarchy
    ("C6",  "'Peer Comparison'!H18",      "D19"),
    ("D6",  "'Peer Comparison'!H18",      "D19"),
    ("E6",  "'Peer Comparison'!H18",      "D19"),
    ("F6",  "'Peer Comparison'!H18",      "D19"),
    # Row 7 — Gross Margin — was fallback to 0.4 (no CFF dependency, but
    # still a magic number; route to a clear "N/A" since we don't have a
    # CONFIG analyst tier for gross margin specifically)
    ("B7",  "'Peer Comparison'!H17",      None),
    ("C7",  "'Peer Comparison'!H17",      None),
    ("D7",  "'Peer Comparison'!H17",      None),
    ("E7",  "'Peer Comparison'!H17",      None),
    ("F7",  "'Peer Comparison'!H17",      None),
    # Row 9 — P/E (NTM) — was fallback to 20
    ("B9",  "'Peer Comparison'!H10",      None),
    ("C9",  "'Peer Comparison'!H10",      None),
    ("D9",  "'Peer Comparison'!H10",      None),
    ("E9",  "'Peer Comparison'!H10",      None),
    ("F9",  "'Peer Comparison'!H10",      None),
    # Row 10 — EV/EBITDA — was fallback to 15
    ("B10", "'Peer Comparison'!H11",      None),
    ("C10", "'Peer Comparison'!H11",      None),
    ("D10", "'Peer Comparison'!H11",      None),
    ("E10", "'Peer Comparison'!H11",      None),
    ("F10", "'Peer Comparison'!H11",      None),
    # Row 8 — Return on Equity — was fallback to 0.15 (no DCF dependency,
    # but still magic; route to N/A so the failure is visible)
    ("B8",  "'Peer Comparison'!H20",      None),
    ("C8",  "'Peer Comparison'!H20",      None),
    ("D8",  "'Peer Comparison'!H20",      None),
    ("E8",  "'Peer Comparison'!H20",      None),
    ("F8",  "'Peer Comparison'!H20",      None),
]


# CFF!J29 — average effective cost of debt = |interest| / (ST debt + LT debt)
# Original formula fell back to 0.045 (4.5%) when interest or debt was zero.
# Audit #4: rewire to the BS-derived weighted-avg-cost-of-debt that lives on
# Required Return!RD column (~row 43, "Cost of Debt"), with ultimate "N/A".
J29_REWIRE = (
    '=IFERROR('
    'ABS(SUMPRODUCT(IF(B10:F10="",0,B10:F10)))/'
    '(SUMPRODUCT(IF(B18:F18="",0,B18:F18))+SUMPRODUCT(IF(B19:F19="",0,B19:F19))),'
    'IFERROR(\'Required Return\'!C43,"N/A"))'
)


def _build_cff_formula(hist_range: str, industry_row: int) -> str:
    """3-tier formula for a CFF!H## ratio cell.

    Tier 1: company historical SUMPRODUCT/COUNT average
    Tier 2: Industry!D{row} (peer→config hierarchy already encoded there)
    Tier 4: "N/A" if Tier 2 also resolves to a string

    The formula structure:
      =IFERROR(
         <company avg>,                       (Tier 1)
         IF(ISNUMBER(Industry!D{row}),
            Industry!D{row},                  (Tiers 2/3)
            "N/A"))                           (Tier 4)
    """
    company_avg = (
        f'SUMPRODUCT(IF({hist_range}="",0,{hist_range}))/'
        f'SUMPRODUCT(IF({hist_range}="",0,1))'
    )
    return (
        f'=IFERROR({company_avg},'
        f'IF(ISNUMBER(Industry!D{industry_row}),'
        f'Industry!D{industry_row},"N/A"))'
    )


def _build_industry_formula(peer_ref: str, fallback_ref: str | None) -> str:
    """Industry tab cell formula: peer comparison value, falling through to
    either an Industry!D## cell (which has its own peer→config hierarchy) or
    a visible "N/A" string.
    """
    if fallback_ref is None:
        return f'=IFERROR({peer_ref},"N/A")'
    # When the peer ref is a percentage in the source (Revenue Growth row in
    # Peer Comparison is a fraction like 0.732, but Industry row 5 was
    # multiplying ×100). Don't double-multiply on the fallback path.
    inner_fallback = (
        f'IF(ISNUMBER(Industry!{fallback_ref}),'
        f'Industry!{fallback_ref}*100 ,"N/A")'
        if "*100" in peer_ref
        else f'IF(ISNUMBER(Industry!{fallback_ref}),'
             f'Industry!{fallback_ref},"N/A")'
    )
    return f'=IFERROR({peer_ref},{inner_fallback})'


def apply(workbook_path: str) -> dict:
    """Rewrite all magic-number IFERROR fallbacks. Returns a dict of
    {cell: new_formula} for logging.
    """
    if not os.path.exists(workbook_path):
        raise FileNotFoundError(workbook_path)

    wb = load_workbook(workbook_path, keep_vba=True)
    cff = wb["Cash Flow Forecast"]
    ind = wb["Industry"]

    written = {}

    # 1) CFF!H## fallbacks
    for cff_cell, hist_range, ind_row, _label in CFF_FALLBACKS:
        new = _build_cff_formula(hist_range, ind_row)
        cff[cff_cell].value = new
        written[f"Cash Flow Forecast!{cff_cell}"] = new

    # 2) Industry tab top-section fallbacks (rows 5-10)
    for cell, peer_ref, fb_ref in INDUSTRY_TOP_FIXES:
        new = _build_industry_formula(peer_ref, fb_ref)
        ind[cell].value = new
        written[f"Industry!{cell}"] = new

    # 3) ib_fixes propagation: G27 = "=IFERROR(Industry!B5,0.05)"
    #    Industry!B5 itself now has the chain, so just remove the magic
    #    fallback and let the chain handle it.
    cff["G27"].value = '=IFERROR(Industry!B5,"N/A")'
    written["Cash Flow Forecast!G27"] = cff["G27"].value

    # 4) CFF!J29 — average cost of debt (was IFERROR …,0.045)
    cff["J29"].value = J29_REWIRE
    written["Cash Flow Forecast!J29"] = J29_REWIRE

    wb.save(workbook_path)

    print(f"  ✓  Fallback chain applied: {len(written)} cells rewritten")
    print(f"     • CFF!H28-H33 + H26 → 3-tier (company → peer → CONFIG → 'N/A')")
    print(f"     • Industry!B5:F5, B6:F6, B7:F7, B9:F9, B10:F10 → peer + N/A")
    print(f"     • CFF!G27 → Industry!B5 chain (was hardcoded 0.05)")

    return written


if __name__ == "__main__":
    import sys
    apply(sys.argv[1] if len(sys.argv) > 1 else "DCF_Final.xlsm")
