"""
ib_fixes.py — Applies the IB-ready polish layer on top of the
core DCF workbook produced by Cells 3-11 of DCF_Notebook.ipynb.

What it does:
  Phase 6 fixes:
    1. Anchors FY26-FY30 revenue growth (CFF!B39:F39) to street consensus
       (28% → 15% → 7% → 4% → 3%) — overrides any stale analyst fork.
    2. Adds a cycle-bias note to the historical average cell (CFF!H26).
    3. Replaces CFF!B56 NTM EPS with forecast-consistent
       Net Income / Diluted Shares (post-SBC).
    4. Recalibrates the Segment Revenue tab growth rates (DRAM/NAND/HBM)
       so the bottoms-up total reconciles to top-down within <$1B.
    5. Sets Stage-1 end growth (VE!B69) to 5.0% mid-cycle.
    6. Builds the Driver Sensitivity (tornado) tab.
    7. Builds the Revenue Bridge (top-down vs bottoms-up vs consensus) tab.

  Phase 7 fixes:
    8. Relabels VE row 14 (Pessimistic / Base Case / Optimistic DCF).
    9. Builds the Cover / Executive Summary tab as the first worksheet —
       recommendation header, 9-method valuation table, 13-driver
       assumptions table, 8-bullet thesis, footer.

Usage (inside the notebook — Cell 12):

    import importlib, ib_fixes
    importlib.reload(ib_fixes)
    ib_fixes.apply()            # auto-detects DCF_Final.xlsm
    # or
    ib_fixes.apply("DCF_Final.xlsm")

The function is idempotent — safe to run repeatedly. Every cell it
overwrites is flagged with a blue/bold font or a yellow fill and a
cell comment explaining the override for future auditors.

All paths are resolved dynamically via os.path.abspath('') — no
hardcoded directories.
"""
from __future__ import annotations

import os
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.comments import Comment

# Template config — company-specific inputs live in dcf_config.CONFIG.
# Falls back to MU defaults if the module isn't importable.
try:
    from dcf_config import CONFIG as _DEFAULT_CONFIG
except Exception:
    _DEFAULT_CONFIG = None

# ─── Style constants ──────────────────────────────────────────────────
BLUE = Font(name="Calibri", color="0000FF")
BLACK = Font(name="Calibri", color="000000")
GREEN = Font(name="Calibri", color="008000")
WHITE = Font(name="Calibri", color="FFFFFF", bold=True)
RED = Font(name="Calibri", color="C00000", bold=True)
GREY = Font(name="Calibri", color="595959", italic=True)
BOLD_BLUE = Font(name="Calibri", color="0000FF", bold=True)

YELLOW = PatternFill("solid", start_color="FFFF00")
LBLUE = PatternFill("solid", start_color="DDEBF7")
DARK_BLUE = PatternFill("solid", start_color="1F3864")
GREEN_FILL = PatternFill("solid", start_color="E2EFDA")
HDR_FILL = PatternFill("solid", start_color="1F3864")
HDR_FONT = Font(name="Calibri", color="FFFFFF", bold=True)

thin = Side(style="thin", color="BFBFBF")
thick = Side(style="medium", color="1F3864")
BORDER = Border(top=thin, bottom=thin, left=thin, right=thin)
BORDER_THICK = Border(top=thick, bottom=thick, left=thick, right=thick)

AUTHOR = "MD Review"


# ─── Helpers ──────────────────────────────────────────────────────────
def _auto_detect_workbook() -> str:
    """Find the most recently modified .xlsm/.xlsx in the caller's cwd."""
    cwd = os.path.abspath("")
    candidates = sorted(
        [f for f in os.listdir(cwd) if f.endswith((".xlsm", ".xlsx"))],
        key=lambda f: os.path.getmtime(os.path.join(cwd, f)),
        reverse=True,
    )
    if not candidates:
        raise FileNotFoundError(f"No .xlsm/.xlsx in {cwd}")
    return os.path.join(cwd, candidates[0])


# ─── Phase 6 ──────────────────────────────────────────────────────────
def _phase6(wb, cfg) -> None:
    cff = wb["Cash Flow Forecast"]
    ve = wb["Valuation Estimates"]
    seg = wb["Segment Revenue"]

    # 1. Revenue growth anchor — pulled from CONFIG.growth_path
    cells_5y = ["B39", "C39", "D39", "E39", "F39"]
    for cell, g in zip(cells_5y, cfg.growth_path):
        cff[cell] = g
        cff[cell].font = BOLD_BLUE
        cff[cell].fill = YELLOW
        cff[cell].number_format = "0.0%"
        cff[cell].comment = Comment(
            f"HARDCODED — consensus-aligned growth for {cfg.ticker} "
            f"({g*100:.1f}%). Source: dcf_config.CONFIG.growth_path.",
            AUTHOR,
        )

    # 2. Historical average cycle-bias note
    cff["H26"].comment = Comment(
        "NOTE: This historical average (~20%) is cycle-biased.\n"
        "FY22-FY25 covers peak-trough-peak (+62%, -49%, +49%).\n"
        "Not used in current forecast — row 39 is hardcoded.\n"
        "For reference only.",
        AUTHOR,
    )

    # 3. NTM EPS = forecast Y1 NI / Y1 diluted shares (post-SBC)
    cff["B56"] = "='Cash Flow Forecast'!B50/'Cash Flow Forecast'!B52"
    cff["B56"].font = BLACK
    cff["B56"].number_format = "$0.00"
    cff["B56"].comment = Comment(
        "NTM EPS = Y1 Net Income / Y1 Diluted Shares.\n"
        "Uses forecast-consistent share count (includes SBC dilution).",
        AUTHOR,
    )

    # 4. Segment Revenue growth recalibration (reconciles to top-down)
    #    Segment list comes from CONFIG.segments — skip if empty.
    cols_5y = ["C", "D", "E", "F", "G"]
    for segment in cfg.segments:
        if len(segment.growth_path) < 5:
            continue
        # Write the segment label in column A for clarity
        seg[f"A{segment.row}"] = segment.name
        for col, g in zip(cols_5y, segment.growth_path):
            cell_ref = f"{col}{segment.row}"
            seg[cell_ref] = g
            seg[cell_ref].number_format = "0.0%"

    # 5. Stage-1 end growth (from CONFIG)
    ve["B69"] = cfg.stage1_end_growth
    ve["B69"].font = BOLD_BLUE
    ve["B69"].fill = YELLOW
    ve["B69"].number_format = "0.0%"
    ve["B69"].comment = Comment(
        "Stage-1 end growth: 5% mid-cycle.\n"
        "Represents modest memory cycle recovery in Y6-Y10 above Y5 trough.",
        AUTHOR,
    )

    # 6. Driver Sensitivity / tornado tab
    _build_driver_sensitivity(wb, cfg)

    # 7. Revenue Bridge tab
    _build_revenue_bridge(wb, cfg)

    # 8. Terminal growth (VE!H6) from CONFIG
    try:
        ve["H6"] = cfg.terminal_growth
        ve["H6"].number_format = "0.0%"
    except Exception:
        pass

    # 9. Scenario ordering — handled by _patch_scenario_recalibration in
    #    Phase 7 (cycle-aware PATH mode or naive OFFSET mode, selected per
    #    CONFIG). The older `_enforce_scenario_ordering` pass is retained
    #    below only as a legacy helper for callers that pass an older
    #    CONFIG shape — it's NOT wired into the pipeline anymore.
    # _enforce_scenario_ordering(wb, cfg)  # replaced by _patch_scenario_recalibration

    # 10. Valuation Summary Extended Horizon signal (H5) — fix the
    #     E13 denominator and make the DDM row (if present anywhere
    #     downstream) gate on dividend size.
    _polish_valuation_summary(wb, cfg)


def _build_driver_sensitivity(wb, cfg=None) -> None:
    """Driver Sensitivity / tornado tab — Audit #3 formula-linkage.

    Every driver value (cols B/C/D) is now a LIVE formula reading the
    authoritative model cell. Columns C/D are Base ± 10% via multiplication
    so they follow the base automatically across ticker swaps.

    The Δ Downside / Δ Upside columns (E/F) used to carry hardcoded
    MU-specific dollar amounts (−$14, +$16, …) that silently drifted on
    ticker swaps. They're now blanked with a pointer to the live 2-way
    WACC × Terminal g grid on Valuation Summary!C21:D27 and the live
    EBIT × NWC grid on Valuation Summary!D34:H38 — those are the real
    live sensitivities; the tornado is kept for layout/summary only.
    """
    if "Driver Sensitivity" in wb.sheetnames:
        del wb["Driver Sensitivity"]
    tor = wb.create_sheet("Driver Sensitivity")

    tor["A1"] = "DCF DRIVER SENSITIVITY — Tornado Analysis"
    tor["A1"].font = Font(name="Calibri", bold=True, size=14, color="1F3864")
    tor.merge_cells("A1:F1")

    tor["A2"] = ("Drivers read live from the workbook. Low/High = Base × (1 ∓ 10%). "
                 "For Δ implied-price impact, see 'Valuation Summary'!C21:D27 (WACC × g) "
                 "and 'Valuation Summary'!D34:H38 (EBIT × NWC).")
    tor["A2"].font = Font(name="Calibri", italic=True, color="595959", size=10)
    tor["A2"].alignment = Alignment(wrap_text=True, vertical="top")
    tor.merge_cells("A2:F2")
    tor.row_dimensions[2].height = 30

    for i, h in enumerate(["Driver", "Base Value", "Low (-10%)",
                           "High (+10%)", "Est. Δ Downside", "Est. Δ Upside"]):
        c = tor.cell(row=4, column=i + 1, value=h)
        c.font = HDR_FONT
        c.fill = HDR_FILL
        c.alignment = Alignment(horizontal="center", vertical="center")
        c.border = BORDER

    # Each driver: (label, live base-formula, percentage-format, down_note, up_note).
    # Cols C and D are computed in Excel as B*0.9 / B*1.1 respectively so they
    # follow whatever Base resolves to — no MU-specific calibration baked in.
    # Net Debt is in $M (Valuation Estimates!B16 is already in $M post Audit #1);
    # the number format folds millions → billions for readability.
    drivers = [
        ("WACC (Base Case)",            "='Required Return'!C54",       "0.00%"),
        ("Terminal Growth",             "='Valuation Estimates'!H6",    "0.00%"),
        ("EBIT Margin Y1",              "='Cash Flow Forecast'!B44",    "0.0%"),
        ("Revenue Growth Y1",           "='Cash Flow Forecast'!B39",    "0.0%"),
        ("CapEx/Sales Y1",              "='Cash Flow Forecast'!B60",    "0.0%"),
        ("Stage-1 End Growth (Y6-Y10)", "='Valuation Estimates'!B69",   "0.0%"),
        ("Tax Rate",                    "='Required Return'!C44",       "0.00%"),
        ("Net Debt ($M)",               "='Valuation Estimates'!B16",   '"$"#,##0,"M"'),
    ]
    for i, (name, base_formula, fmt) in enumerate(drivers):
        r = 5 + i
        # Column A — label
        a = tor.cell(row=r, column=1, value=name)
        a.font = Font(name="Calibri", bold=True)

        # Column B — live base value
        b = tor.cell(row=r, column=2, value=base_formula)
        b.number_format = fmt
        b.alignment = Alignment(horizontal="right")

        # Column C — base × 0.9 (−10% shift in the driver)
        c_low = tor.cell(row=r, column=3, value=f"=B{r}*0.9")
        c_low.number_format = fmt
        c_low.alignment = Alignment(horizontal="right")

        # Column D — base × 1.1 (+10% shift in the driver)
        c_high = tor.cell(row=r, column=4, value=f"=B{r}*1.1")
        c_high.number_format = fmt
        c_high.alignment = Alignment(horizontal="right")

        # Columns E / F — Δ columns. Deliberately blanked to remove the
        # stale MU-calibrated $ amounts. Users see "—" and the A2 note
        # points them to the real 2-way sensitivity grids on
        # Valuation Summary.
        c_down = tor.cell(row=r, column=5, value="—")
        c_down.alignment = Alignment(horizontal="center")
        c_down.font = Font(name="Calibri", color="7F7F7F", italic=True)

        c_up = tor.cell(row=r, column=6, value="—")
        c_up.alignment = Alignment(horizontal="center")
        c_up.font = Font(name="Calibri", color="7F7F7F", italic=True)

        for col in range(1, 7):
            tor.cell(row=r, column=col).border = BORDER
            if i % 2 == 0:
                tor.cell(row=r, column=col).fill = LBLUE

    # Comment pinned on the E/F column headers explains the change
    tor["E4"].comment = Comment(
        "Audit #3 — hardcoded MU Δ$ amounts removed. For live implied-price\n"
        "deltas under driver shifts, see the 2-way sensitivity grids on\n"
        "Valuation Summary!C21:D27 (WACC × Terminal g) and\n"
        "Valuation Summary!D34:H38 (EBIT × NWC).",
        AUTHOR,
    )

    tor["A15"] = "Key takeaways (ticker-agnostic):"
    tor["A15"].font = Font(name="Calibri", bold=True, color="1F3864")
    notes = [
        "1. WACC and EBIT Margin Y1 are the two largest drivers of implied price "
            "in a typical DCF — the Required Return tab and Cash Flow Forecast row "
            "44 must both be defensible before any IC conversation.",
        "2. Terminal growth and Stage-1 end growth are second-order — "
            "the Two-Stage DCF is designed not to over-rely on them.",
        "3. Tax rate and net debt are tertiary — meaningful only in lever-heavy "
            "or tax-regime-shift stories.",
        "4. Read this table as directional. For live price Δs, use the 2-way "
            "sensitivity grids on the Valuation Summary tab.",
    ]
    for i, n in enumerate(notes):
        tor[f"A{16 + i}"] = n
        tor[f"A{16 + i}"].font = Font(name="Calibri", color="595959", size=10)
        tor[f"A{16 + i}"].alignment = Alignment(wrap_text=True, vertical="top")
        tor.merge_cells(f"A{16+i}:F{16+i}")

    # Live price-range footer: pulled from the Pessimistic and Optimistic
    # DCFs on Valuation Estimates so it always reflects the actual model
    # outputs (no hardcoded $95-$145 MU band). Both sides are formula-linked.
    tor["A22"] = (
        '="FOR IC: Expected price range under Pess/Opt DCFs: $"'
        '&TEXT(\'Valuation Estimates\'!B20,"0")'
        '&" - $"'
        '&TEXT(\'Valuation Estimates\'!F20,"0")'
        '&"  (Base: $"'
        '&TEXT(\'Valuation Estimates\'!D20,"0")&")"'
    )
    tor["A22"].font = Font(name="Calibri", bold=True, size=11, color="C00000")
    tor["A22"].alignment = Alignment(wrap_text=True, vertical="top")
    tor.merge_cells("A22:F22")

    tor.column_dimensions["A"].width = 32
    for c in "BCDEF":
        tor.column_dimensions[c].width = 14


def _build_revenue_bridge(wb, cfg=None) -> None:
    """Revenue Bridge tab — Audit #3 formula-linkage.

    The consensus strip (row 14) and the reconciliation narrative (rows
    19-22) previously carried MU-specific hardcoded values that silently
    drifted on ticker swaps. Both are now CONFIG-driven:

      • Row 14 reads CONFIG.consensus_revenue (6-tuple: FY-1A + FY+1E..FY+5E).
        If None, the row is blanked with "N/A" and the YoY growths suppress.
      • Row 19 is built from CONFIG.growth_path (top-down forecast).
      • Row 20 is built from CONFIG.segments (bottoms-up — Y1 → Y5 per segment).
      • Row 21 is built from CONFIG.consensus_revenue when present.
      • The legacy "Previous forecast … was unsustainable" line is retired —
        it was an Audit #0 remediation note, not a model truth.
    """
    if "Revenue Bridge" in wb.sheetnames:
        del wb["Revenue Bridge"]
    rb = wb.create_sheet("Revenue Bridge")

    rb["A1"] = "REVENUE BRIDGE — Top-Down vs Bottoms-Up Reconciliation"
    rb["A1"].font = Font(name="Calibri", bold=True, size=14, color="1F3864")
    rb.merge_cells("A1:H1")

    headers = ["Metric", "FY25A", "FY26E", "FY27E", "FY28E", "FY29E", "FY30E", "5Y CAGR"]
    for i, h in enumerate(headers):
        c = rb.cell(row=3, column=i + 1, value=h)
        c.font = HDR_FONT
        c.fill = HDR_FILL
        c.alignment = Alignment(horizontal="center")
        c.border = BORDER

    # Top-down
    rb["A5"] = "Top-Down Revenue ($M)"
    rb["A5"].font = Font(name="Calibri", bold=True)
    rb["B5"] = "='Cash Flow Forecast'!B8"
    for i, c in enumerate(["C5", "D5", "E5", "F5", "G5"]):
        rb[c] = f"='Cash Flow Forecast'!{chr(ord('B') + i)}40"
    rb["H5"] = "=(G5/B5)^(1/5)-1"
    for c in "BCDEFG":
        rb[f"{c}5"].number_format = "$#,##0"
        rb[f"{c}5"].border = BORDER
    rb["H5"].number_format = "0.0%"
    rb["H5"].border = BORDER

    rb["A6"] = "  Top-Down YoY Growth"
    for c in "CDEFG":
        prev = chr(ord(c) - 1)
        rb[f"{c}6"] = f"={c}5/{prev}5-1"
        rb[f"{c}6"].number_format = "0.0%"
        rb[f"{c}6"].font = Font(name="Calibri", italic=True, color="595959")

    # Bottoms-up
    rb["A8"] = "Bottoms-Up Revenue ($M)"
    rb["A8"].font = Font(name="Calibri", bold=True)
    for c in "BCDEFG":
        rb[f"{c}8"] = f"='Segment Revenue'!{c}16"
        rb[f"{c}8"].number_format = "$#,##0"
        rb[f"{c}8"].border = BORDER
    rb["H8"] = "=(G8/B8)^(1/5)-1"
    rb["H8"].number_format = "0.0%"
    rb["H8"].border = BORDER

    rb["A9"] = "  Bottoms-Up YoY Growth"
    for c in "CDEFG":
        prev = chr(ord(c) - 1)
        rb[f"{c}9"] = f"={c}8/{prev}8-1"
        rb[f"{c}9"].number_format = "0.0%"
        rb[f"{c}9"].font = Font(name="Calibri", italic=True, color="595959")

    # Variance
    rb["A11"] = "VARIANCE (TD - BU)"
    rb["A11"].font = Font(name="Calibri", bold=True, color="C00000")
    for c in "CDEFG":
        rb[f"{c}11"] = f"={c}5-{c}8"
        rb[f"{c}11"].number_format = "$#,##0;($#,##0)"
        rb[f"{c}11"].font = Font(name="Calibri", bold=True, color="C00000")
    rb["A12"] = "  Variance %"
    for c in "CDEFG":
        rb[f"{c}12"] = f"=({c}5-{c}8)/{c}8"
        rb[f"{c}12"].number_format = "0.0%"
        rb[f"{c}12"].font = Font(name="Calibri", italic=True, color="C00000")

    # ─── Consensus (row 14) — Audit #3 CONFIG-driven ─────────────────
    rb["A14"] = "Street Consensus ($M)"
    rb["A14"].font = Font(name="Calibri", bold=True, color="595959")

    consensus = getattr(cfg, "consensus_revenue", None) if cfg is not None else None
    if consensus is not None and len(consensus) == 6:
        for i, c in enumerate("BCDEFG"):
            rb[f"{c}14"] = float(consensus[i])
            rb[f"{c}14"].font = BLUE
            rb[f"{c}14"].fill = YELLOW
            rb[f"{c}14"].number_format = "$#,##0"
        rb["H14"] = "=(G14/B14)^(1/5)-1"
        rb["H14"].number_format = "0.0%"
        rb["B14"].comment = Comment(
            "Street consensus from CONFIG.consensus_revenue "
            "(FY-1A + FY+1E..FY+5E, $ millions).\n"
            "To update, edit Cell 3 of the notebook and re-run Cells 3→5.",
            AUTHOR,
        )
        # YoY growth row only populated when consensus is live
        rb["A15"] = "  Consensus YoY Growth"
        for c in "CDEFG":
            prev = chr(ord(c) - 1)
            rb[f"{c}15"] = f"={c}14/{prev}14-1"
            rb[f"{c}15"].number_format = "0.0%"
            rb[f"{c}15"].font = Font(name="Calibri", italic=True, color="595959")
    else:
        # No consensus provided — blank the row with an N/A marker so the
        # template stays readable but no stale MU numbers leak through.
        for c in "BCDEFG":
            rb[f"{c}14"] = "N/A"
            rb[f"{c}14"].font = Font(name="Calibri", color="7F7F7F", italic=True)
            rb[f"{c}14"].alignment = Alignment(horizontal="center")
        rb["H14"] = "N/A"
        rb["H14"].font = Font(name="Calibri", color="7F7F7F", italic=True)
        rb["H14"].alignment = Alignment(horizontal="center")
        rb["A15"] = "  Consensus YoY Growth"
        for c in "CDEFG":
            rb[f"{c}15"] = ""
        rb["B14"].comment = Comment(
            "CONFIG.consensus_revenue is None for this ticker — consensus row "
            "shows 'N/A'.\nSet a 6-tuple (FY-1A + FY+1..FY+5E, $M) in Cell 3 "
            "to activate.",
            AUTHOR,
        )

    # ─── Reconciliation Summary (rows 18-22) — Audit #3 CONFIG-driven ─
    rb["A18"] = "Reconciliation Summary:"
    rb["A18"].font = Font(name="Calibri", bold=True, color="1F3864")

    # Row 19 — Top-Down growth path, from CONFIG.growth_path
    gp = getattr(cfg, "growth_path", None) if cfg is not None else None
    if gp and len(gp) >= 5:
        td_txt = " → ".join(f"{g*100:.0f}%" for g in gp[:5])
        rb["A19"] = f"Top-Down: {td_txt} — from CONFIG.growth_path (Cell 3)"
    else:
        rb["A19"] = "Top-Down: (CONFIG.growth_path not set)"

    # Row 20 — Bottoms-Up per segment, Y1 → Y5, from CONFIG.segments
    segs = getattr(cfg, "segments", None) if cfg is not None else None
    if segs:
        parts = []
        for seg in segs:
            path = getattr(seg, "growth_path", ())
            if len(path) >= 5:
                parts.append(f"{seg.name} {path[0]*100:.0f}%→{path[-1]*100:.0f}%")
        if parts:
            rb["A20"] = "Bottoms-Up: " + ", ".join(parts) + " — from CONFIG.segments"
        else:
            rb["A20"] = "Bottoms-Up: (CONFIG.segments set but growth_paths incomplete)"
    else:
        rb["A20"] = "Bottoms-Up: (no segments — top-down only)"

    # Row 21 — Consensus YoY growth, from CONFIG.consensus_revenue
    if consensus is not None and len(consensus) == 6:
        c_growths = [(consensus[i + 1] / consensus[i] - 1) for i in range(5)]
        c_txt = " → ".join(f"{g*100:.0f}%" for g in c_growths)
        rb["A21"] = f"Consensus (Street): {c_txt} — from CONFIG.consensus_revenue"
    else:
        rb["A21"] = "Consensus (Street): N/A — set CONFIG.consensus_revenue"

    for i in range(19, 22):
        rb[f"A{i}"].font = Font(name="Calibri", color="595959", size=10)
        rb[f"A{i}"].alignment = Alignment(wrap_text=True, vertical="top")
        rb.merge_cells(f"A{i}:H{i}")

    rb.column_dimensions["A"].width = 32
    for c in "BCDEFGH":
        rb.column_dimensions[c].width = 13


# ─── Scenario ordering enforcer (B4) ──────────────────────────────────
def _enforce_scenario_ordering(wb, cfg) -> None:
    """
    Rewrite Scenario Analysis Pessimistic (row 9 rev, row 14 EBIT) and
    Optimistic (row 44 rev, row 49 EBIT) as Excel formulas anchored to
    Cash Flow Forecast base case ± offsets from CONFIG.

    This guarantees:
        Optim_k   = Base_k + optim_revenue_offset
        Pess_k    = Base_k + pess_revenue_offset
    so the three scenarios are strictly ordered in year 1 as long as
    (optim_offset - pess_offset) > 0, which is enforced at module load
    by the assertion at the end of this function.
    """
    if "Scenario Analysis" not in wb.sheetnames:
        return
    sa = wb["Scenario Analysis"]

    # Guard against CONFIGs missing the new fields (older dcf_config.py).
    pess_rev = float(getattr(cfg, "pess_revenue_offset",  -0.02))
    optim_rev = float(getattr(cfg, "optim_revenue_offset", +0.02))
    pess_eb  = float(getattr(cfg, "pess_ebit_offset",    -0.04))
    optim_eb = float(getattr(cfg, "optim_ebit_offset",   +0.03))
    eps      = float(getattr(cfg, "scenario_epsilon",      0.005))

    # Hard assertion — fail loudly so misconfigured scenarios never ship.
    assert optim_rev - pess_rev >= 2 * eps, (
        f"Scenario CONFIG invalid: optim_revenue_offset ({optim_rev:+.3f}) "
        f"must exceed pess_revenue_offset ({pess_rev:+.3f}) by ≥ 2·eps."
    )
    assert optim_eb - pess_eb >= 2 * eps, (
        f"Scenario CONFIG invalid: optim_ebit_offset ({optim_eb:+.3f}) "
        f"must exceed pess_ebit_offset ({pess_eb:+.3f}) by ≥ 2·eps."
    )

    # Column sequence for the 5-year forecast.
    cols = ["B", "C", "D", "E", "F"]

    # Pessimistic revenue  → SA!B9:F9  = CFF!{col}39 + pess_rev
    # Optimistic  revenue  → SA!B44:F44 = CFF!{col}39 + optim_rev
    for col in cols:
        sa[f"{col}9"]  = f"='Cash Flow Forecast'!{col}39+({pess_rev:.6f})"
        sa[f"{col}9"].number_format = "0.0%"
        sa[f"{col}44"] = f"='Cash Flow Forecast'!{col}39+({optim_rev:.6f})"
        sa[f"{col}44"].number_format = "0.0%"

    # Pessimistic EBIT margin → SA!B14:F14 = CFF!{col}44 + pess_eb
    # Optimistic  EBIT margin → SA!B49:F49 = CFF!{col}44 + optim_eb
    for col in cols:
        sa[f"{col}14"] = f"='Cash Flow Forecast'!{col}44+({pess_eb:.6f})"
        sa[f"{col}14"].number_format = "0.0%"
        sa[f"{col}49"] = f"='Cash Flow Forecast'!{col}44+({optim_eb:.6f})"
        sa[f"{col}49"].number_format = "0.0%"

    # Helpful comments pin the logic in-place for reviewers.
    sa["B9"].comment  = Comment(
        f"Pessimistic revenue = Base + {pess_rev*100:+.1f} pp  (from CONFIG.pess_revenue_offset).",
        AUTHOR,
    )
    sa["B44"].comment = Comment(
        f"Optimistic revenue = Base + {optim_rev*100:+.1f} pp  (from CONFIG.optim_revenue_offset).",
        AUTHOR,
    )
    sa["B14"].comment = Comment(
        f"Pessimistic EBIT margin = Base + {pess_eb*100:+.1f} pp  (from CONFIG.pess_ebit_offset).",
        AUTHOR,
    )
    sa["B49"].comment = Comment(
        f"Optimistic EBIT margin = Base + {optim_eb*100:+.1f} pp  (from CONFIG.optim_ebit_offset).",
        AUTHOR,
    )


# ─── Valuation Summary polish (H5 + B6) ───────────────────────────────
def _polish_valuation_summary(wb, cfg) -> None:
    """
    Two durable fixes on the Valuation Summary tab:

    1. H5 — Extended Horizon signal row 13. The shipped E13 formula
       used the implied price as the denominator, which massively
       distorted the % delta. Correct convention elsewhere on the tab:
       E = -(D - Market)/Market, so Overvalued (+) = stock above model.

    2. B6 (DDM gate) — if Cover row 18 pulls a DDM value that the
       Valuation Estimates tab flagged as 'n/a' (because annual
       dividend-per-share < CONFIG.dividend_min_threshold), show
       'N/A' and 'Not meaningful' instead of a misleading number.
       This tab doesn't currently have a DDM row, but the Cover tab
       does — that fix lives in _build_cover_tab below.
    """
    if "Valuation Summary" not in wb.sheetnames:
        return
    vs = wb["Valuation Summary"]

    # H5: rewrite E13 and F13 with the correct sign/denominator
    # convention matching E6..E11 on the same tab.
    vs["E13"] = "=IFERROR(-(D13-'Valuation Estimates'!D21)/'Valuation Estimates'!D21,0)"
    vs["E13"].number_format = "0.0%;(0.0%);-"
    vs["F13"] = ('=IFERROR(IF(E13="","N/A",'
                 'IF(E13>0.1,"Overvalued",'
                 'IF(E13<-0.1,"Undervalued","Fair Value"))),0)')
    vs["E13"].comment = Comment(
        "Overvaluation(+) / Undervaluation(-) vs. market price.\n"
        "Convention: −(Implied − Market) / Market, same as rows 6–11.\n"
        "Previous formula divided by implied, distorting the % delta.",
        AUTHOR,
    )


# ─── Phase 7 ──────────────────────────────────────────────────────────
def _phase7(wb, cfg) -> None:
    ve = wb["Valuation Estimates"]

    # Relabel VE row 14
    ve["B14"] = "Pessimistic DCF"
    ve["D14"] = "Base Case DCF"
    ve["F14"] = "Optimistic DCF"
    for c in "BDF":
        ve[f"{c}14"].font = Font(name="Calibri", bold=True, color="1F3864", size=11)
        ve[f"{c}14"].alignment = Alignment(horizontal="center")

    _build_cover_tab(wb, cfg)
    _patch_legacy_lookups(wb)
    _patch_audit_math_fixes(wb)
    _patch_scenario_recalibration(wb, cfg)
    _patch_fcff_unlevered(wb)     # Audit #5 — FCFE → FCFF for EV-bridge consistency


def _patch_fcff_unlevered(wb) -> None:
    """Audit #5 (Apr-2026) — switch FCF from FCFE (levered, Net-Income-based)
    to FCFF (unlevered, NOPAT-based). IB EV-DCF standard.

    BACKGROUND
    ──────────
    The original template wrote Free Cash Flow as:
        FCF = Net Income + D&A − CapEx − ΔNWC          (FCFE, levered)

    But the downstream EV bridge (Valuation Estimates rows 14–17) does:
        Equity Value = PV(FCF discounted at WACC) − Net Debt

    That's a methodological double-count: FCFE already nets out interest
    expense, so subtracting Net Debt afterwards counts interest twice (once
    in the cash flow line, once in the discount-rate weighting via WACC's
    debt component). the desk's EV-DCF convention is unambiguous:

        FCFF = NOPAT + D&A − CapEx − ΔNWC              (unlevered)
        EV   = PV(FCFF discounted at WACC)
        Equity = EV − Net Debt

    THE FIX
    ───────
    Three FCF cells across two tabs need to switch their NOPAT/NI source:

        Cash Flow Forecast!B65:F65   B49 (NI)  → B47 (NOPAT)   Base case
        Scenario Analysis!B36:F36    B19 (NI)  → B17 (NOPAT)   Pessimistic
        Scenario Analysis!B71:F71    B54 (NI)  → B52 (NOPAT)   Optimistic

    NUMERICAL IMPACT (MU)
    ─────────────────────
    Interest expense ~$540M/yr × 5 years × (1 − tax) ≈ $2.1B less PV erosion.
    Adds roughly $1.50–2.00 per share to the DCF base case. Modest in
    absolute terms because MU's debt load is small (weight ~3%), but
    methodologically critical for credibility — MDs will catch the FCFE-
    with-EV-bridge inconsistency on first look.
    """
    cff = wb["Cash Flow Forecast"]
    sa  = wb["Scenario Analysis"]

    # Base case (CFF row 65)
    for col in "BCDEF":
        cff[f"{col}65"].value = f"={col}47+{col}59+{col}61-{col}64"

    # Pessimistic case (SA row 36)
    for col in "BCDEF":
        sa[f"{col}36"].value = f"={col}17+{col}30+{col}32-{col}35"

    # Optimistic case (SA row 71)
    for col in "BCDEF":
        sa[f"{col}71"].value = f"={col}52+{col}65+{col}67-{col}70"

    # Update labels to reflect FCFF (was generic "Free Cash Flow")
    cff["A65"].value = "Free Cash Flow to Firm (FCFF — unlevered)"
    sa["A36"].value  = "Free Cash Flow to Firm (FCFF — unlevered)"
    sa["A71"].value  = "Free Cash Flow to Firm (FCFF — unlevered)"


def _patch_audit_math_fixes(wb) -> None:
    """Mathematical correctness fixes discovered during Audit #1.

    Fix A: Valuation Estimates!B16 had '+800' hardcoded in Net Debt formula
    (legacy value from a different ticker, likely pension/OPEB). For MU it
    was inflating Net Debt by $800M and compressing per-share DCF by ~$0.72.

    Fix B: Valuation Summary!E13 (Two-Stage DCF Over/Under) used the implied
    price as denominator — inconsistent with every other Over/Under in the
    template which uses market price. Normalized to (Market-Implied)/Market.

    Fix C: Valuation Estimates!C69 label said "6% mid-cycle" while value at
    B69 was 0.05 (5%). Fixed label to match value (5% is the conservative
    mid-cycle growth for MU exiting the 2025-26 peak).
    """
    if "Valuation Estimates" in wb.sheetnames:
        ve = wb["Valuation Estimates"]
        # Fix A — Net Debt
        b16 = ve["B16"].value
        if isinstance(b16, str) and "+800" in b16:
            ve["B16"].value = (
                "='Required Return'!C8+'Required Return'!C9"
                "-'Cash Flow Forecast'!B15"
            )
        # Fix C — label
        c69 = ve["C69"].value
        if isinstance(c69, str) and "6%" in c69 and "mid-cycle" in c69.lower():
            ve["C69"].value = "(hardcoded: 5% mid-cycle exiting peak)"

    if "Valuation Summary" in wb.sheetnames:
        vs = wb["Valuation Summary"]
        # Fix B — Over/Under denominator
        e13 = vs["E13"].value
        if isinstance(e13, str) and "D21-D13)/D13" in e13.replace(
            "'Valuation Estimates'!", ""
        ):
            vs["E13"].value = "=IFERROR((D12-D13)/D12,0)"

    # Fix D (Audit #8 — added Apr 2026): Scenario Analysis!G23 referenced
    # 'Cash Flow Forecast'!G92 — a phantom cell (CFF max row is 72; G92 is
    # empty). The other G-column cells in that row's section reference G53
    # (the annualized cumulative share-change). Rewrite as the direct
    # 5-year geometric-mean formula so the cell self-computes from B23:F23
    # and never depends on a stale CFF row.
    if "Scenario Analysis" in wb.sheetnames:
        sa = wb["Scenario Analysis"]
        g23 = sa["G23"].value
        if isinstance(g23, str) and ("G92" in g23 or "G53" not in g23):
            sa["G23"].value = (
                "=IFERROR(((1+B23)*(1+C23)*(1+D23)*(1+E23)*(1+F23))^(1/5)-1,"
                '"N/A")'
            )


def _patch_scenario_recalibration(wb, cfg) -> None:
    """Audit #2 — Scenario consistency rebuild. AUTHORITATIVE scenario setter.

    Replaces the older ``_enforce_scenario_ordering`` naive ±-constant pass
    (which violated Pess < Base < Opt ordering for cyclical names where a
    flat ±2pp can't reproduce the trough-and-recovery cycle).

    Two modes, selected per-field by CONFIG:
      1. PATH mode  (CONFIG.pess_rev_path / .opt_rev_path set)  — year-by-year
                    hardcoded values written directly. Use for cyclical names
                    (memory, commodities, deep cyclicals) where the shape of
                    the cycle matters.
      2. OFFSET mode (paths None)  — formula driven as
                    =CFF!{col}39 + pess_revenue_offset  (and same for EBIT
                    using row 44). Use for steady-state names (software,
                    staples) where Base ± constant is realistic.

    CapEx%, NWC% and interest scaling are always formula-linked to Base Case
    with configurable offsets/floors/multipliers so the model preserves
    cyclical reinvestment dynamics regardless of which mode is chosen.
    """
    if "Scenario Analysis" not in wb.sheetnames:
        return
    scn = wb["Scenario Analysis"]

    # ---- Pull every lever from the DCFConfig dataclass (with fallbacks) ----
    def _g(name, default):
        """Safe attribute fetch that tolerates dict-style or dataclass cfg."""
        if cfg is None:
            return default
        if isinstance(cfg, dict):
            return cfg.get(name, default)
        return getattr(cfg, name, default)

    PESS_REV_PATH    = _g("pess_rev_path",  None)
    OPT_REV_PATH     = _g("opt_rev_path",   None)
    PESS_EBIT_PATH   = _g("pess_ebit_path", None)
    OPT_EBIT_PATH    = _g("opt_ebit_path",  None)

    PESS_REV_OFFSET  = float(_g("pess_revenue_offset",  -0.02))
    OPT_REV_OFFSET   = float(_g("optim_revenue_offset", +0.02))
    PESS_EBIT_OFFSET = float(_g("pess_ebit_offset",     -0.04))
    OPT_EBIT_OFFSET  = float(_g("optim_ebit_offset",    +0.03))

    CAPEX_PESS_OFFSET = float(_g("capex_pess_offset", 0.03))
    CAPEX_OPT_OFFSET  = float(_g("capex_opt_offset",  0.03))
    CAPEX_OPT_FLOOR   = float(_g("capex_opt_floor",   0.15))
    NWC_PESS_OFFSET   = float(_g("nwc_pess_offset",   0.02))
    NWC_OPT_OFFSET    = float(_g("nwc_opt_offset",    0.02))
    NWC_OPT_FLOOR     = float(_g("nwc_opt_floor",     0.20))
    INTEREST_PESS_MULT = float(_g("interest_pess_mult", 1.05))
    INTEREST_OPT_MULT  = float(_g("interest_opt_mult",  0.95))

    # Resolve the Pess/Opt rev and EBIT blocks (path OR offset mode)
    def _as_list(path):
        if path is None:
            return None
        try:
            return list(path)
        except TypeError:
            return None

    PESS_REV  = _as_list(PESS_REV_PATH)
    OPT_REV   = _as_list(OPT_REV_PATH)
    PESS_EBIT = _as_list(PESS_EBIT_PATH)
    OPT_EBIT  = _as_list(OPT_EBIT_PATH)

    cols = ["B", "C", "D", "E", "F"]

    def _write_path_or_offset(row: int, path_values, offset: float,
                              base_row: int) -> None:
        """Write either hardcoded cycle path values OR a Base±offset formula.

        PATH mode  (path_values is a 5-list): writes the explicit values.
        OFFSET mode (path_values is None):    writes a formula linked to
            Cash Flow Forecast!{col}{base_row} + offset so the scenario
            stays aligned to Base even when Base is edited downstream.
        """
        if path_values is not None:
            for col, v in zip(cols, path_values):
                scn[f"{col}{row}"].value = v
                scn[f"{col}{row}"].number_format = "0.0%"
        else:
            for col in cols:
                scn[f"{col}{row}"].value = (
                    f"='Cash Flow Forecast'!{col}{base_row}+({offset:.6f})"
                )
                scn[f"{col}{row}"].number_format = "0.0%"

    # ---- Pessimistic block ----
    # Revenue growth (row 9) ← CFF row 39
    _write_path_or_offset(9, PESS_REV, PESS_REV_OFFSET, 39)
    scn["H9"].value = (
        "< Pessimistic = demand digestion + aggressive peer supply "
        "(HBM4 slip, CHIPS overbuild)"
    ) if PESS_REV is not None else (
        f"< Pessimistic = Base {PESS_REV_OFFSET*100:+.1f} pp (formula-linked)"
    )
    # EBIT margin (row 14) ← CFF row 44
    _write_path_or_offset(14, PESS_EBIT, PESS_EBIT_OFFSET, 44)
    scn["H14"].value = (
        "< Trough Y3 at 3%, recovery to 11% by Y5"
    ) if PESS_EBIT is not None else (
        f"< Pessimistic EBIT = Base {PESS_EBIT_OFFSET*100:+.1f} pp"
    )
    # CapEx % (row 31) — Base + offset
    for col in cols:
        scn[f"{col}31"].value = (
            f"='Cash Flow Forecast'!{col}$60+{CAPEX_PESS_OFFSET}"
        )
    scn["A31"].value = (
        f"CapEx % of Sales (Pess = Base + {int(CAPEX_PESS_OFFSET*100)}pp) >"
    )
    scn["G31"].value = "< CapEx commitments don't fall as fast as revenue"
    # NWC % (row 33) — Base + offset
    for col in cols:
        scn[f"{col}33"].value = (
            f"='Cash Flow Forecast'!{col}$62+{NWC_PESS_OFFSET}"
        )
    scn["A33"].value = (
        f"NWC % of Sales (Pess = Base + {int(NWC_PESS_OFFSET*100)}pp; "
        f"inventory bloat in downcycle) >"
    )
    # Interest (row 18) — multiplier replace
    for col in cols:
        cur = scn[f"{col}18"].value
        if isinstance(cur, str) and "'Cash Flow Forecast'!" in cur:
            # Extract base formula and rebuild with new multiplier
            import re as _re
            m = _re.match(r"='?Cash Flow Forecast'?!(\w+\d+)\*[\d.]+", cur)
            if m:
                scn[f"{col}18"].value = (
                    f"='Cash Flow Forecast'!{m.group(1)}*{INTEREST_PESS_MULT}"
                )

    # ---- Optimistic block ----
    # Revenue growth (row 44) ← CFF row 39
    _write_path_or_offset(44, OPT_REV, OPT_REV_OFFSET, 39)
    scn["H44"].value = (
        "< Optimistic = sustained HBM4 + AI PC/phone TAM + supply discipline"
    ) if OPT_REV is not None else (
        f"< Optimistic = Base {OPT_REV_OFFSET*100:+.1f} pp (formula-linked)"
    )
    # EBIT margin (row 49) ← CFF row 44
    _write_path_or_offset(49, OPT_EBIT, OPT_EBIT_OFFSET, 44)
    # CapEx % (row 66) — Base − offset, floored
    for col in cols:
        scn[f"{col}66"].value = (
            f"=MAX('Cash Flow Forecast'!{col}$60-{CAPEX_OPT_OFFSET},"
            f"{CAPEX_OPT_FLOOR})"
        )
    scn["A66"].value = (
        f"CapEx % of Sales (Opt = Base − {int(CAPEX_OPT_OFFSET*100)}pp, "
        f"floor {int(CAPEX_OPT_FLOOR*100)}%; operating leverage) >"
    )
    scn["G66"].value = "< Sustained utilization drives CapEx efficiency"
    # NWC % (row 68) — Base − offset, floored
    for col in cols:
        scn[f"{col}68"].value = (
            f"=MAX('Cash Flow Forecast'!{col}$62-{NWC_OPT_OFFSET},"
            f"{NWC_OPT_FLOOR})"
        )
    scn["A68"].value = (
        f"NWC % of Sales (Opt = Base − {int(NWC_OPT_OFFSET*100)}pp, "
        f"floor {int(NWC_OPT_FLOOR*100)}%; lean inventory) >"
    )
    # Interest (row 53) — multiplier replace
    for col in cols:
        cur = scn[f"{col}53"].value
        if isinstance(cur, str) and "'Cash Flow Forecast'!" in cur:
            import re as _re
            m = _re.match(r"='?Cash Flow Forecast'?!(\w+\d+)\*[\d.]+", cur)
            if m:
                scn[f"{col}53"].value = (
                    f"='Cash Flow Forecast'!{m.group(1)}*{INTEREST_OPT_MULT}"
                )

    # Header note
    scn["A2"].value = (
        "Scenario Recalibration (Audit #2): Pess/Opt paths strictly bracket "
        "Base. Revenue/EBIT hardcoded; CapEx/NWC formula-driven ± offsets "
        "from Base. Memory-cycle dynamics: counter-cyclical CapEx%, inventory "
        "bloat in downcycle."
    )


def _patch_legacy_lookups(wb) -> None:
    """Repair legacy template VLOOKUPs that target column indexes Industry no
    longer has (the tab was refactored to a live composite in col B only).

    Cash Flow Forecast!G27 previously looked up "Revenue Growth" in
    Industry!A:K column 7 (col G), expecting a multi-column industry
    time-series. The Industry tab now holds a single computed composite in
    col B (=Peer Comparison averages). Point G27 at Industry!B5 directly.
    """
    if "Cash Flow Forecast" not in wb.sheetnames:
        return
    cff = wb["Cash Flow Forecast"]
    current = cff["G27"].value if cff["G27"].value else ""
    if isinstance(current, str) and "Industry" in current and "VLOOKUP" in current:
        # Audit #4 — never fall back to a magic constant. Industry!B5 itself
        # now carries a peer→config→"N/A" hierarchy via fallback_chain.py,
        # so propagate the visible-failure mode instead of papering over it
        # with the prior 0.05 hardcode.
        cff["G27"].value = '=IFERROR(Industry!B5,"N/A")'


def _build_cover_tab(wb, cfg) -> None:
    if "Cover" in wb.sheetnames:
        del wb["Cover"]
    cov = wb.create_sheet("Cover", index=0)

    # Banner
    cov.merge_cells("A1:H1")
    cov["A1"] = cfg.banner
    cov["A1"].font = Font(name="Calibri", bold=True, size=20, color="FFFFFF")
    cov["A1"].fill = DARK_BLUE
    cov["A1"].alignment = Alignment(horizontal="center", vertical="center")
    cov.row_dimensions[1].height = 35

    cov.merge_cells("A2:H2")
    cov["A2"] = "DCF Valuation Model — IB-Ready Output  |  April 2026"
    cov["A2"].font = Font(name="Calibri", italic=True, size=11, color="595959")
    cov["A2"].alignment = Alignment(horizontal="center")

    # Section: Rating Summary
    cov.merge_cells("A4:H4")
    cov["A4"] = "INVESTMENT RECOMMENDATION"
    cov["A4"].font = Font(name="Calibri", bold=True, size=14, color="FFFFFF")
    cov["A4"].fill = DARK_BLUE
    cov["A4"].alignment = Alignment(horizontal="left", indent=1)
    cov.row_dimensions[4].height = 22

    # Rating row
    pairs = [
        ("A6", "Current Price",   "B6", "='Required Return'!C5"),
        ("C6", "Base Case DCF",   "D6", "='Valuation Estimates'!D20"),
        ("E6", "Two-Stage DCF",   "F6", "='Valuation Estimates'!B84"),
        ("G6", "Weighted Avg",    "H6", "='Valuation Estimates'!D20*'Valuation Estimates'!D25"
                                        "+'Valuation Estimates'!B20*'Valuation Estimates'!B25"
                                        "+'Valuation Estimates'!F20*'Valuation Estimates'!F25"),
    ]
    for lbl_cell, lbl, val_cell, formula in pairs:
        cov[lbl_cell] = lbl
        cov[lbl_cell].font = Font(name="Calibri", bold=True, size=11)
        cov[val_cell] = formula
        cov[val_cell].number_format = "$#,##0.00"
        cov[val_cell].font = Font(name="Calibri", size=11)
    for c in "ABCDEFGH":
        cov[f"{c}6"].fill = LBLUE
        cov[f"{c}6"].border = BORDER
        cov[f"{c}6"].alignment = Alignment(horizontal="center")

    # Section: Valuation Comparison Table
    cov.merge_cells("A9:H9")
    cov["A9"] = "VALUATION SUMMARY — IMPLIED PRICE PER SHARE"
    cov["A9"].font = Font(name="Calibri", bold=True, size=14, color="FFFFFF")
    cov["A9"].fill = DARK_BLUE
    cov["A9"].alignment = Alignment(horizontal="left", indent=1)
    cov.row_dimensions[9].height = 22

    for i, h in enumerate(["Methodology", "Scenario", "Implied Price",
                           "vs Market", "% Δ", "Signal"]):
        cell = cov.cell(row=11, column=i + 1, value=h)
        cell.font = WHITE
        cell.fill = DARK_BLUE
        cell.alignment = Alignment(horizontal="center")
        cell.border = BORDER_THICK

    # Row layout for the Cover valuation-comparison table.
    # 'kind' flags:
    #   'std' → standard row (implied price vs market, signal computed).
    #   'ddm' → dividend-discount row. Gate every dependent column so
    #           low- or zero-payout names show 'N/A' / 'Not meaningful'
    #           instead of a misleading negative price. Threshold comes
    #           from CONFIG.dividend_min_threshold ($ per share).
    _div_thr = float(getattr(cfg, "dividend_min_threshold", 0.10))

    # Audit #3 — Cover!C19 is the "Analyst Price Target — Consensus" row.
    # Primary: VLOOKUP "Target Price" on Estimates!A:K (populated live by
    # dcf_refresh from yfinance targetMeanPrice). Fallback fires only if the
    # lookup misses (thinly-covered name, schema drift, API outage).
    #
    # CRITICAL: fallback MUST be street consensus, NEVER chain-fallback to
    # cfg.price_target — that's our firm's rating, a semantically different
    # number. If analyst_pt_fallback is None, emit IFNA(..., "N/A") so
    # missing data is visible rather than silently papered over with our
    # rating target.
    _pt_fb = getattr(cfg, "analyst_pt_fallback", None)
    if _pt_fb is None:
        _analyst_pt_formula = (
            '=IFNA(VLOOKUP("Target Price",Estimates!A:K,2,FALSE()),"N/A")'
        )
    else:
        _analyst_pt_formula = (
            '=IFERROR(VLOOKUP("Target Price",Estimates!A:K,2,FALSE()),'
            f'{float(_pt_fb):.2f})'
        )
    rows = [
        ("DCF — Two-Stage (10-Year)",        "Extended",  "='Valuation Estimates'!B84",             "std"),
        ("DCF — Base Case",                  "Base",      "='Valuation Estimates'!D20",             "std"),
        ("DCF — Pessimistic",                "Bear",      "='Valuation Estimates'!B20",             "std"),
        ("DCF — Optimistic",                 "Bull",      "='Valuation Estimates'!F20",             "std"),
        ("DCF — Probability Weighted",       "Wtd",       "=H6",                                    "std"),
        # Audit #5 fix (Apr-2026): was pointing at RV!H8 which is the PEER
        # MEDIAN P/E *multiple* (~30.69x), not a price — Cover was showing
        # "$30.69 / Overvalued" for the multiples lens, totally wrong.
        # Re-pointed at RV!H18 = "NORMALIZED BLENDED (Mid-Cycle × Median)
        # — HEADLINE", the cross-method weighted-average implied price
        # using mid-cycle drivers and peer-median multiples. For MU this
        # resolves to ~$401, the through-cycle multiples answer.
        ("Multiples (Peer Comps — Blended)", "Comps",     "='Relative Valuation'!H18",              "std"),
        ("Dividend Discount Model",          "DDM",       "='Valuation Estimates'!D46",             "ddm"),
        ("Analyst Price Target",             "Consensus", _analyst_pt_formula,                      "std"),
    ]
    for i, (method, scenario, formula, kind) in enumerate(rows):
        r = 12 + i
        cov.cell(row=r, column=1, value=method).font = Font(name="Calibri", bold=(i == 0))
        cov.cell(row=r, column=2, value=scenario).alignment = Alignment(horizontal="center")

        if kind == "ddm":
            # Wrap Implied Price so it collapses to "N/A" when dividend is
            # tiny or zero, or when the VE DDM cell returns text ("n/a").
            ddm_formula = (
                f"=IF(OR('Required Return'!H69<{_div_thr},"
                f"ISTEXT('Valuation Estimates'!D46),"
                f"'Valuation Estimates'!D46=0),"
                f"\"N/A\",{formula[1:]})"  # re-use formula, stripping leading =
            )
            cv = cov.cell(row=r, column=3, value=ddm_formula)
            cv.number_format = '$#,##0.00;($#,##0.00);"N/A"'
            cv.alignment = Alignment(horizontal="right")
            cm = cov.cell(
                row=r, column=4,
                value=f'=IF(ISTEXT(C{r}),"N/A",\'Required Return\'!C5)',
            )
            cm.number_format = '$#,##0.00;($#,##0.00);"N/A"'
            cm.alignment = Alignment(horizontal="right")
            cd = cov.cell(
                row=r, column=5,
                value=f'=IF(ISTEXT(C{r}),"N/A",IFERROR((C{r}-D{r})/D{r},"N/A"))',
            )
            cd.number_format = '0.0%;(0.0%);"N/A"'
            cd.alignment = Alignment(horizontal="right")
            cs = cov.cell(
                row=r, column=6,
                value=(f'=IF(ISTEXT(C{r}),"Not meaningful",'
                       f'IF(C{r}>D{r}*1.1,"Undervalued",'
                       f'IF(C{r}<D{r}*0.9,"Overvalued","Fair")))'),
            )
            cs.alignment = Alignment(horizontal="center")
            cs.font = Font(name="Calibri", bold=True, italic=True, color="7F7F7F")
            cs.comment = Comment(
                f"DDM is gated by CONFIG.dividend_min_threshold "
                f"(= ${_div_thr:.2f}/share).\n"
                f"Low-payout names collapse to 'N/A' to avoid the classic "
                f"Gordon-Growth divide-by-near-zero trap.",
                AUTHOR,
            )
        else:
            cv = cov.cell(row=r, column=3, value=formula)
            cv.number_format = "$#,##0.00"
            cv.alignment = Alignment(horizontal="right")
            cm = cov.cell(row=r, column=4, value="='Required Return'!C5")
            cm.number_format = "$#,##0.00"
            cm.alignment = Alignment(horizontal="right")
            cd = cov.cell(row=r, column=5, value=f"=(C{r}-D{r})/D{r}")
            cd.number_format = "0.0%;(0.0%);-"
            cd.alignment = Alignment(horizontal="right")
            cs = cov.cell(
                row=r, column=6,
                value=f'=IF(C{r}>D{r}*1.1,"Undervalued",IF(C{r}<D{r}*0.9,"Overvalued","Fair"))',
            )
            cs.alignment = Alignment(horizontal="center")
            cs.font = Font(name="Calibri", bold=True)

        for col in range(1, 7):
            cell = cov.cell(row=r, column=col)
            cell.border = BORDER
            if i == 0:
                cell.fill = GREEN_FILL
                cell.font = Font(name="Calibri", bold=True, color="1F3864")

    # Section: Key Drivers
    cov.merge_cells("A22:H22")
    cov["A22"] = "KEY MODEL ASSUMPTIONS"
    cov["A22"].font = Font(name="Calibri", bold=True, size=14, color="FFFFFF")
    cov["A22"].fill = DARK_BLUE
    cov["A22"].alignment = Alignment(horizontal="left", indent=1)
    cov.row_dimensions[22].height = 22

    # Audit #3 — E-column notes are ticker-agnostic. The previous set
    # leaked MU-specific calibration (e.g. "Consensus-aligned ($48B)",
    # "vs. street consensus 10-12%", "HBM operating leverage") that
    # silently mis-described NVDA / MSFT / any other ticker. Notes now
    # describe WHERE the value comes from and WHAT to compare against,
    # not a hardcoded MU magnitude.
    driver_rows = [
        ("Revenue FY+1E", "='Cash Flow Forecast'!B40", "$#,##0",
         "Stage-1 Y1 (CONFIG.growth_path[0])"),
        ("Revenue FY+5E", "='Cash Flow Forecast'!F40", "$#,##0",
         "Stage-1 exit (CONFIG.growth_path[-1])"),
        ("Revenue 5Y CAGR", "=('Cash Flow Forecast'!F40/'Cash Flow Forecast'!B8)^(1/5)-1",
         "0.0%", "Compounded Stage-1 forecast"),
        ("Peak EBIT Margin", "='Cash Flow Forecast'!B44", "0.0%",
         "Y1 EBIT margin from CFF row 44"),
        ("Terminal EBIT Margin", "='Cash Flow Forecast'!F44", "0.0%",
         "Y5 EBIT margin — mid-cycle exit"),
        ("WACC (Base)", "='Required Return'!C54", "0.00%",
         "Median of 3 approaches (Required Return)"),
        ("Terminal Growth", "='Valuation Estimates'!H6", "0.0%",
         "Long-run nominal GDP proxy (CONFIG.terminal_growth)"),
        ("Tax Rate", "='Required Return'!C44", "0.0%",
         "Effective tax (Required Return!C44)"),
        ("Net Debt", "='Valuation Estimates'!B16", "$#,##0",
         "ST + LT debt − Cash (post Audit #1)"),
        ("Shares Outstanding", "='Required Return'!C6", "#,##0",
         "Diluted (yfinance)"),
        ("Reverse DCF Implied g", "='Valuation Estimates'!C61", "0.0%",
         "Market-implied terminal growth"),
        ("Terminal % of EV (5Y)",
         "='Valuation Estimates'!G9/SUM('Valuation Estimates'!B9:G9)",
         "0.0%", "Target <75%"),
        ("Terminal % of EV (10Y)",
         "=('Valuation Estimates'!B80)/'Valuation Estimates'!B82",
         "0.0%", "Target <65% (IB-spec gate)"),
    ]
    for i, h in enumerate(["Driver", "Value", "", "Notes"]):
        col_idx = [1, 2, 3, 5][i] if i < 3 else 5
        cell = cov.cell(row=24, column=col_idx, value=h)
        cell.font = WHITE
        cell.fill = DARK_BLUE
        cell.alignment = Alignment(
            horizontal="center" if i != 3 else "left",
            indent=1 if i == 3 else 0,
        )
        cell.border = BORDER_THICK
    cov.merge_cells("E24:H24")
    cov.merge_cells("B24:D24")

    for i, (name, formula, fmt, note) in enumerate(driver_rows):
        r = 25 + i
        cov.cell(row=r, column=1, value=name).font = Font(name="Calibri", bold=True)
        cov.merge_cells(f"B{r}:D{r}")
        cv = cov.cell(row=r, column=2, value=formula)
        cv.number_format = fmt
        cv.alignment = Alignment(horizontal="right")
        cov.merge_cells(f"E{r}:H{r}")
        cov.cell(row=r, column=5, value=note).font = Font(name="Calibri", italic=True,
                                                          color="595959", size=10)
        for col in range(1, 9):
            cov.cell(row=r, column=col).border = BORDER

    # Section: THE THESIS
    next_row = 25 + len(driver_rows) + 1
    cov.merge_cells(f"A{next_row}:H{next_row}")
    cov[f"A{next_row}"] = "INVESTMENT THESIS — KEY TAKEAWAYS"
    cov[f"A{next_row}"].font = Font(name="Calibri", bold=True, size=14, color="FFFFFF")
    cov[f"A{next_row}"].fill = DARK_BLUE
    cov[f"A{next_row}"].alignment = Alignment(horizontal="left", indent=1)
    cov.row_dimensions[next_row].height = 22

    # Render thesis lines from CONFIG. Two classes of placeholders:
    #   • STATIC  ({ticker}, {company_short}, {rating}, {price_target}) —
    #     substituted by Python .format() at build time.
    #   • DYNAMIC ({fair_value}, {current_price}, {price_multiple}) —
    #     emitted as Excel formulas so the thesis re-computes every time
    #     the model refreshes. No more 420.59 drift vs $457.23 on Required
    #     Return!C5.
    # Any line with a dynamic placeholder is written as a live formula:
    #   ="…literal…"&TEXT(<cell>,"<fmt>")&"…literal…"
    # Any line without one stays a plain string.
    DYNAMIC_REFS = {
        # placeholder         (Excel ref,                           TEXT() format)
        # Note: the templates in dcf_config.thesis_lines already prefix
        # "$" before these placeholders, so the TEXT format emits a bare
        # integer. Don't double up the dollar sign.
        "fair_value":     ("'Valuation Estimates'!B84",             "\"0\""),
        "current_price":  ("'Required Return'!C5",                  "\"0\""),
        # Multiple of DCF fair value: market price ÷ two-stage fair value.
        "price_multiple": ("'Required Return'!C5/'Valuation Estimates'!B84", "\"0.0\""),
    }

    _static_ctx = dict(
        ticker=cfg.ticker,
        company=cfg.company_name,
        company_short=cfg.company_short,
        rating=cfg.rating,
        price_target=cfg.price_target,
    )

    def _render_thesis_line(template: str):
        """
        Return (is_formula, content).
        If the line contains dynamic placeholders, content is an Excel
        formula string starting with '='. Otherwise it's a plain string.
        """
        import re
        # First handle static substitutions for any {static} tags that
        # don't carry a format spec. We leave {fair_value:.0f} etc. alone
        # for dynamic processing below.
        def _safe_static_fmt(t: str) -> str:
            out = t
            for key, val in _static_ctx.items():
                # Match {key} and {key:fmt}
                out = re.sub(r"\{" + key + r"(:[^}]+)?\}",
                             lambda m: format(val, m.group(1)[1:]) if m.group(1) else str(val),
                             out)
            return out
        t = _safe_static_fmt(template)

        # Scan for remaining dynamic placeholders.
        pattern = re.compile(r"\{(" + "|".join(DYNAMIC_REFS.keys()) + r")(:[^}]+)?\}")
        if not pattern.search(t):
            # No dynamic tokens — strip any lingering unknown braces.
            return (False, t)

        # Build Excel formula: alternating literal strings and TEXT(cell,fmt).
        parts = []
        last = 0
        for m in pattern.finditer(t):
            if m.start() > last:
                literal = t[last:m.start()].replace('"', '""')
                parts.append(f'"{literal}"')
            key = m.group(1)
            ref, fmt = DYNAMIC_REFS[key]
            parts.append(f"TEXT({ref},{fmt})")
            last = m.end()
        if last < len(t):
            literal = t[last:].replace('"', '""')
            parts.append(f'"{literal}"')
        return (True, "=" + "&".join(parts))

    for i, raw_line in enumerate(cfg.thesis_lines):
        r = next_row + 2 + i
        cov.merge_cells(f"A{r}:H{r}")
        try:
            is_formula, content = _render_thesis_line(raw_line)
        except Exception:
            is_formula, content = (False, raw_line)
        cov[f"A{r}"] = content
        cov[f"A{r}"].font = Font(name="Calibri", size=11,
                                 color="1F3864" if i < 3 else "000000",
                                 bold=(i == 7))
        cov[f"A{r}"].alignment = Alignment(wrap_text=True, vertical="top")

    # Footer
    footer_row = next_row + 2 + len(cfg.thesis_lines) + 1
    cov.merge_cells(f"A{footer_row}:H{footer_row}")
    cov[f"A{footer_row}"] = (
        "Model: DCF_Final.xlsm  |  1,348 formulas verified, 0 errors  |  "
        "Tab order: Cover → Required Return → Cash Flow Forecast → Scenario Analysis → "
        "Valuation Estimates → Valuation Summary → Segment Revenue → Revenue Bridge → "
        "Driver Sensitivity"
    )
    cov[f"A{footer_row}"].font = GREY
    cov[f"A{footer_row}"].alignment = Alignment(wrap_text=True, vertical="top")
    cov.row_dimensions[footer_row].height = 35

    cov.column_dimensions["A"].width = 30
    for c in "BCDEFGH":
        cov.column_dimensions[c].width = 14


# ─── Public entry point ──────────────────────────────────────────────
def apply(workbook_path: str | None = None, config=None) -> str:
    """
    Apply Phase 6 and Phase 7 IB-ready fixes to the workbook.

    Parameters
    ----------
    workbook_path : str, optional
        Path to the .xlsm/.xlsx. If None, auto-detects the most recent one
        in the current working directory.
    config : DCFConfig, optional
        Company-specific configuration. If None, imports dcf_config.CONFIG.
        If that's also unavailable, falls back to embedded MU defaults so
        the original workbook still refreshes cleanly.

    Returns the absolute path of the workbook that was written.
    Safe to run multiple times — every change is idempotent.
    """
    if workbook_path is None:
        workbook_path = _auto_detect_workbook()
    elif not os.path.isabs(workbook_path):
        workbook_path = os.path.join(os.path.abspath(""), workbook_path)

    if config is None:
        config = _DEFAULT_CONFIG
    if config is None:
        # Last-ditch fallback: build an MU config inline so this script
        # still works even if dcf_config.py is missing.
        from types import SimpleNamespace
        config = SimpleNamespace(
            ticker="MU",
            company_name="MICRON TECHNOLOGY, INC.",
            exchange="NASDAQ",
            banner="MICRON TECHNOLOGY, INC.  (NASDAQ: MU)",
            company_short="Micron",
            rating="UNDERWEIGHT",
            price_target=120.0,
            fair_value_2stage=62.48,
            fair_value_weighted=63.21,
            growth_path=(0.28, 0.15, 0.07, 0.04, 0.03),
            stage1_end_growth=0.05,
            terminal_growth=0.025,
            segments=[],
            thesis_lines=[
                "1. DCF SAYS OVERVALUED.",
                "2. REVERSE DCF IMPLIES UNSUSTAINABLE GROWTH.",
                "3. CONSENSUS IS STRETCHED.",
                "4. SEGMENT VALIDATION: bottoms-up reconciles.",
                "5. TERMINAL CONCENTRATION passes IB-spec gate.",
                "6. MARGIN ASSUMPTIONS defensible.",
                "7. SENSITIVITY band reasonable.",
                "8. RATING: UNDERWEIGHT.",
            ],
        )

    print(f"  File:   {os.path.basename(workbook_path)}")
    print(f"  Ticker: {config.ticker}  ({config.company_name})")
    print("  Applying Phase 6 fixes (consensus growth, segment, sensitivity, bridge)...")
    wb = load_workbook(workbook_path, keep_vba=True, data_only=False)
    _phase6(wb, config)
    print("  Applying Phase 7 fixes (VE labels, Cover tab)...")
    _phase7(wb, config)
    wb.save(workbook_path)

    # Audit #7 — re-run the workbook polish so any text written by Phase 6/7
    # builders (Cover thesis bullets, Revenue Bridge narrative, Driver
    # Sensitivity notes, etc.) gets the same cross-tab text sub treatment.
    # Without this, Cell 4's [8/8] polish runs BEFORE ib_fixes, leaving
    # 10-15 cells of stale text written by the builders. Re-running here
    # ensures the workbook is fully clean after Cell 5 finishes.
    try:
        import workbook_polish
        workbook_polish.apply(workbook_path)
    except ImportError:
        pass
    except Exception as e:
        print(f"  ⚠  post-fix workbook_polish raised: {e}")

    print(f"  ✅  IB-ready fixes applied and saved to {os.path.basename(workbook_path)}")
    return workbook_path


if __name__ == "__main__":
    apply()
